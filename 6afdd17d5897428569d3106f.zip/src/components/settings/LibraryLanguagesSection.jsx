import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Tags } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/AuthContext";
import { renameGameLanguage } from "@/lib/server-fns";
import useSiteLanguage from "@/hooks/use-site-language";

// Admins only: every language the library's builds are tagged with, and a way
// to rename one everywhere it is used.
export default function LibraryLanguagesSection({ languages }) {
  const { user } = useAuth();
  const router = useRouter();
  const rename = useServerFn(renameGameLanguage);
  const { t } = useSiteLanguage();
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  if (user?.role !== "admin") return null;

  const current = from || languages[0]?.name || "";

  const submit = async (event) => {
    event.preventDefault();
    if (!current || !to.trim()) return;
    setBusy(true);
    setMessage("");
    try {
      const result = await rename({ data: { from: current, to: to.trim() } });
      setMessage(`Updated ${result.updated} ${result.updated === 1 ? "build" : "builds"}.`);
      setFrom("");
      setTo("");
      await router.invalidate();
    } catch (err) {
      setMessage(err?.message || "That rename could not be saved.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="rounded-xl border border-border bg-card p-5">
      <h2 className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        <Tags className="h-3.5 w-3.5" />
        {t("library_languages")}
      </h2>

      {languages.length === 0 ? (
        <p className="mt-3 text-sm text-muted-foreground">No build lists a language yet.</p>
      ) : (
        <>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {languages.map((language) => (
              <span
                key={language.name}
                className="rounded-full border border-border bg-background px-3 py-1 text-xs text-muted-foreground"
              >
                {language.name} <span className="font-mono text-[10px] text-primary">{language.count}</span>
              </span>
            ))}
          </div>

          <form onSubmit={submit} className="mt-4 flex flex-wrap items-end gap-2">
            <div className="space-y-1">
              <Label htmlFor="rename-from" className="text-xs text-muted-foreground">
                Rename
              </Label>
              <select
                id="rename-from"
                value={current}
                onChange={(event) => setFrom(event.target.value)}
                className="h-9 rounded-md border border-input bg-transparent px-3 text-sm text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              >
                {languages.map((language) => (
                  <option key={language.name} value={language.name}>
                    {language.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="rename-to" className="text-xs text-muted-foreground">
                to
              </Label>
              <Input
                id="rename-to"
                value={to}
                onChange={(event) => setTo(event.target.value)}
                placeholder="English (US)"
                className="h-9"
              />
            </div>
            <Button type="submit" size="sm" disabled={busy || !to.trim()}>
              {busy ? "Saving…" : "Rename"}
            </Button>
          </form>
        </>
      )}

      {message && <p className="mt-3 text-xs text-muted-foreground">{message}</p>}
    </section>
  );
}