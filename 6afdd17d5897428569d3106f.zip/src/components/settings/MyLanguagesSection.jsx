import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Languages, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { savePlayLanguages } from "@/lib/server-fns";
import useSiteLanguage from "@/hooks/use-site-language";
import { cn } from "@/lib/utils";

// The languages a member plays in, kept on their own account so the library's
// Language filter can show only those builds.
export default function MyLanguagesSection({ languages }) {
  const { user, isAuthenticated, isLoadingAuth, refresh } = useAuth();
  const save = useServerFn(savePlayLanguages);
  const { t } = useSiteLanguage();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const mine = user?.play_languages || [];
  const options = [...new Set([...languages, ...mine])].sort((a, b) => a.localeCompare(b));

  const toggle = async (language) => {
    const next = mine.includes(language) ? mine.filter((item) => item !== language) : [...mine, language];
    setBusy(true);
    setError("");
    try {
      await save({ data: { languages: next } });
      await refresh();
    } catch (err) {
      setError(err?.message || "Those languages could not be saved.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="rounded-xl border border-border bg-card p-5">
      <h2 className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        <Languages className="h-3.5 w-3.5" />
        {t("my_languages")}
      </h2>

      {isLoadingAuth ? (
        <p className="mt-3 text-sm text-muted-foreground">Loading…</p>
      ) : !isAuthenticated ? (
        <p className="mt-3 text-sm text-muted-foreground">
          <Link to="/login" className="text-primary hover:underline">
            Sign in
          </Link>{" "}
          to save the languages you play in.
        </p>
      ) : languages.length === 0 ? (
        <p className="mt-3 text-sm text-muted-foreground">No build in the library lists its languages yet.</p>
      ) : (
        <>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {options.map((language) => {
              const active = mine.includes(language);
              return (
                <button
                  key={language}
                  type="button"
                  disabled={busy}
                  onClick={() => toggle(language)}
                  className={cn(
                    "rounded-full border px-3 py-1 text-xs transition-colors disabled:opacity-60",
                    active
                      ? "border-primary/60 bg-primary/15 text-primary"
                      : "border-border bg-background text-muted-foreground hover:text-foreground"
                  )}
                >
                  {language}
                </button>
              );
            })}
          </div>
          <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
            {busy && <Loader2 className="h-3 w-3 animate-spin" />}
            {mine.length
              ? "The library's Language filter can show only these."
              : "Pick one or more languages to save them to your account."}
          </p>
        </>
      )}

      {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
    </section>
  );
}