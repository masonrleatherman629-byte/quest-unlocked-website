import { Link } from "@tanstack/react-router";
import { MailCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";

// An invited person lands on the public home page, so the sign-up step is
// pointed out instead of leaving them to guess.
export default function InviteBanner() {
  const { isAuthenticated, isLoadingAuth } = useAuth();
  if (isLoadingAuth || isAuthenticated) return null;

  return (
    <div className="mx-auto w-full max-w-6xl px-5 pt-6">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-primary/40 bg-primary/10 px-4 py-3">
        <p className="flex items-center gap-2 text-sm text-foreground">
          <MailCheck className="h-4 w-4 shrink-0 text-primary" />
          Got an invite? Create your account with the invited email, then choose your own password.
        </p>
        <Button asChild size="sm">
          <Link to="/register">Create account</Link>
        </Button>
      </div>
    </div>
  );
}