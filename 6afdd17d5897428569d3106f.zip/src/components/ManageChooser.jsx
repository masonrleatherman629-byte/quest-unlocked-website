import { Link } from "@tanstack/react-router";
import { Lock, ShieldCheck, Upload } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { canUseAdminArea } from "@/lib/admin-access";

export default function ManageChooser({ open, onOpenChange, user }) {
  const canAdmin = canUseAdminArea(user);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading">Manage</DialogTitle>
          <DialogDescription>Pick the area you want to open.</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {canAdmin ? (
            <Link
              to="/admin"
              onClick={() => onOpenChange(false)}
              className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/50"
            >
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border border-primary/40 bg-primary/10 text-primary">
                <ShieldCheck className="h-5 w-5" />
              </span>
              <span>
                <span className="block font-heading text-sm font-semibold text-foreground">Admin manage</span>
                <span className="mt-0.5 block text-xs text-muted-foreground">
                  Every build, publisher, launcher file, request and update.
                </span>
              </span>
            </Link>
          ) : (
            <div className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 opacity-60">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border border-border bg-muted text-muted-foreground">
                <Lock className="h-5 w-5" />
              </span>
              <span>
                <span className="block font-heading text-sm font-semibold text-foreground">Admin manage</span>
                <span className="mt-0.5 block text-xs text-muted-foreground">
                  Locked. Only the owner account can open this area.
                </span>
              </span>
            </div>
          )}

          <Link
            to="/manage"
            onClick={() => onOpenChange(false)}
            className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border border-border bg-muted text-muted-foreground">
              <Upload className="h-5 w-5" />
            </span>
            <span>
              <span className="block font-heading text-sm font-semibold text-foreground">Regular supply</span>
              <span className="mt-0.5 block text-xs text-muted-foreground">
                Your own page: upload a game and message us about your requests.
              </span>
            </span>
          </Link>
        </div>
      </DialogContent>
    </Dialog>
  );
}