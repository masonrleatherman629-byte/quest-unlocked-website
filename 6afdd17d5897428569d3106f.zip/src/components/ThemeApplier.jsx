import { useEffect } from "react";
import { applyTheme, readTheme, THEME_EVENT } from "@/lib/theme";

// Puts the saved appearance on the page and keeps it in sync when it changes.
export default function ThemeApplier() {
  useEffect(() => {
    const sync = () => applyTheme(readTheme());
    sync();
    window.addEventListener(THEME_EVENT, sync);
    return () => window.removeEventListener(THEME_EVENT, sync);
  }, []);

  return null;
}