import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { MessageCircle, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import RequestThreadDialog from "@/components/requests/RequestThreadDialog";
import UserAvatar from "@/components/profile/UserAvatar";
import { deleteGameRequest, setGameRequestStatus } from "@/lib/server-fns";

const STATUSES = ["New", "Planned", "Shipped", "Declined"];

const formatDate = (value) =>
  value ? new Date(value).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "";

export default function RequestsPanel({ requests }) {
  const router = useRouter();
  const setStatus = useServerFn(setGameRequestStatus);
  const remove = useServerFn(deleteGameRequest);

  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState("");
  const [activeId, setActiveId] = useState(null);
  const active = requests.find((request) => request.id === activeId) || null;

  const change = async (id, status) => {
    await setStatus({ data: { id, status } });
    await router.invalidate();
  };

  const handleDelete = async (request) => {
    const confirmed = window.confirm(`Delete the request "${request.title}"? This cannot be undone.`);
    if (!confirmed) return;
    setBusyId(request.id);
    setError("");
    try {
      await remove({ data: { id: request.id } });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "The request could not be deleted.");
    } finally {
      setBusyId(null);
    }
  };

  if (!requests.length) {
    return (
      <div className="rounded-xl border border-dashed border-border px-6 py-16 text-center">
        <p className="font-heading text-lg text-foreground">No requests yet</p>
        <p className="mt-1 text-sm text-muted-foreground">New submissions from the Requests page land here.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {error && <p className="text-sm text-destructive">{error}</p>}
      <ul className="space-y-3">
        {requests.map((request) => (
          <li key={request.id} className="rounded-xl border border-border bg-card p-5">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary" className="font-mono text-[10px] uppercase tracking-[0.14em]">
                {request.kind}
              </Badge>
              <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                <UserAvatar
                  user={{
                    full_name: request.requester_name,
                    avatar_url: request.requester_avatar_url,
                  }}
                  className="h-5 w-5"
                />
                {request.requester_name || "Guest"}
              </span>
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                {formatDate(request.created_date)}
              </span>
              <span className="flex items-center gap-1 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                <MessageCircle className="h-3.5 w-3.5" />
                {(request.messages || []).length}
              </span>
            </div>

            <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
              <button
                type="button"
                onClick={() => setActiveId(request.id)}
                className="text-left font-heading text-lg font-semibold text-foreground hover:text-primary"
              >
                {request.title}
              </button>
              <div className="flex items-center gap-2">
                <Select value={request.status} onValueChange={(value) => change(request.id, value)}>
                  <SelectTrigger className="h-8 w-[130px] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  disabled={busyId === request.id}
                  onClick={() => handleDelete(request)}
                  aria-label={`Delete ${request.title}`}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{request.details}</p>
            {request.contact && (
              <p className="mt-2 font-mono text-[11px] text-muted-foreground">contact: {request.contact}</p>
            )}

            <Button variant="outline" size="sm" className="mt-3" onClick={() => setActiveId(request.id)}>
              <MessageCircle className="mr-2 h-3.5 w-3.5" />
              Message
            </Button>
          </li>
        ))}
      </ul>

      <RequestThreadDialog
        request={active}
        open={Boolean(active)}
        onOpenChange={(value) => !value && setActiveId(null)}
      />
    </div>
  );
}