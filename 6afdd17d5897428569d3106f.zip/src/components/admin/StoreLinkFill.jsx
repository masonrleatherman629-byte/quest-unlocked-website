import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Link2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { lookupStoreLink } from "@/lib/server-fns";

// Fields a pasted listing may fill. Uploads and build details are never touched.
const FIELDS = [
  "title",
  "developer",
  "description",
  "release_date",
  "genres",
  "players",
  "rating",
  "rating_count",
  "store_status",
  "store_url",
  "image_url",
  "screenshots",
  "video_urls",
];

export default function StoreLinkFill({ onFill }) {
  const lookup = useServerFn(lookupStoreLink);
  const [url, setUrl] = useState("");
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const busy = status === "Reading the listing";

  const fill = async (event) => {
    event.preventDefault();
    if (!url.trim() || busy) return;
    setError("");
    setStatus("Reading the listing");
    try {
      const result = await lookup({ data: { url: url.trim() } });
      const details = {};
      for (const key of FIELDS) {
        const value = result?.[key];
        if (value === undefined || value === null) continue;
        if (typeof value === "string" && !value.trim()) continue;
        if (Array.isArray(value) && !value.length) continue;
        details[key] = value;
      }
      if (!Object.keys(details).length) {
        setStatus("");
        setError("Nothing could be read from that link. Fill the details in by hand.");
        return;
      }
      onFill(details);
      setStatus("Details filled in — check them before saving");
    } catch (err) {
      setStatus("");
      setError(err?.message || "That link could not be read.");
    }
  };

  return (
    <div className="space-y-2 rounded-lg border border-border bg-background p-4">
      <Label htmlFor="store-link-fill">Paste a Meta Quest Store link</Label>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Input
          id="store-link-fill"
          value={url}
          onChange={(event) => setUrl(event.target.value)}
          placeholder="https://www.meta.com/experiences/…"
        />
        <Button type="button" variant="outline" onClick={fill} disabled={busy || !url.trim()}>
          {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Link2 className="mr-2 h-4 w-4" />}
          Fill details
        </Button>
      </div>
      {status && <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">{status}</p>}
      {error && <p className="text-xs text-destructive">{error}</p>}
      <p className="text-xs text-muted-foreground">
        Title, developer, description, artwork, screenshots, rating and player count come from the listing.
      </p>
    </div>
  );
}