import { useEffect, useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Wrench } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { setMaintenance } from "@/lib/site-config-fns";

// The switch that takes the public site down, kept with the rest of Manage.
export default function MaintenanceToggle({ config }) {
  const router = useRouter();
  const save = useServerFn(setMaintenance);
  const [enabled, setEnabled] = useState(config.maintenance);
  const [message, setMessage] = useState(config.message);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    setEnabled(config.maintenance);
    setMessage(config.message);
  }, [config.maintenance, config.message]);

  const submit = async () => {
    setSaving(true);
    setError("");
    try {
      await save({ data: { maintenance: enabled, message } });
      await router.invalidate();
      toast.success(enabled ? "The maintenance screen is live." : "The site is back up.");
    } catch (err) {
      setError(err?.message || "The setting could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-6 rounded-xl border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <Wrench className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <div>
            <h2 className="font-heading text-sm font-semibold text-foreground">Maintenance screen</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Visitors see a maintenance page instead of the library. Admins keep full access.
            </p>
          </div>
        </div>
        <Switch checked={enabled} onCheckedChange={setEnabled} aria-label="Show the maintenance screen" />
      </div>

      <Textarea
        value={message}
        onChange={(event) => setMessage(event.target.value)}
        rows={2}
        maxLength={500}
        placeholder="What visitors are told while the site is down"
        aria-label="Maintenance message"
        className="mt-3 resize-none"
      />

      <div className="mt-3 flex items-center gap-3">
        <Button size="sm" onClick={submit} disabled={saving}>
          {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Save
        </Button>
        <span className="text-xs text-muted-foreground">
          {config.maintenance ? "Maintenance is on" : "Maintenance is off"}
        </span>
      </div>

      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
    </div>
  );
}