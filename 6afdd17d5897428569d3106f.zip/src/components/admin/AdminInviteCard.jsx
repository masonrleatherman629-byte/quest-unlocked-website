import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, MailPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { inviteAdmin } from "@/lib/server-fns";

// A new admin is invited by email and picks their own password from that email.
export default function AdminInviteCard() {
  const invite = useServerFn(inviteAdmin);
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");

  const send = async (event) => {
    event.preventDefault();
    if (!email.trim() || sending) return;
    setSending(true);
    setError("");
    setStatus("");
    try {
      await invite({ data: { email: email.trim() } });
      setStatus(`Invite sent to ${email.trim()}. They set their own password from that email.`);
      setEmail("");
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "The invite could not be sent.");
    } finally {
      setSending(false);
    }
  };

  return (
    <form onSubmit={send} className="mt-6 rounded-xl border border-border bg-card p-5">
      <h2 className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        <MailPlus className="h-3.5 w-3.5" />
        Invite an admin
      </h2>
      <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-end">
        <div className="flex-1 space-y-2">
          <Label htmlFor="admin-invite-email">Email address</Label>
          <Input
            id="admin-invite-email"
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="name@example.com"
          />
        </div>
        <Button type="submit" disabled={sending || !email.trim()}>
          {sending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Send invite
        </Button>
      </div>
      {status && <p className="mt-2 text-xs text-primary">{status}</p>}
      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
      <p className="mt-2 text-xs text-muted-foreground">
        Sign-in uses an email address and a password chosen by the account owner, so nobody can set a password for
        someone else.
      </p>
    </form>
  );
}