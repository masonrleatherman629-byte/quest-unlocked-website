import { useEffect, useMemo, useState } from "react";
import { Loader2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function PublisherGamesDialog({
  open,
  onOpenChange,
  publisher,
  games,
  publishers,
  onAssign,
  busyId,
}) {
  const [term, setTerm] = useState("");

  useEffect(() => {
    if (open) setTerm("");
  }, [open, publisher?.id]);

  const names = useMemo(
    () => Object.fromEntries(publishers.map((item) => [item.id, item.name])),
    [publishers]
  );

  const matches = useMemo(() => {
    const query = term.trim().toLowerCase();
    return games
      .filter(
        (game) =>
          !query ||
          [game.title, game.developer].filter(Boolean).join(" ").toLowerCase().includes(query)
      )
      .slice(0, 50);
  }, [games, term]);

  if (!publisher) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading">Games for {publisher.name}</DialogTitle>
          <DialogDescription>Search your library and attach a build to this publisher.</DialogDescription>
        </DialogHeader>

        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={term}
            onChange={(event) => setTerm(event.target.value)}
            placeholder="Search games by title or developer"
            className="pl-9"
          />
        </div>

        <div className="max-h-80 overflow-y-auto rounded-lg border border-border">
          {matches.length ? (
            matches.map((game) => {
              const attached = game.publisher_id === publisher.id;
              return (
                <div
                  key={game.id}
                  className="flex items-center justify-between gap-3 border-b border-border/70 px-3 py-2.5 last:border-b-0"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm text-foreground">{game.title}</p>
                    <p className="truncate font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      {attached
                        ? "In this publisher"
                        : game.publisher_id
                          ? names[game.publisher_id] || "Another publisher"
                          : game.developer || "No publisher"}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant={attached ? "ghost" : "outline"}
                    disabled={busyId === game.id}
                    onClick={() => onAssign(game.id, attached ? "" : publisher.id)}
                  >
                    {busyId === game.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : attached ? (
                      "Remove"
                    ) : (
                      "Add"
                    )}
                  </Button>
                </div>
              );
            })
          ) : (
            <p className="px-3 py-8 text-center text-sm text-muted-foreground">
              No games match that search.
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}