import moment from "moment";
import { Image } from "@/components/ui/image";

// One line of the staff chat: who said it, when, and what.
export default function StaffMessageRow({ message }) {
  const initials = (message.author_name || "Staff").slice(0, 2).toUpperCase();

  return (
    <div className="flex gap-3">
      {message.author_avatar_url ? (
        <Image
          src={message.author_avatar_url}
          alt=""
          className="h-8 w-8 shrink-0 rounded-full object-cover"
        />
      ) : (
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary text-[11px] font-semibold text-secondary-foreground">
          {initials}
        </span>
      )}
      <div className="min-w-0">
        <p className="flex flex-wrap items-baseline gap-2">
          <span className="text-sm font-medium text-foreground">{message.author_name || "Staff"}</span>
          <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            {moment(message.created_date).format("MMM D, h:mm A")}
          </span>
        </p>
        <p className="mt-0.5 whitespace-pre-wrap text-sm text-muted-foreground">{message.body}</p>
      </div>
    </div>
  );
}