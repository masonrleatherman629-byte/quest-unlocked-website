const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Send } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import StaffMessageRow from "@/components/admin/StaffMessageRow";
import { sendStaffMessage } from "@/lib/staff-chat-fns";

// The team's own thread, shared by every admin account.
export default function StaffChat({ messages }) {
  const [list, setList] = useState(messages);
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const send = useServerFn(sendStaffMessage);
  const bottom = useRef(null);

  useEffect(() => setList(messages), [messages]);

  // A message another admin sends shows up without a reload.
  useEffect(
    () =>
      db.entities.StaffMessage.subscribe((event) => {
        if (event.type !== "create" || !event.data?.id) return;
        setList((current) =>
          current.some((message) => message.id === event.data.id) ? current : [...current, event.data]
        );
      }),
    []
  );

  useEffect(() => {
    bottom.current?.scrollIntoView({ block: "nearest" });
  }, [list.length]);

  const submit = async (event) => {
    event.preventDefault();
    const text = body.trim();
    if (!text || sending) return;
    setSending(true);
    setError("");
    try {
      const created = await send({ data: { body: text } });
      setList((current) =>
        current.some((message) => message.id === created.id) ? current : [...current, created]
      );
      setBody("");
    } catch (err) {
      setError(err?.message || "The message could not be sent.");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="max-h-[55vh] min-h-[16rem] space-y-4 overflow-y-auto p-4">
        {list.length ? (
          list.map((message) => <StaffMessageRow key={message.id} message={message} />)
        ) : (
          <p className="py-12 text-center text-sm text-muted-foreground">
            No messages yet. Say hello to the team.
          </p>
        )}
        <div ref={bottom} />
      </div>

      <form onSubmit={submit} className="border-t border-border/70 p-3">
        <div className="flex items-end gap-2">
          <Textarea
            value={body}
            onChange={(event) => setBody(event.target.value)}
            placeholder="Message the team"
            rows={2}
            aria-label="Staff chat message"
            className="min-h-[44px] resize-none"
            onKeyDown={(event) => {
              if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) submit(event);
            }}
          />
          <Button type="submit" disabled={sending || !body.trim()}>
            {sending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Send className="mr-2 h-4 w-4" />
            )}
            Send
          </Button>
        </div>
        {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
      </form>
    </div>
  );
}