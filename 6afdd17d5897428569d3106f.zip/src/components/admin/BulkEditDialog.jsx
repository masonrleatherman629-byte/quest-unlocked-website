import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useRouter } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { bulkUpdateGames } from "@/lib/server-fns";

const KEEP = "keep";
const STATUSES = ["Ready", "Not in library", "Draft", "Archived"];
const CATEGORIES = ["Games", "Apps", "Experiences", "Demos"];

const EMPTY = {
  status: KEEP,
  category: KEEP,
  price: "",
  content_rating: "",
  offline_play: KEEP,
};

// One form, applied to every selected game: anything left on Keep is untouched.
export default function BulkEditDialog({ open, onOpenChange, games = [], onSaved }) {
  const router = useRouter();
  const bulkUpdate = useServerFn(bulkUpdateGames);
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setForm(EMPTY);
    setError("");
  }, [open]);

  const set = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    const patch = {};
    if (form.status !== KEEP) patch.status = form.status;
    if (form.category !== KEEP) patch.category = form.category;
    if (form.price.trim()) patch.price = form.price.trim();
    if (form.content_rating.trim()) patch.content_rating = form.content_rating.trim();
    if (form.offline_play !== KEEP) patch.offline_play = form.offline_play === "yes";

    if (!Object.keys(patch).length) {
      setError("Pick at least one setting to change.");
      return;
    }

    setSaving(true);
    setError("");
    try {
      const { updated } = await bulkUpdate({ data: { ids: games.map((game) => game.id), patch } });
      toast.success(`${updated} ${updated === 1 ? "game" : "games"} updated.`);
      await router.invalidate();
      onSaved?.();
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || "The games could not be updated.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading">Bulk edit {games.length} games</DialogTitle>
          <DialogDescription>
            The same settings are applied to every selected game. Fields left on Keep stay as they are.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(value) => set("status", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={KEEP}>Keep current</SelectItem>
                {STATUSES.map((status) => (
                  <SelectItem key={status} value={status}>
                    {status}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Category</Label>
            <Select value={form.category} onValueChange={(value) => set("category", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={KEEP}>Keep current</SelectItem>
                {CATEGORIES.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Offline play</Label>
            <Select value={form.offline_play} onValueChange={(value) => set("offline_play", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={KEEP}>Keep current</SelectItem>
                <SelectItem value="yes">Yes</SelectItem>
                <SelectItem value="no">No</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bulk-price">Price</Label>
            <Input
              id="bulk-price"
              value={form.price}
              onChange={(event) => set("price", event.target.value)}
              placeholder="Leave empty to keep, e.g. $4.99"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bulk-rating">Content rating</Label>
            <Input
              id="bulk-rating"
              value={form.content_rating}
              onChange={(event) => set("content_rating", event.target.value)}
              placeholder="Leave empty to keep, e.g. PEGI 12"
            />
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !games.length}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Apply to {games.length}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}