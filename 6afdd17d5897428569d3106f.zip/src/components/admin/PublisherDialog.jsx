import { useEffect, useState } from "react";
import { ImagePlus, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Image } from "@/components/ui/image";
import { uploadGameArtwork } from "@/lib/game-artwork";

const EMPTY_PUBLISHER = {
  name: "",
  description: "",
  logo_url: "",
  website_url: "",
  discord_url: "",
};

export default function PublisherDialog({ open, onOpenChange, publisher, onSave }) {
  const [form, setForm] = useState(EMPTY_PUBLISHER);
  const [logoStatus, setLogoStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setForm(publisher ? { ...EMPTY_PUBLISHER, ...publisher } : EMPTY_PUBLISHER);
    setLogoStatus("");
    setError("");
  }, [open, publisher]);

  const update = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));

  const handleLogo = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setLogoStatus("Uploading");
    setError("");
    try {
      const url = await uploadGameArtwork(file, setLogoStatus);
      setForm((current) => ({ ...current, logo_url: url }));
      setLogoStatus("Done");
    } catch (err) {
      setError(err?.message || "The logo could not be uploaded.");
      setLogoStatus("Failed");
    } finally {
      event.target.value = "";
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.name.trim()) {
      setError("A publisher name is required.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await onSave({ ...form, name: form.name.trim() });
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || "The publisher could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading">
            {publisher?.id ? `Edit ${publisher.name}` : "Add a publisher"}
          </DialogTitle>
          <DialogDescription>
            {publisher?.id
              ? "Changes are saved to this publisher only."
              : "Studios you can attach games to from the game editor."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 shrink-0 overflow-hidden rounded-lg border border-border bg-muted">
              {form.logo_url ? (
                <Image
                  src={form.logo_url}
                  alt="Publisher logo preview"
                  className="h-full w-full object-cover"
                  fittingType="fill"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                  Logo
                </div>
              )}
            </div>
            <div className="space-y-1">
              <Button asChild type="button" variant="outline" size="sm">
                <label className="cursor-pointer">
                  <ImagePlus className="mr-2 h-4 w-4" />
                  {form.logo_url ? "Replace logo" : "Upload logo"}
                  <input type="file" accept="image/*" className="hidden" onChange={handleLogo} />
                </label>
              </Button>
              {logoStatus && logoStatus !== "Done" && (
                <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">{logoStatus}…</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="publisher-name">Name</Label>
            <Input id="publisher-name" value={form.name} onChange={update("name")} placeholder="Physix Lab Studios" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="publisher-description">Description</Label>
            <Textarea
              id="publisher-description"
              value={form.description}
              onChange={update("description")}
              rows={3}
              placeholder="What this studio makes."
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="publisher-website">Website</Label>
              <Input id="publisher-website" value={form.website_url} onChange={update("website_url")} placeholder="https://…" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="publisher-discord">Discord</Label>
              <Input id="publisher-discord" value={form.discord_url} onChange={update("discord_url")} placeholder="https://discord.gg/…" />
            </div>
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {publisher?.id ? "Save changes" : "Add publisher"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}