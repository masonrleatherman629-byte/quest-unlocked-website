import { Link } from "@tanstack/react-router";

const TABS = [
  { to: "/admin", label: "Builds" },
  { to: "/admin/bundles", label: "Bundles" },
  { to: "/admin/publishers", label: "Publishers" },
  { to: "/admin/launcher", label: "Launcher" },
  { to: "/admin/requests", label: "Requests" },
  { to: "/admin/updates", label: "Updates" },
  { to: "/admin/chat", label: "Staff chat" },
  { to: "/admin/guide", label: "Guide" },
  { to: "/admin/users", label: "Users" },
  { to: "/admin/team", label: "Team" },
];

export default function AdminTabs() {
  return (
    <nav className="mt-6 flex flex-wrap gap-1 border-b border-border/70">
      {TABS.map((tab) => (
        <Link
          key={tab.to}
          to={tab.to}
          className="border-b-2 border-transparent px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          activeProps={{ className: "border-primary text-foreground" }}
        >
          {tab.label}
        </Link>
      ))}
    </nav>
  );
}