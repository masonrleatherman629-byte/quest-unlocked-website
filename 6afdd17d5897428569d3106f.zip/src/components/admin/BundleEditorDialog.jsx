import { useEffect, useState } from "react";
import { Check, ImagePlus, Loader2, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Image } from "@/components/ui/image";
import StoreLinkFill from "@/components/admin/StoreLinkFill";
import { uploadGameArtwork } from "@/lib/game-artwork";
import { cn } from "@/lib/utils";

const EMPTY_BUNDLE = {
  title: "",
  description: "",
  image_url: "",
  screenshots: [],
  store_url: "",
  game_ids: [],
};

export default function BundleEditorDialog({ open, onOpenChange, bundle, games = [], onSave }) {
  const [form, setForm] = useState(EMPTY_BUNDLE);
  const [search, setSearch] = useState("");
  const [artworkStatus, setArtworkStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setForm({
      ...EMPTY_BUNDLE,
      ...bundle,
      screenshots: bundle?.screenshots || [],
      game_ids: bundle?.game_ids || [],
    });
    setSearch("");
    setArtworkStatus("");
    setError("");
  }, [open, bundle]);

  const toggleGame = (id) =>
    setForm((current) => ({
      ...current,
      game_ids: current.game_ids.includes(id)
        ? current.game_ids.filter((value) => value !== id)
        : [...current.game_ids, id],
    }));

  const handleArtwork = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setArtworkStatus("Optimising");
    setError("");
    try {
      const url = await uploadGameArtwork(file, setArtworkStatus);
      setForm((current) => ({ ...current, image_url: url }));
    } catch (err) {
      setError(err?.message || "The artwork could not be uploaded.");
    } finally {
      event.target.value = "";
    }
  };

  // A pasted bundle listing fills the bundle's own copy and artwork.
  const applyStoreDetails = (details) =>
    setForm((current) => ({
      ...current,
      title: details.title || current.title,
      description: details.description || current.description,
      image_url: details.image_url || current.image_url,
      screenshots: details.screenshots?.length ? details.screenshots : current.screenshots,
      store_url: details.store_url || current.store_url,
    }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.title.trim()) {
      setError("A bundle name is required.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await onSave({ ...form, title: form.title.trim() });
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || "The bundle could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  const term = search.trim().toLowerCase();
  const visibleGames = games.filter((game) =>
    !term || [game.title, game.developer].filter(Boolean).join(" ").toLowerCase().includes(term)
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-heading">{bundle?.id ? `Edit ${bundle.title}` : "Add a bundle"}</DialogTitle>
          <DialogDescription>Pick the library games that belong to this bundle.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          <StoreLinkFill onFill={applyStoreDetails} />

          <div className="space-y-2">
            <Label>Bundle artwork</Label>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="aspect-[4/3] w-full overflow-hidden rounded-lg border border-border bg-muted sm:w-44">
                {form.image_url ? (
                  <Image src={form.image_url} alt="Bundle artwork" className="h-full w-full object-cover" fittingType="fill" />
                ) : (
                  <div className="flex h-full items-center justify-center font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    No artwork
                  </div>
                )}
              </div>
              <Button asChild type="button" variant="outline" size="sm">
                <label className="cursor-pointer">
                  <ImagePlus className="mr-2 h-4 w-4" />
                  {form.image_url ? "Replace artwork" : "Upload artwork"}
                  <input type="file" accept="image/*" className="hidden" onChange={handleArtwork} />
                </label>
              </Button>
              {artworkStatus && artworkStatus !== "Done" && (
                <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">{artworkStatus}…</span>
              )}
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="bundle-title">Bundle name</Label>
              <Input
                id="bundle-title"
                value={form.title}
                onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))}
                placeholder="Starter Pack"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bundle-store">Store listing</Label>
              <Input
                id="bundle-store"
                value={form.store_url}
                onChange={(event) => setForm((current) => ({ ...current, store_url: event.target.value }))}
                placeholder="https://www.meta.com/experiences/…"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="bundle-description">Description</Label>
              <Textarea
                id="bundle-description"
                value={form.description}
                onChange={(event) => setForm((current) => ({ ...current, description: event.target.value }))}
                rows={4}
                placeholder="What the bundle contains and who it suits."
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Included games</Label>
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                {form.game_ids.length} picked
              </span>
            </div>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search the library"
                className="pl-9"
              />
            </div>
            <div className="max-h-64 overflow-y-auto rounded-lg border border-border bg-background">
              {visibleGames.length ? (
                visibleGames.map((game) => {
                  const active = form.game_ids.includes(game.id);
                  return (
                    <button
                      key={game.id}
                      type="button"
                      onClick={() => toggleGame(game.id)}
                      className={cn(
                        "flex w-full items-center gap-3 border-b border-border/60 px-3 py-2 text-left last:border-b-0",
                        active ? "bg-primary/10" : "hover:bg-secondary/50"
                      )}
                    >
                      <span
                        className={cn(
                          "flex h-4 w-4 shrink-0 items-center justify-center rounded border",
                          active ? "border-primary bg-primary text-primary-foreground" : "border-border"
                        )}
                      >
                        {active && <Check className="h-3 w-3" />}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm text-foreground">{game.title}</span>
                        <span className="block truncate font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                          {[game.developer, game.status].filter(Boolean).join(" · ")}
                        </span>
                      </span>
                    </button>
                  );
                })
              ) : (
                <p className="px-3 py-6 text-center text-xs text-muted-foreground">No games match that search.</p>
              )}
            </div>
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {bundle?.id ? "Save bundle" : "Create bundle"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}