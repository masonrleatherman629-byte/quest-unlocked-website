import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const EMPTY_SECTION = { title: "", body: "", image_url: "", order: 0 };

export default function GuideEditorDialog({ open, onOpenChange, section, nextOrder = 1, onSave }) {
  const [form, setForm] = useState(EMPTY_SECTION);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setForm({ ...EMPTY_SECTION, order: nextOrder, ...section });
    setError("");
  }, [open, section, nextOrder]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.title.trim() || !form.body.trim()) {
      setError("A heading and some text are both needed.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await onSave({
        ...form,
        title: form.title.trim(),
        body: form.body.trim(),
        order: Number(form.order) || 0,
      });
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || "The guide step could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-heading">{section?.id ? "Edit guide step" : "Add a guide step"}</DialogTitle>
          <DialogDescription>Steps appear on the guide page in this order.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-[minmax(0,1fr)_100px]">
            <div className="space-y-2">
              <Label htmlFor="guide-title">Heading</Label>
              <Input
                id="guide-title"
                value={form.title}
                onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))}
                placeholder="Enable developer mode"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="guide-order">Order</Label>
              <Input
                id="guide-order"
                type="number"
                value={form.order}
                onChange={(event) => setForm((current) => ({ ...current, order: event.target.value }))}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="guide-body">Text</Label>
            <Textarea
              id="guide-body"
              value={form.body}
              onChange={(event) => setForm((current) => ({ ...current, body: event.target.value }))}
              rows={8}
              placeholder="Explain this step. Line breaks are kept on the guide page."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="guide-image">Picture link (optional)</Label>
            <Input
              id="guide-image"
              value={form.image_url}
              onChange={(event) => setForm((current) => ({ ...current, image_url: event.target.value }))}
              placeholder="https://…"
            />
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save step
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}