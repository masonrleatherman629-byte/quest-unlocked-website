import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import BuildUploadRow from "@/components/admin/BuildUploadRow";
import { uploadGameBuild } from "@/lib/game-artwork";
import { updateGame } from "@/lib/server-fns";

const nameKey = (value) => value.toLowerCase().replace(/\.[a-z0-9]+$/, "").replace(/[^a-z0-9]/g, "");

// A build is matched to a game by its file name, so a folder of builds can be
// dropped in one go; the picker on each row corrects any wrong guess.
const matchGame = (fileName, games) => {
  const key = nameKey(fileName);
  if (key.length < 3) return "";
  let best = null;
  for (const game of games) {
    const title = nameKey(game.title || "");
    if (title.length < 3) continue;
    if (key === title || key.startsWith(title) || title.startsWith(key)) {
      if (!best || title.length > nameKey(best.title).length) best = game;
    }
  }
  return best?.id || "";
};

export default function MultiBuildUploadDialog({ open, onOpenChange, games, onUploaded }) {
  const update = useServerFn(updateGame);
  const [rows, setRows] = useState([]);
  const [running, setRunning] = useState(false);

  const setRow = (id, patch) =>
    setRows((current) => current.map((row) => (row.id === id ? { ...row, ...patch } : row)));

  const addFiles = (fileList) => {
    const picked = [...fileList].map((file) => ({
      id: crypto.randomUUID(),
      file,
      gameId: matchGame(file.name, games),
      status: "Waiting",
      message: "",
    }));
    setRows((current) => [...current, ...picked]);
  };

  const pending = rows.filter((row) => row.status !== "Done" && row.gameId);

  const run = async () => {
    if (!pending.length || running) return;
    setRunning(true);
    let done = 0;
    for (const row of pending) {
      setRow(row.id, { status: "Uploading" });
      try {
        const build = await uploadGameBuild(row.file);
        await update({ data: { id: row.gameId, ...build, upload_status: "Ready" } });
        setRow(row.id, { status: "Done", message: "" });
        done += 1;
      } catch (err) {
        setRow(row.id, { status: "Failed", message: err?.message || "The upload failed." });
      }
    }
    setRunning(false);
    if (done) {
      toast.success(`${done} ${done === 1 ? "build" : "builds"} uploaded.`);
      onUploaded();
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (running) return;
        if (!next) setRows([]);
        onOpenChange(next);
      }}
    >
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-heading">Upload builds</DialogTitle>
          <DialogDescription>
            Pick several build files at once. Each one is matched to a game by its file name, and you
            can change the game on any row before uploading.
          </DialogDescription>
        </DialogHeader>

        <Button asChild variant="outline" className="w-full" disabled={running}>
          <label className="cursor-pointer">
            <Upload className="mr-2 h-4 w-4" />
            Choose build files
            <input
              type="file"
              multiple
              className="hidden"
              accept=".zip,.apk,.obb,.rar,.7z,.tar,.gz"
              onChange={(event) => {
                addFiles(event.target.files || []);
                event.target.value = "";
              }}
            />
          </label>
        </Button>

        {rows.length > 0 && (
          <ul className="divide-y divide-border/70 rounded-lg border border-border bg-background px-3">
            {rows.map((row) => (
              <BuildUploadRow
                key={row.id}
                row={row}
                games={games}
                disabled={running}
                onPick={(gameId) => setRow(row.id, { gameId, status: "Waiting", message: "" })}
              />
            ))}
          </ul>
        )}

        <DialogFooter>
          <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} disabled={running}>
            Close
          </Button>
          <Button type="button" onClick={run} disabled={running || !pending.length}>
            {running && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Upload {pending.length || ""} {pending.length === 1 ? "build" : "builds"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}