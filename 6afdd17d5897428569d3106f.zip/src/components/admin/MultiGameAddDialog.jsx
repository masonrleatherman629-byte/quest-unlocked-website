import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toGamePayload } from "@/lib/game-payload";
import { createGame, lookupStoreLink } from "@/lib/server-fns";

const STATUS_TONE = {
  Added: "text-primary",
  Updated: "text-primary",
  Failed: "text-destructive",
  Reading: "text-muted-foreground",
  Waiting: "text-muted-foreground",
};

// Several store listings at once: each link is read and added on its own, so one
// bad link never stops the rest.
export default function MultiGameAddDialog({ open, onOpenChange, onAdded }) {
  const lookup = useServerFn(lookupStoreLink);
  const create = useServerFn(createGame);
  const [text, setText] = useState("");
  const [rows, setRows] = useState([]);
  const [running, setRunning] = useState(false);

  const links = [...new Set(text.split(/\s+/).map((value) => value.trim()).filter((value) => /^https?:\/\//i.test(value)))];

  const setRow = (index, patch) =>
    setRows((current) => current.map((row, position) => (position === index ? { ...row, ...patch } : row)));

  const run = async () => {
    if (!links.length || running) return;
    setRunning(true);
    setRows(links.map((url) => ({ url, status: "Waiting", message: "" })));
    for (let index = 0; index < links.length; index += 1) {
      setRow(index, { status: "Reading" });
      try {
        const details = await lookup({ data: { url: links[index] } });
        if (!details?.title) throw new Error("Nothing could be read from that link.");
        const { game, merged } = await create({
          data: toGamePayload({ ...details, status: details.status || "Not in library" }),
        });
        setRow(index, { status: merged ? "Updated" : "Added", message: game?.title || details.title });
      } catch (err) {
        setRow(index, { status: "Failed", message: err?.message || "That link could not be added." });
      }
    }
    setRunning(false);
    onAdded();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-heading">Add several games</DialogTitle>
          <DialogDescription>
            Paste one Meta Quest Store link per line. Each one is added as its own library entry.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          <Label htmlFor="multi-links">Store links</Label>
          <Textarea
            id="multi-links"
            value={text}
            onChange={(event) => setText(event.target.value)}
            rows={6}
            placeholder={"https://www.meta.com/experiences/…\nhttps://www.meta.com/experiences/…"}
            disabled={running}
          />
          <p className="text-xs text-muted-foreground">
            {links.length} {links.length === 1 ? "link" : "links"} found. New games start as “Not in library”
            until you upload a build.
          </p>
        </div>

        {rows.length > 0 && (
          <ul className="space-y-1.5 rounded-lg border border-border bg-background p-3">
            {rows.map((row) => (
              <li key={row.url} className="flex items-start gap-2 text-xs">
                {row.status === "Reading" ? (
                  <Loader2 className="mt-0.5 h-3.5 w-3.5 shrink-0 animate-spin text-muted-foreground" />
                ) : row.status === "Failed" ? (
                  <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-destructive" />
                ) : row.status === "Waiting" ? (
                  <span className="mt-0.5 h-3.5 w-3.5 shrink-0 rounded-full border border-border" />
                ) : (
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                )}
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-foreground">{row.message || row.url}</span>
                  <span className={STATUS_TONE[row.status]}>{row.status}</span>
                </span>
              </li>
            ))}
          </ul>
        )}

        <DialogFooter>
          <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} disabled={running}>
            Close
          </Button>
          <Button type="button" onClick={run} disabled={running || !links.length}>
            {running && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Add {links.length || ""} {links.length === 1 ? "game" : "games"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}