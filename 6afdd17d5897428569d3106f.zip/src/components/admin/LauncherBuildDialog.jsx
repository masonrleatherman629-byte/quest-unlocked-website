import { useEffect, useState } from "react";
import { Loader2, Upload } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { uploadGameBuild } from "@/lib/game-artwork";

const EMPTY = {
  version: "",
  notes: "",
  status: "Available",
  download_url: "",
  file_name: "",
  size_label: "",
};

export default function LauncherBuildDialog({ open, onOpenChange, platform, build, onSave }) {
  const [form, setForm] = useState(EMPTY);
  const [uploadStatus, setUploadStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setForm(build ? { ...EMPTY, ...build } : EMPTY);
    setUploadStatus("");
    setError("");
  }, [open, build]);

  const update = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));

  const handleFile = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadStatus("Uploading");
    setError("");
    try {
      const uploaded = await uploadGameBuild(file, setUploadStatus);
      setForm((current) => ({ ...current, ...uploaded }));
      setUploadStatus("Done");
    } catch (err) {
      setError(err?.message || "The installer could not be uploaded.");
      setUploadStatus("Failed");
    } finally {
      event.target.value = "";
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.download_url) {
      setError("Upload an installer for this platform first.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await onSave({ ...form, platform, id: build?.id });
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || "The build could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading">{platform} build</DialogTitle>
          <DialogDescription>Upload the Moon Launcher installer for {platform}.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="rounded-lg border border-border bg-muted/40 p-3">
            <Button asChild type="button" variant="outline" size="sm">
              <label className="cursor-pointer">
                <Upload className="mr-2 h-4 w-4" />
                {form.download_url ? "Replace installer" : "Upload installer"}
                <input type="file" className="hidden" onChange={handleFile} />
              </label>
            </Button>
            {form.file_name && (
              <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                {form.file_name} {form.size_label && `· ${form.size_label}`}
              </p>
            )}
            {uploadStatus && uploadStatus !== "Done" && (
              <p className="mt-2 font-mono text-[10px] uppercase tracking-[0.14em] text-primary">
                {uploadStatus}…
              </p>
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="launcher-version">Version</Label>
              <Input id="launcher-version" value={form.version} onChange={update("version")} placeholder="1.4.0" />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={form.status}
                onValueChange={(value) => setForm((current) => ({ ...current, status: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Available">Available</SelectItem>
                  <SelectItem value="Coming soon">Coming soon</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="launcher-notes">Install note</Label>
            <Textarea
              id="launcher-notes"
              value={form.notes}
              onChange={update("notes")}
              rows={2}
              placeholder="Optional: anything special about installing on this platform."
            />
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save build
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}