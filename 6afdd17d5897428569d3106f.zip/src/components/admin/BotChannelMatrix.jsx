import { Checkbox } from "@/components/ui/checkbox";

const EVENTS = ["New game", "Game update", "Digest", "Site online"];
const CHANNELS = [
  { key: "updates", label: "Updates" },
  { key: "leaks", label: "Leaks" },
];

// Which event reaches which channel: one tick per event and channel.
export default function BotChannelMatrix({ form, onToggle }) {
  return (
    <div className="mt-4 overflow-hidden rounded-lg border border-border">
      <div className="grid grid-cols-[1fr_auto_auto] items-center gap-3 border-b border-border bg-muted/40 px-3 py-2">
        <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
          Send to
        </span>
        {CHANNELS.map((channel) => (
          <span
            key={channel.key}
            className="w-16 text-center font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground"
          >
            {channel.label}
          </span>
        ))}
      </div>

      {EVENTS.map((event) => (
        <div
          key={event}
          className="grid grid-cols-[1fr_auto_auto] items-center gap-3 border-b border-border/70 px-3 py-2 last:border-0"
        >
          <span className="text-sm text-foreground">{event}</span>
          {CHANNELS.map((channel) => (
            <span key={channel.key} className="flex w-16 justify-center">
              <Checkbox
                checked={(form[`${channel.key}_events`] || []).includes(event)}
                onCheckedChange={() => onToggle(channel.key, event)}
                aria-label={`${event} to ${channel.label}`}
              />
            </span>
          ))}
        </div>
      ))}
    </div>
  );
}