import { Loader2, ShieldCheck, ShieldOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import UserAvatar from "@/components/profile/UserAvatar";

export default function UserRow({ user, isSelf, busy, onToggle }) {
  const isAdmin = user.role === "admin";

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/70 px-4 py-3 last:border-b-0">
      <div className="flex min-w-0 items-center gap-3">
        <UserAvatar user={user} />
        <div className="min-w-0">
          <p className="flex items-center gap-2 truncate font-heading text-sm font-medium text-foreground">
            {user.full_name || user.discord_name || "Unnamed member"}
            {isSelf && <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">you</span>}
          </p>
          <p className="truncate text-xs text-muted-foreground">{user.email}</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Badge variant={isAdmin ? "default" : "secondary"} className="text-[10px] uppercase tracking-wider">
          {isAdmin ? "Admin" : "User"}
        </Badge>
        <Button
          variant="outline"
          size="sm"
          disabled={isSelf || busy}
          onClick={() => onToggle(user, isAdmin ? "user" : "admin")}
        >
          {busy ? (
            <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
          ) : isAdmin ? (
            <ShieldOff className="mr-1.5 h-3.5 w-3.5" />
          ) : (
            <ShieldCheck className="mr-1.5 h-3.5 w-3.5" />
          )}
          {isAdmin ? "Remove admin" : "Make admin"}
        </Button>
      </div>
    </div>
  );
}