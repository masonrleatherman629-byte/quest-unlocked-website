import { Input } from "@/components/ui/input";
import { GENRES } from "@/lib/game-options";
import { cn } from "@/lib/utils";

export default function GenrePicker({ value, onChange }) {
  const selected = value
    .split(",")
    .map((genre) => genre.trim())
    .filter(Boolean);

  const toggle = (genre) => {
    const next = selected.includes(genre) ? selected.filter((item) => item !== genre) : [...selected, genre];
    onChange(next.join(", "));
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1.5">
        {GENRES.map((genre) => {
          const active = selected.includes(genre);
          return (
            <button
              key={genre}
              type="button"
              onClick={() => toggle(genre)}
              className={cn(
                "rounded-full border px-2.5 py-1 text-xs transition-colors",
                active
                  ? "border-primary/60 bg-primary/15 text-primary"
                  : "border-border bg-card text-muted-foreground hover:text-foreground"
              )}
            >
              {genre}
            </button>
          );
        })}
      </div>
      <Input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="Pick above, or type your own (comma separated)"
        aria-label="Genres"
      />
    </div>
  );
}