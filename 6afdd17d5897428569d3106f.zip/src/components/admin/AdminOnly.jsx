import { ShieldAlert } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { canUseAdminArea } from "@/lib/admin-access";

export default function AdminOnly({ children }) {
  const { user, isLoadingAuth } = useAuth();

  if (isLoadingAuth) {
    return <div className="mx-auto w-full max-w-4xl px-5 py-24 text-sm text-muted-foreground">Loading…</div>;
  }

  if (!canUseAdminArea(user)) {
    return (
      <div className="mx-auto flex w-full max-w-2xl flex-col items-center px-5 py-24 text-center">
        <ShieldAlert className="h-8 w-8 text-muted-foreground" />
        <h1 className="mt-4 font-heading text-2xl font-semibold text-foreground">Admins only</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Manage is limited to admin accounts. You can still upload games from Regular supply.
        </p>
      </div>
    );
  }

  return children;
}