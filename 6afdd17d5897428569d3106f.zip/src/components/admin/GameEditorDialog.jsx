import { useEffect, useState } from "react";
import { ImagePlus, Loader2, Plus, Trash2, Upload, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Image } from "@/components/ui/image";
import StoreLookupFields from "@/components/admin/StoreLookupFields";
import StoreLinkFill from "@/components/admin/StoreLinkFill";
import {
  uploadGameArtwork,
  uploadGameBuild,
  uploadGameObb,
  uploadGameScreenshots,
  uploadGameVideo,
} from "@/lib/game-artwork";
import GenrePicker from "@/components/admin/GenrePicker";
import VersionsEditor from "@/components/admin/VersionsEditor";
import { PLAYER_MODES, PLAYERS } from "@/lib/game-options";
import { cn } from "@/lib/utils";

const EMPTY_GAME = {
  title: "",
  developer: "",
  publisher_id: "",
  version: "",
  release_date: "",
  category: "Games",
  status: "Ready",
  languages: [],
  description: "",
  image_url: "",
  screenshots: [],
  video_urls: [],
  file_name: "",
  size_label: "",
  download_url: "",
  obb_url: "",
  obb_file_name: "",
  upload_status: "None",
  versions: [],
  player_modes: [],
  players: "Single player",
  rating: 0,
  rating_count: 0,
  rating_source: "",
  store_status: "Not on store",
  store_url: "",
  price: "",
  offline_play: false,
  content_rating: "",
};

const CATEGORIES = ["Games", "Apps", "Experiences", "Demos"];
const STATUSES = ["Ready", "Not in library", "Draft", "Archived"];

export default function GameEditorDialog({
  open,
  onOpenChange,
  game,
  publishers = [],
  onSave,
  showStoreLookup = true,
}) {
  const [form, setForm] = useState(EMPTY_GAME);
  const [genreText, setGenreText] = useState("");
  const [headsetText, setHeadsetText] = useState("");
  const [languageText, setLanguageText] = useState("");
  const [videoInput, setVideoInput] = useState("");
  const [artworkStatus, setArtworkStatus] = useState("");
  const [shotStatus, setShotStatus] = useState("");
  const [trailerStatus, setTrailerStatus] = useState("");
  const [buildStatus, setBuildStatus] = useState("");
  const [obbStatus, setObbStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setForm(
      game
        ? {
            ...EMPTY_GAME,
            ...game,
            screenshots: game.screenshots || [],
            video_urls: game.video_urls || [],
            upload_status: game.upload_status || "None",
            versions: game.versions || [],
            player_modes: game.player_modes || [],
          }
        : EMPTY_GAME
    );
    setGenreText((game?.genres || []).join(", "));
    setHeadsetText((game?.headsets || ["Quest 3", "Quest 3S", "Quest 2", "Quest Pro"]).join(", "));
    setLanguageText((game?.languages || []).join(", "));
    setVideoInput("");
    setArtworkStatus("");
    setShotStatus("");
    setTrailerStatus("");
    setBuildStatus("");
    setObbStatus("");
    setError("");
  }, [open, game]);

  const update = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));

  const handleArtwork = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setArtworkStatus("Optimising");
    setError("");
    try {
      const url = await uploadGameArtwork(file, setArtworkStatus);
      // Only this game's form takes the new URL; nothing else is touched.
      setForm((current) => ({ ...current, image_url: url }));
    } catch (err) {
      setError(err?.message || "The image could not be uploaded.");
      setArtworkStatus("Failed");
    } finally {
      event.target.value = "";
    }
  };

  const handleScreenshots = async (event) => {
    const files = [...(event.target.files || [])];
    if (!files.length) return;
    setShotStatus(`0/${files.length}`);
    setError("");
    try {
      const urls = await uploadGameScreenshots(files, setShotStatus);
      setForm((current) => ({ ...current, screenshots: [...current.screenshots, ...urls] }));
      setShotStatus("Done");
    } catch (err) {
      setError(err?.message || "The screenshots could not be uploaded.");
      setShotStatus("Failed");
    } finally {
      event.target.value = "";
    }
  };

  const handleBuild = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setBuildStatus("Uploading");
    setForm((current) => ({ ...current, upload_status: "Uploading" }));
    setError("");
    try {
      const result = await uploadGameBuild(file, setBuildStatus);
      setForm((current) => ({ ...current, ...result, upload_status: "Ready" }));
      setBuildStatus("Ready");
    } catch (err) {
      setError(err?.message || "The build could not be uploaded.");
      setBuildStatus("Failed");
      setForm((current) => ({ ...current, upload_status: "Failed" }));
    } finally {
      event.target.value = "";
    }
  };

  const handleObb = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setObbStatus("Uploading");
    setError("");
    try {
      const result = await uploadGameObb(file);
      setForm((current) => ({ ...current, ...result }));
      setObbStatus("Done");
    } catch (err) {
      setError(err?.message || "The OBB could not be uploaded.");
      setObbStatus("Failed");
    } finally {
      event.target.value = "";
    }
  };

  const handleTrailer = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setTrailerStatus("Uploading");
    setError("");
    try {
      const url = await uploadGameVideo(file, setTrailerStatus);
      setForm((current) => ({ ...current, video_urls: [...current.video_urls, url] }));
      setTrailerStatus("Done");
    } catch (err) {
      setError(err?.message || "The trailer could not be uploaded.");
      setTrailerStatus("Failed");
    } finally {
      event.target.value = "";
    }
  };

  const addVideo = () => {
    const url = videoInput.trim();
    if (!url) return;
    setForm((current) => ({ ...current, video_urls: [...current.video_urls, url] }));
    setVideoInput("");
  };

  const removeShot = (index) =>
    setForm((current) => ({ ...current, screenshots: current.screenshots.filter((_, i) => i !== index) }));

  const removeVideo = (index) =>
    setForm((current) => ({ ...current, video_urls: current.video_urls.filter((_, i) => i !== index) }));

  // A pasted store link fills the form; genres live in their own text field.
  const applyStoreDetails = (details) => {
    setForm((current) => ({ ...current, ...details }));
    if ((details.genres || []).length) setGenreText(details.genres.join(", "));
    if ((details.languages || []).length) setLanguageText(details.languages.join(", "));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.title.trim()) {
      setError("A title is required.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await onSave({
        ...form,
        title: form.title.trim(),
        genres: genreText.split(",").map((value) => value.trim()).filter(Boolean),
        languages: languageText.split(",").map((value) => value.trim()).filter(Boolean),
        headsets: headsetText.split(",").map((value) => value.trim()).filter(Boolean),
      });
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || "The game could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-heading">
            {game?.id ? `Edit ${game.title}` : "Add a game"}
          </DialogTitle>
          <DialogDescription>
            {game?.id ? "Changes are saved to this game only." : "Publish a new build to the library."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <StoreLinkFill onFill={applyStoreDetails} />

          <div className="space-y-2">
            <Label>Cover artwork</Label>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="aspect-[4/3] w-full overflow-hidden rounded-lg border border-border bg-muted sm:w-52">
                {form.image_url ? (
                  <Image
                    src={form.image_url}
                    alt="Artwork preview"
                    className="h-full w-full object-cover"
                    fittingType="fill"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                    No artwork
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Button asChild type="button" variant="outline" size="sm">
                  <label className="cursor-pointer">
                    <ImagePlus className="mr-2 h-4 w-4" />
                    {form.image_url ? "Replace artwork" : "Upload artwork"}
                    <input type="file" accept="image/*" className="hidden" onChange={handleArtwork} />
                  </label>
                </Button>
                {artworkStatus && artworkStatus !== "Done" && (
                  <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">{artworkStatus}…</p>
                )}
                <p className="text-xs text-muted-foreground">Each upload gets its own file name.</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Screenshots</Label>
              <Button asChild type="button" variant="ghost" size="sm">
                <label className="cursor-pointer">
                  <ImagePlus className="mr-2 h-3.5 w-3.5" />
                  Add shots
                  <input type="file" accept="image/*" multiple className="hidden" onChange={handleScreenshots} />
                </label>
              </Button>
            </div>
            {shotStatus && shotStatus !== "Done" && (
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">Uploading {shotStatus}</p>
            )}
            {form.screenshots.length ? (
              <div className="flex flex-wrap gap-2">
                {form.screenshots.map((src, index) => (
                  <div key={`${src}-${index}`} className="relative h-16 w-24 overflow-hidden rounded-md border border-border">
                    <Image src={src} alt={`Screenshot ${index + 1}`} className="h-full w-full object-cover" fittingType="fill" />
                    <button
                      type="button"
                      onClick={() => removeShot(index)}
                      className="absolute right-1 top-1 rounded-full bg-background/90 p-0.5 text-muted-foreground hover:text-destructive"
                      aria-label="Remove screenshot"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">No screenshots yet.</p>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="video-input">Trailers & videos</Label>
              <Button asChild type="button" variant="ghost" size="sm">
                <label className="cursor-pointer">
                  <Upload className="mr-2 h-3.5 w-3.5" />
                  {trailerStatus === "Uploading" ? "Uploading…" : "Upload trailer"}
                  <input type="file" accept="video/*" className="hidden" onChange={handleTrailer} />
                </label>
              </Button>
            </div>
            {trailerStatus && trailerStatus !== "Done" && trailerStatus !== "Uploading" && (
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-destructive">{trailerStatus}</p>
            )}
            <div className="flex gap-2">
              <Input
                id="video-input"
                value={videoInput}
                onChange={(event) => setVideoInput(event.target.value)}
                placeholder="https://…/trailer.mp4 or a video page link"
              />
              <Button type="button" variant="outline" onClick={addVideo} aria-label="Add video link">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {form.video_urls.length > 0 && (
              <ul className="space-y-1.5">
                {form.video_urls.map((url, index) => (
                  <li
                    key={`${url}-${index}`}
                    className="flex items-center justify-between gap-2 rounded-md border border-border bg-background px-3 py-1.5"
                  >
                    <span className="truncate font-mono text-[11px] text-muted-foreground">{url}</span>
                    <button
                      type="button"
                      onClick={() => removeVideo(index)}
                      className="text-muted-foreground hover:text-destructive"
                      aria-label="Remove video"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input id="title" value={form.title} onChange={update("title")} placeholder="PhysixLab" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="developer">Developer</Label>
              <Input id="developer" value={form.developer} onChange={update("developer")} placeholder="Studio name" />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>Publisher</Label>
              <Select
                value={form.publisher_id || "none"}
                onValueChange={(value) =>
                  setForm((current) => ({ ...current, publisher_id: value === "none" ? "" : value }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="No publisher" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No publisher</SelectItem>
                  {publishers.map((publisher) => (
                    <SelectItem key={publisher.id} value={publisher.id}>
                      {publisher.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="version">Version</Label>
              <Input id="version" value={form.version} onChange={update("version")} placeholder="1.0.0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="release-date">Release date</Label>
              <Input
                id="release-date"
                type="date"
                value={form.release_date || ""}
                onChange={update("release_date")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="size">Build size</Label>
              <Input id="size" value={form.size_label} onChange={update("size_label")} placeholder="619 MB" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price">Price</Label>
              <Input id="price" value={form.price || ""} onChange={update("price")} placeholder="$4.99 or Free" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="content-rating">Content rating</Label>
              <Input
                id="content-rating"
                value={form.content_rating || ""}
                onChange={update("content_rating")}
                placeholder="PEGI 18 · Extreme Violence"
              />
            </div>
            <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-background px-3 py-2 sm:col-span-2">
              <div>
                <Label htmlFor="offline-play">Offline play</Label>
                <p className="text-xs text-muted-foreground">Shown as an Offline Play tag on the card.</p>
              </div>
              <Switch
                id="offline-play"
                checked={!!form.offline_play}
                onCheckedChange={(checked) => setForm((current) => ({ ...current, offline_play: checked }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(value) => setForm((c) => ({ ...c, category: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(value) => setForm((c) => ({ ...c, status: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUSES.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Players</Label>
              <Select value={form.players} onValueChange={(value) => setForm((c) => ({ ...c, players: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PLAYERS.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>Supported play modes</Label>
              <div className="flex flex-wrap gap-1.5">
                {PLAYER_MODES.map((mode) => {
                  const active = (form.player_modes || []).includes(mode);
                  return (
                    <button
                      key={mode}
                      type="button"
                      onClick={() =>
                        setForm((current) => ({
                          ...current,
                          player_modes: active
                            ? (current.player_modes || []).filter((item) => item !== mode)
                            : [...(current.player_modes || []), mode],
                        }))
                      }
                      className={cn(
                        "rounded-full border px-3 py-1 text-xs transition-colors",
                        active
                          ? "border-primary/60 bg-primary/15 text-primary"
                          : "border-border bg-card text-muted-foreground hover:text-foreground"
                      )}
                    >
                      {mode}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="genres">Genres</Label>
              <GenrePicker value={genreText} onChange={setGenreText} />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={form.description}
                onChange={update("description")}
                rows={5}
                placeholder="What makes this build worth installing?"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="headsets">Compatible headsets</Label>
              <Input
                id="headsets"
                value={headsetText}
                onChange={(event) => setHeadsetText(event.target.value)}
                placeholder="Quest 3, Quest 2"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="languages">Languages</Label>
              <Input
                id="languages"
                value={languageText}
                onChange={(event) => setLanguageText(event.target.value)}
                placeholder="English, French, Japanese"
              />
              <p className="text-xs text-muted-foreground">Comma separated, shown on the game page.</p>
            </div>
          </div>

          {showStoreLookup && <StoreLookupFields form={form} setForm={setForm} />}

          <div className="space-y-2 rounded-lg border border-border bg-background p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <Label>Build file</Label>
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                Upload status: {form.upload_status}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button asChild type="button" variant="outline" size="sm">
                <label className="cursor-pointer">
                  <Upload className="mr-2 h-3.5 w-3.5" />
                  {buildStatus === "Uploading" ? "Uploading…" : "Upload build"}
                  <input
                    type="file"
                    accept=".zip,.apk,.obb,.rar,.7z,.tar,.gz"
                    className="hidden"
                    onChange={handleBuild}
                  />
                </label>
              </Button>
              {form.file_name && (
                <span className="truncate font-mono text-[11px] text-muted-foreground">
                  {form.file_name} {form.size_label ? `· ${form.size_label}` : ""}
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button asChild type="button" variant="outline" size="sm">
                <label className="cursor-pointer">
                  <Upload className="mr-2 h-3.5 w-3.5" />
                  {obbStatus === "Uploading" ? "Uploading…" : form.obb_url ? "Replace OBB" : "Upload OBB"}
                  <input type="file" accept=".obb" className="hidden" onChange={handleObb} />
                </label>
              </Button>
              {form.obb_file_name && (
                <span className="truncate font-mono text-[11px] text-muted-foreground">{form.obb_file_name}</span>
              )}
              <span className="text-xs text-muted-foreground">
                Optional, for APK + OBB builds. Keep the main.&lt;version&gt;.&lt;package&gt;.obb name.
              </span>
            </div>
            {buildStatus && buildStatus !== "Done" && (
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">{buildStatus}…</p>
            )}
            <div className="grid gap-3 sm:grid-cols-2">
              <Input
                value={form.file_name}
                onChange={update("file_name")}
                placeholder="com.studio.game.zip"
                aria-label="Build file name"
              />
              <Input
                value={form.download_url}
                onChange={update("download_url")}
                placeholder="https://…"
                aria-label="Download URL"
              />
            </div>
          </div>

          <VersionsEditor
            value={form.versions || []}
            onChange={(versions) => setForm((current) => ({ ...current, versions }))}
          />

          {error && <p className="text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {game?.id ? "Save changes" : "Add to library"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}