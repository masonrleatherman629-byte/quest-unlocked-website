import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { fetchGameVersions } from "@/lib/server-fns";

const STATUSES = ["Released", "In Archive", "Outdated"];

const EMPTY_ROW = {
  version_name: "",
  version_code: "",
  size_label: "",
  release_date: "",
  status: "Outdated",
  source: "Manual",
};

const byNewest = (a, b) => (b.release_date || "").localeCompare(a.release_date || "");

// Imported rows replace a manual row for the same version instead of doubling it.
const mergeRows = (current, incoming) => {
  const merged = new Map();
  for (const row of [...current, ...incoming]) {
    if (!row.version_name) continue;
    merged.set(row.version_name, row);
  }
  return [...merged.values()].sort(byNewest);
};

export default function VersionsEditor({ value = [], onChange }) {
  const [url, setUrl] = useState("");
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState("");
  const fetchVersions = useServerFn(fetchGameVersions);

  const rows = value || [];

  const updateRow = (index, key, next) =>
    onChange(rows.map((row, i) => (i === index ? { ...row, [key]: next } : row)));

  const addRow = () => onChange([...rows, { ...EMPTY_ROW }]);

  const removeRow = (index) => onChange(rows.filter((_, i) => i !== index));

  const handleImport = async () => {
    if (!url.trim()) return;
    setImporting(true);
    setError("");
    try {
      const { rows: imported } = await fetchVersions({ data: { url: url.trim() } });
      onChange(mergeRows(rows, imported));
      setUrl("");
    } catch (err) {
      setError(err?.message || "That version list could not be read.");
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-3 rounded-lg border border-border bg-background p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Label>Versions</Label>
        <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
          {rows.length} {rows.length === 1 ? "row" : "rows"}
        </span>
      </div>

      {rows.length > 0 && (
        <div className="space-y-2">
          {rows.map((row, index) => (
            <div key={index} className="grid gap-2 sm:grid-cols-[1.1fr_0.7fr_0.8fr_1fr_1fr_auto]">
              <Input
                value={row.version_name || ""}
                onChange={(event) => updateRow(index, "version_name", event.target.value)}
                placeholder="0.1.3"
                aria-label="Version name"
              />
              <Input
                value={row.version_code || ""}
                onChange={(event) => updateRow(index, "version_code", event.target.value)}
                placeholder="13"
                aria-label="Version code"
              />
              <Input
                value={row.size_label || ""}
                onChange={(event) => updateRow(index, "size_label", event.target.value)}
                placeholder="672 MB"
                aria-label="Size"
              />
              <Input
                type="date"
                value={row.release_date || ""}
                onChange={(event) => updateRow(index, "release_date", event.target.value)}
                aria-label="Release date"
              />
              <Select value={row.status || "Outdated"} onValueChange={(next) => updateRow(index, "status", next)}>
                <SelectTrigger aria-label="Status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUSES.map((status) => (
                    <SelectItem key={status} value={status}>
                      {status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => removeRow(index)}
                aria-label="Remove version"
              >
                <Trash2 className="h-4 w-4 text-muted-foreground" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <Button type="button" variant="outline" size="sm" onClick={addRow}>
          <Plus className="mr-2 h-3.5 w-3.5" />
          Add version
        </Button>
        <Input
          value={url}
          onChange={(event) => setUrl(event.target.value)}
          placeholder="Paste a listing page with a version table"
          className="min-w-[220px] flex-1"
          aria-label="Version list link"
        />
        <Button type="button" variant="outline" size="sm" onClick={handleImport} disabled={importing || !url.trim()}>
          {importing && <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />}
          Import from link
        </Button>
      </div>

      {error && <p className="text-xs text-destructive">{error}</p>}
      <p className="text-xs text-muted-foreground">
        Every build you post adds its version here automatically. Older releases turn outdated.
      </p>
    </div>
  );
}