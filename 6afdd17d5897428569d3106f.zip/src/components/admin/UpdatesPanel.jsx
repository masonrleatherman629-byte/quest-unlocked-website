import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import UpdateCard from "@/components/updates/UpdateCard";
import { createUpdate, deleteUpdate } from "@/lib/server-fns";

const KINDS = ["Release", "Patch", "Note"];

export default function UpdatesPanel({ updates }) {
  const router = useRouter();
  const create = useServerFn(createUpdate);
  const remove = useServerFn(deleteUpdate);

  const [form, setForm] = useState({ title: "", body: "", kind: "Note" });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    if (!form.title.trim() || !form.body.trim()) {
      setError("A title and a body are both needed.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await create({ data: { ...form, title: form.title.trim(), body: form.body.trim() } });
      setForm({ title: "", body: "", kind: "Note" });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "The update could not be posted.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    await remove({ data: { id } });
    await router.invalidate();
  };

  return (
    <div className="space-y-8">
      <form onSubmit={submit} className="space-y-4 rounded-xl border border-border bg-card p-5">
        <div className="grid gap-4 sm:grid-cols-[1fr_140px]">
          <div className="space-y-2">
            <Label htmlFor="update-title">Headline</Label>
            <Input
              id="update-title"
              value={form.title}
              onChange={(event) => setForm((c) => ({ ...c, title: event.target.value }))}
              placeholder="Gas N Cars VR Halloween build is live"
            />
          </div>
          <div className="space-y-2">
            <Label>Kind</Label>
            <Select value={form.kind} onValueChange={(value) => setForm((c) => ({ ...c, kind: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {KINDS.map((kind) => (
                  <SelectItem key={kind} value={kind}>
                    {kind}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="update-body">Body</Label>
          <Textarea
            id="update-body"
            value={form.body}
            onChange={(event) => setForm((c) => ({ ...c, body: event.target.value }))}
            rows={4}
            placeholder="What changed?"
          />
        </div>
        {error && <p className="text-sm text-destructive">{error}</p>}
        <Button type="submit" disabled={saving}>
          {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Post update
        </Button>
      </form>

      <div className="space-y-3">
        {updates.map((update) => (
          <div key={update.id} className="relative">
            <UpdateCard update={update} />
            <button
              type="button"
              onClick={() => handleDelete(update.id)}
              className="absolute right-4 top-4 text-muted-foreground transition-colors hover:text-destructive"
              aria-label="Delete update"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}