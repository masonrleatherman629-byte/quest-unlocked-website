import { useEffect, useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Bot, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import BotChannelMatrix from "@/components/admin/BotChannelMatrix";
import BotMessageComposer from "@/components/admin/BotMessageComposer";
import { saveBotConfig } from "@/lib/bot-config-fns";

// The bot's settings, kept with the rest of Manage: what posts, where, and as whom.
export default function DiscordBotPanel({ config }) {
  const router = useRouter();
  const save = useServerFn(saveBotConfig);
  const [form, setForm] = useState(config);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => setForm(config), [config]);

  const set = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  const toggleEvent = (channel, event) =>
    setForm((current) => {
      const key = `${channel}_events`;
      const currentEvents = current[key] || [];
      return {
        ...current,
        [key]: currentEvents.includes(event)
          ? currentEvents.filter((item) => item !== event)
          : [...currentEvents, event],
      };
    });

  const submit = async (event) => {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      await save({ data: form });
      await router.invalidate();
      toast.success("Bot settings saved.");
    } catch (err) {
      setError(err?.message || "The bot settings could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-4 rounded-xl border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <Bot className="mt-0.5 h-4 w-4 shrink-0 text-discord" />
          <div>
            <h2 className="font-heading text-sm font-semibold text-foreground">Discord bot</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Choose which events post to the updates and leaks channels, and how the bot looks.
            </p>
          </div>
        </div>
        <Switch
          checked={form.enabled}
          onCheckedChange={(value) => set("enabled", value)}
          aria-label="Bot is posting"
        />
      </div>

      <form onSubmit={submit} className="mt-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="bot-name">Bot name</Label>
            <Input
              id="bot-name"
              value={form.bot_name}
              onChange={(event) => set("bot_name", event.target.value)}
              maxLength={60}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="bot-avatar">Bot picture link</Label>
            <Input
              id="bot-avatar"
              value={form.bot_avatar_url}
              onChange={(event) => set("bot_avatar_url", event.target.value)}
              placeholder="https://…"
            />
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-6">
          <label className="flex items-center gap-2 text-sm text-foreground">
            <Switch
              checked={form.include_image}
              onCheckedChange={(value) => set("include_image", value)}
              aria-label="Include game artwork"
            />
            Include game artwork
          </label>
          <label className="flex items-center gap-2 text-sm text-foreground">
            <Switch
              checked={form.ping_role}
              onCheckedChange={(value) => set("ping_role", value)}
              aria-label="Ping the community role"
            />
            Ping the community role
          </label>
        </div>

        <BotChannelMatrix form={form} onToggle={toggleEvent} />

        {error && <p className="mt-2 text-xs text-destructive">{error}</p>}

        <div className="mt-3 flex items-center gap-3">
          <Button type="submit" size="sm" disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save bot settings
          </Button>
          <span className="text-xs text-muted-foreground">
            {form.enabled ? "The bot is posting" : "The bot is paused"}
          </span>
        </div>
      </form>

      <BotMessageComposer />
    </div>
  );
}