import { useEffect, useState } from "react";
import { ImagePlus, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Image } from "@/components/ui/image";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { uploadGameArtwork } from "@/lib/game-artwork";

const ROLES = ["Admin", "Helper", "Tester"];

const EMPTY_MEMBER = {
  name: "",
  role: "Helper",
  text: "",
  avatar_url: "",
  order: undefined,
};

export default function TeamMemberDialog({ open, onOpenChange, member, onSave }) {
  const [form, setForm] = useState(EMPTY_MEMBER);
  const [uploadStatus, setUploadStatus] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setForm(member ? { ...EMPTY_MEMBER, ...member } : EMPTY_MEMBER);
    setUploadStatus("");
    setError("");
  }, [open, member]);

  const update = (key) => (event) =>
    setForm((current) => ({ ...current, [key]: event.target.value }));

  const handleAvatar = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadStatus("Uploading");
    setError("");
    try {
      const url = await uploadGameArtwork(file, setUploadStatus);
      setForm((current) => ({ ...current, avatar_url: url }));
      setUploadStatus("Done");
    } catch (err) {
      setError(err?.message || "The picture could not be uploaded.");
      setUploadStatus("Failed");
    } finally {
      event.target.value = "";
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.name.trim()) {
      setError("A name is required.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await onSave({
        id: form.id,
        name: form.name.trim(),
        role: form.role || "Helper",
        text: form.text,
        avatar_url: form.avatar_url,
        order: form.order === "" || form.order === undefined ? undefined : Number(form.order),
      });
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || "That person could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading">
            {member?.id ? `Edit ${member.name}` : "Add a team member"}
          </DialogTitle>
          <DialogDescription>
            The picture and the text under it are what the team page shows.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="flex items-center gap-4">
            <div className="h-20 w-20 shrink-0 overflow-hidden rounded-full border border-border bg-muted">
              {form.avatar_url ? (
                <Image
                  src={form.avatar_url}
                  alt="Picture preview"
                  className="h-full w-full object-cover"
                  fittingType="fill"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                  Photo
                </div>
              )}
            </div>
            <div className="space-y-1">
              <Button asChild type="button" variant="outline" size="sm">
                <label className="cursor-pointer">
                  <ImagePlus className="mr-2 h-4 w-4" />
                  {form.avatar_url ? "Replace picture" : "Upload picture"}
                  <input type="file" accept="image/*" className="hidden" onChange={handleAvatar} />
                </label>
              </Button>
              {uploadStatus && uploadStatus !== "Done" && (
                <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">
                  {uploadStatus}…
                </p>
              )}
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="member-name">Name</Label>
              <Input
                id="member-name"
                value={form.name}
                onChange={update("name")}
                placeholder="rad"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="member-role">Role</Label>
              <Select
                value={form.role}
                onValueChange={(value) => setForm((current) => ({ ...current, role: value }))}
              >
                <SelectTrigger id="member-role">
                  <SelectValue placeholder="Helper" />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="member-text">Text under the picture</Label>
            <Textarea
              id="member-text"
              value={form.text}
              onChange={update("text")}
              rows={3}
              placeholder="Runs the library, tests every build on Quest 3."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="member-order">Position on the page</Label>
            <Input
              id="member-order"
              type="number"
              min={0}
              value={form.order ?? ""}
              onChange={update("order")}
              placeholder="Lowest first"
            />
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {member?.id ? "Save changes" : "Add member"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}