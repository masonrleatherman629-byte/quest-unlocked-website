import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Send, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { autoPostBotMessage, sendBotMessage } from "@/lib/bot-config-fns";

// A message written by hand: goes out the moment it is sent, picture included.
export default function BotMessageComposer() {
  const send = useServerFn(sendBotMessage);
  const autoPost = useServerFn(autoPostBotMessage);
  const [channel, setChannel] = useState("updates");
  const [message, setMessage] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [sending, setSending] = useState(false);
  const [drafting, setDrafting] = useState(false);
  const [error, setError] = useState("");

  // One click: the post is written from the library and sent straight out.
  const autoSend = async () => {
    setDrafting(true);
    setError("");
    try {
      const result = await autoPost({ data: { channel } });
      toast.success(
        result.messages > 1
          ? `Sent to ${channel} in ${result.messages} messages.`
          : `Sent to ${channel}.`
      );
      setMessage("");
      setImageUrl("");
    } catch (err) {
      setError(err?.message || "The message could not be sent.");
    } finally {
      setDrafting(false);
    }
  };

  const submit = async (event) => {
    event.preventDefault();
    if (!message.trim()) {
      setError("Press Auto-write to fill the message, or type one, then send.");
      return;
    }
    setSending(true);
    setError("");
    try {
      await send({ data: { channel, message, image_url: imageUrl } });
      toast.success(`Sent to ${channel}.`);
      setMessage("");
      setImageUrl("");
    } catch (err) {
      setError(err?.message || "The message could not be sent.");
    } finally {
      setSending(false);
    }
  };

  return (
    <form onSubmit={submit} className="mt-4 rounded-lg border border-border bg-muted/20 p-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-heading text-sm font-semibold text-foreground">Send a message now</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Auto-write builds the post from your newest games and sends it. You can also type your own.
          </p>
        </div>
        <Button type="button" variant="outline" size="sm" onClick={autoSend} disabled={drafting}>
          {drafting ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Sparkles className="mr-2 h-4 w-4" />
          )}
          Auto-write &amp; send
        </Button>
      </div>

      <div className="mt-3 space-y-2">
        <Label htmlFor="bot-channel">Channel</Label>
        <Select value={channel} onValueChange={setChannel}>
          <SelectTrigger id="bot-channel">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="updates">Updates</SelectItem>
            <SelectItem value="leaks">Leaks</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="mt-3 space-y-2">
        <Label htmlFor="bot-message">Message</Label>
        <Textarea
          id="bot-message"
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          rows={3}
          maxLength={3800}
          placeholder="What the bot should say"
          className="resize-none"
        />
      </div>

      <div className="mt-3 space-y-2">
        <Label htmlFor="bot-image">Image link</Label>
        <Input
          id="bot-image"
          value={imageUrl}
          onChange={(event) => setImageUrl(event.target.value)}
          placeholder="Optional picture shown with the message"
        />
      </div>

      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}

      <Button type="submit" size="sm" className="mt-3" disabled={sending}>
        {sending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
        Send
      </Button>
    </form>
  );
}