import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Store } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PLAYER_MODES, PLAYERS, STORE_STATUSES } from "@/lib/game-options";
import { lookupQuestStore } from "@/lib/server-fns";

export default function StoreLookupFields({ form, setForm }) {
  const lookup = useServerFn(lookupQuestStore);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");

  const set = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));

  const runLookup = async () => {
    if (!form.title.trim()) {
      setError("Add a title before looking it up.");
      return;
    }
    setError("");
    setStatus("Checking the store");
    try {
      const result = await lookup({
        data: { title: form.title.trim(), developer: form.developer || undefined },
      });
      setForm((current) => {
        const modes = (result?.player_modes || []).filter((mode) => PLAYER_MODES.includes(mode));
        return {
          ...current,
          rating: typeof result?.rating === "number" ? result.rating : current.rating,
          rating_count: typeof result?.rating_count === "number" ? result.rating_count : current.rating_count,
          store_status: STORE_STATUSES.includes(result?.store_status)
            ? result.store_status
            : current.store_status,
          store_url: result?.store_url || current.store_url,
          players: PLAYERS.includes(result?.players) ? result.players : current.players,
          player_modes: modes.length ? modes : current.player_modes,
          rating_source: "Meta Quest Store",
        };
      });
      setStatus("Filled from the store");
    } catch (err) {
      setError(err?.message || "The lookup failed. Fill the numbers in by hand.");
      setStatus("");
    }
  };

  return (
    <div className="space-y-3 rounded-lg border border-border bg-background p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Label>Store listing & ratings</Label>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={runLookup}
          disabled={status === "Checking the store"}
        >
          {status === "Checking the store" ? (
            <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />
          ) : (
            <Store className="mr-2 h-3.5 w-3.5" />
          )}
          Look up on Quest Store
        </Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-2">
          <Label>Published on the store</Label>
          <Select
            value={form.store_status}
            onValueChange={(value) => setForm((current) => ({ ...current, store_status: value }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {STORE_STATUSES.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="store-url">Store link</Label>
          <Input
            id="store-url"
            value={form.store_url}
            onChange={set("store_url")}
            placeholder="https://www.meta.com/experiences/…"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="rating">Rating (0–5)</Label>
          <Input
            id="rating"
            type="number"
            min="0"
            max="5"
            step="0.1"
            value={form.rating}
            onChange={(event) => setForm((current) => ({ ...current, rating: Number(event.target.value) }))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="rating-count">Number of ratings</Label>
          <Input
            id="rating-count"
            type="number"
            min="0"
            value={form.rating_count}
            onChange={(event) =>
              setForm((current) => ({ ...current, rating_count: Number(event.target.value) }))
            }
          />
        </div>
      </div>

      {status && status !== "Checking the store" && (
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">{status}</p>
      )}
      {error && <p className="text-xs text-destructive">{error}</p>}
      <p className="text-xs text-muted-foreground">
        The lookup reads this game's listing from the Quest Store DB catalogue, and searches the web when it has none. Check the numbers before saving.
      </p>
    </div>
  );
}