import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// One picked build file: its name, size, and the game it will be attached to.
export default function BuildUploadRow({ row, games, disabled, onPick }) {
  const megabytes = `${(row.file.size / (1024 * 1024)).toFixed(0)} MB`;
  const detail = row.status === "Failed" ? row.message : row.status === "Done" ? "Uploaded" : megabytes;

  return (
    <li className="flex items-center gap-3 py-2">
      {row.status === "Uploading" ? (
        <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-muted-foreground" />
      ) : row.status === "Done" ? (
        <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-primary" />
      ) : row.status === "Failed" ? (
        <XCircle className="h-3.5 w-3.5 shrink-0 text-destructive" />
      ) : (
        <span className="h-3.5 w-3.5 shrink-0 rounded-full border border-border" />
      )}

      <span className="min-w-0 flex-1">
        <span className="block truncate text-xs text-foreground">{row.file.name}</span>
        <span
          className={`block truncate text-[11px] ${
            row.status === "Failed" ? "text-destructive" : "text-muted-foreground"
          }`}
        >
          {detail}
        </span>
      </span>

      <Select
        value={row.gameId || undefined}
        onValueChange={onPick}
        disabled={disabled || row.status === "Done"}
      >
        <SelectTrigger className="h-8 w-[190px] shrink-0 text-xs" aria-label="Game for this build">
          <SelectValue placeholder="Pick a game" />
        </SelectTrigger>
        <SelectContent>
          {games.map((game) => (
            <SelectItem key={game.id} value={game.id} className="text-xs">
              {game.title}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </li>
  );
}