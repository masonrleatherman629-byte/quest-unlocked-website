import { Link } from "@tanstack/react-router";
import { Layers } from "lucide-react";
import { Image } from "@/components/ui/image";
import { Badge } from "@/components/ui/badge";

export default function BundleCard({ bundle, count = 0 }) {
  return (
    <Link
      to="/bundles/$bundleId"
      params={{ bundleId: bundle.id }}
      className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-colors hover:border-primary/50"
    >
      <div className="relative aspect-[16/9] w-full overflow-hidden bg-muted">
        {bundle.image_url ? (
          <Image
            src={bundle.image_url}
            alt={`${bundle.title} artwork`}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
            fittingType="fill"
          />
        ) : (
          <div className="flex h-full items-center justify-center font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            No artwork
          </div>
        )}
        <Badge className="absolute left-3 top-3 border-0 bg-background/85 text-[11px] font-medium uppercase tracking-wider text-foreground backdrop-blur">
          {count} {count === 1 ? "game" : "games"}
        </Badge>
        <Badge className="absolute right-3 top-3 border-0 bg-primary text-[10px] font-semibold uppercase tracking-[0.14em] text-primary-foreground">
          Bundle
        </Badge>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="font-heading text-lg font-semibold text-foreground">{bundle.title}</h3>
        {bundle.description && (
          <p className="line-clamp-2 text-sm leading-relaxed text-muted-foreground">{bundle.description}</p>
        )}
        <span className="mt-auto flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-primary">
          <Layers className="h-3.5 w-3.5" />
          View bundle
        </span>
      </div>
    </Link>
  );
}