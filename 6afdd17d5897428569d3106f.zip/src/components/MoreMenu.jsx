import { Link } from "@tanstack/react-router";
import { ChevronDown, Download, MessageCircle, Palette, Rocket } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DISCORD_URL } from "@/lib/links";

export default function MoreMenu({ className }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className={className}>
        <span className="flex items-center gap-1">
          More
          <ChevronDown className="h-3.5 w-3.5" />
        </span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-44">
        <DropdownMenuItem asChild>
          <Link to="/launcher" className="flex items-center gap-2">
            <Rocket className="h-4 w-4" />
            Launcher
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/downloads" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Downloads
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to="/settings" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            Appearance
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <a href={DISCORD_URL} target="_blank" rel="noreferrer" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            Discord
          </a>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}