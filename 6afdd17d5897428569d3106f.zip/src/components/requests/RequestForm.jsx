import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { createGameRequest } from "@/lib/server-fns";
import { cn } from "@/lib/utils";

const KINDS = [
  { value: "Game", label: "Game request", hint: "A build you want in the library" },
  { value: "Suggestion", label: "Site suggestion", hint: "Something to improve the hub" },
];

export default function RequestForm() {
  const submit = useServerFn(createGameRequest);
  const [kind, setKind] = useState("Game");
  const [form, setForm] = useState({ title: "", details: "", contact: "" });
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);

  const set = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!form.title.trim() || !form.details.trim()) {
      setError("Add a name and a little detail so it can be reviewed.");
      return;
    }
    setSending(true);
    setError("");
    try {
      await submit({ data: { kind, ...form, title: form.title.trim(), details: form.details.trim() } });
      setSent(true);
      setForm({ title: "", details: "", contact: "" });
    } catch (err) {
      setError(err?.message || "The request could not be sent.");
    } finally {
      setSending(false);
    }
  };

  if (sent) {
    return (
      <div className="rounded-xl border border-primary/40 bg-primary/5 p-8 text-center">
        <CheckCircle2 className="mx-auto h-8 w-8 text-primary" />
        <h2 className="mt-3 font-heading text-xl font-semibold text-foreground">Request received</h2>
        <p className="mt-1 text-sm text-muted-foreground">It lands in the review queue. Drop another one any time.</p>
        <Button variant="outline" className="mt-5" onClick={() => setSent(false)}>
          Send another
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5 rounded-xl border border-border bg-card p-6">
      <div className="grid gap-2 sm:grid-cols-2">
        {KINDS.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => setKind(option.value)}
            className={cn(
              "rounded-lg border px-4 py-3 text-left transition-colors",
              kind === option.value
                ? "border-primary/60 bg-primary/10"
                : "border-border bg-background hover:border-border/80"
            )}
          >
            <span className="block font-heading text-sm font-medium text-foreground">{option.label}</span>
            <span className="mt-0.5 block text-xs text-muted-foreground">{option.hint}</span>
          </button>
        ))}
      </div>

      <div className="space-y-2">
        <Label htmlFor="request-title">{kind === "Game" ? "Game name" : "Suggestion title"}</Label>
        <Input id="request-title" value={form.title} onChange={set("title")} placeholder={kind === "Game" ? "Boneworks" : "Add a wishlist"} />
      </div>

      <div className="space-y-2">
        <Label htmlFor="request-details">{kind === "Game" ? "Where to find it, why it belongs here" : "What should change"}</Label>
        <Textarea
          id="request-details"
          value={form.details}
          onChange={set("details")}
          rows={5}
          maxLength={2000}
          placeholder="Store link, version, anything useful."
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="request-contact">Contact (optional)</Label>
        <Input id="request-contact" value={form.contact} onChange={set("contact")} placeholder="Discord handle or email" />
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}

      <Button type="submit" disabled={sending}>
        {sending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
        Send request
      </Button>
    </form>
  );
}