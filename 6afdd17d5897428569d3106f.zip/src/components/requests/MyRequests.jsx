import { useState } from "react";
import { MessageCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import RequestThreadDialog from "@/components/requests/RequestThreadDialog";

const formatDate = (value) =>
  value ? new Date(value).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "";

export default function MyRequests({ requests }) {
  const [activeId, setActiveId] = useState(null);
  const active = requests.find((request) => request.id === activeId) || null;

  return (
    <div className="mt-6 rounded-xl border border-border bg-card p-6">
      <h2 className="font-heading text-lg font-semibold text-foreground">Your requests</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Open one to read the reply from the team and write back.
      </p>

      {requests.length ? (
        <ul className="mt-4 space-y-2">
          {requests.map((request) => (
            <li key={request.id}>
              <button
                type="button"
                onClick={() => setActiveId(request.id)}
                className="flex w-full flex-wrap items-center justify-between gap-3 rounded-lg border border-border bg-background px-4 py-3 text-left transition-colors hover:border-primary/50"
              >
                <div className="min-w-0">
                  <p className="truncate font-heading text-sm font-medium text-foreground">{request.title}</p>
                  <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    {request.kind} · {formatDate(request.created_date)}
                  </p>
                </div>
                <span className="flex items-center gap-2">
                  <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-[0.14em]">
                    {request.status}
                  </Badge>
                  <span className="flex items-center gap-1 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    <MessageCircle className="h-3.5 w-3.5" />
                    {(request.messages || []).length}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-4 text-sm text-muted-foreground">
          Nothing yet. Send a request from the Requests page and it shows up here.
        </p>
      )}

      <RequestThreadDialog request={active} open={Boolean(active)} onOpenChange={(value) => !value && setActiveId(null)} />
    </div>
  );
}