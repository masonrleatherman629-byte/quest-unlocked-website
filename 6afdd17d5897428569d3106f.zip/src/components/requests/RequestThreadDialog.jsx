import { useEffect, useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Send } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import UserAvatar from "@/components/profile/UserAvatar";
import { useAuth } from "@/lib/AuthContext";
import { displayAvatar, displayName } from "@/lib/identity";
import { replyToGameRequest } from "@/lib/server-fns";

const when = (value) =>
  new Date(value).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

export default function RequestThreadDialog({ request, open, onOpenChange }) {
  const router = useRouter();
  const { user } = useAuth();
  const send = useServerFn(replyToGameRequest);
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setBody("");
      setError("");
    }
  }, [open, request?.id]);

  if (!request) return null;

  const messages = request.messages || [];

  const handleSend = async (event) => {
    event.preventDefault();
    if (!body.trim()) return;
    setSending(true);
    setError("");
    try {
      await send({ data: { id: request.id, body: body.trim() } });
      setBody("");
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "The message could not be sent.");
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading">{request.title}</DialogTitle>
          <DialogDescription className="whitespace-pre-line">{request.details}</DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2.5">
          <UserAvatar
            user={{
              full_name: request.requester_name,
              avatar_url: request.requester_avatar_url,
            }}
            className="h-9 w-9"
          />
          <div className="min-w-0">
            <p className="truncate font-heading text-sm font-medium text-foreground">
              {request.requester_name || "Guest"}
            </p>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
              Requested {when(request.created_date)}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="secondary" className="font-mono text-[10px] uppercase tracking-[0.14em]">
            {request.kind}
          </Badge>
          <Badge variant="outline" className="font-mono text-[10px] uppercase tracking-[0.14em]">
            {request.status}
          </Badge>
        </div>

        <div className="max-h-72 space-y-3 overflow-y-auto rounded-lg border border-border bg-muted/30 p-3">
          {messages.length ? (
            messages.map((message, index) => (
              <div
                key={`${message.sent_at}-${index}`}
                className={
                  message.author_role === "admin"
                    ? "rounded-lg border border-primary/40 bg-primary/10 px-3 py-2"
                    : "rounded-lg border border-border bg-card px-3 py-2"
                }
              >
                <div className="flex items-start gap-2">
                  <UserAvatar
                    user={{ full_name: message.author_name, avatar_url: message.author_avatar_url }}
                    className="h-9 w-9"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="font-heading text-xs font-medium text-foreground">
                        {message.author_name || "Quest Unlocked"}
                      </span>
                      {message.author_role === "admin" && (
                        <Badge
                          variant="secondary"
                          className="px-1.5 py-0 font-mono text-[9px] uppercase tracking-[0.14em]"
                        >
                          Team
                        </Badge>
                      )}
                      <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                        {when(message.sent_at)}
                      </span>
                    </div>
                    <p className="mt-1 whitespace-pre-line text-sm text-foreground">{message.body}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="py-6 text-center text-sm text-muted-foreground">
              No messages yet. Start the conversation below.
            </p>
          )}
        </div>

        <form onSubmit={handleSend} className="space-y-3">
          <div className="flex items-center gap-2">
            <UserAvatar
              user={{ full_name: displayName(user), avatar_url: displayAvatar(user) }}
              className="h-9 w-9"
            />
            <span className="text-xs text-muted-foreground">Posting as {displayName(user)}</span>
          </div>
          <Textarea
            value={body}
            onChange={(event) => setBody(event.target.value)}
            rows={3}
            placeholder="Write a message…"
          />
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="flex justify-end">
            <Button type="submit" disabled={sending || !body.trim()}>
              {sending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
              Send
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}