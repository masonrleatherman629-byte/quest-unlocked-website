const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { LogOut, MessageCircle, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Image } from "@/components/ui/image";
import UserAvatar from "@/components/profile/UserAvatar";
import MoreMenu from "@/components/MoreMenu";
import ManageChooser from "@/components/ManageChooser";
import { useAuth } from "@/lib/AuthContext";
import useSiteLanguage from "@/hooks/use-site-language";
import { isRtlLanguage } from "@/lib/site-language";
import { DISCORD_URL } from "@/lib/links";

const NAV = [
{ to: "/", key: "nav_library" },
{ to: "/top-games", key: "nav_top_games" },
{ to: "/benchmarks", key: "nav_benchmarks" },
{ to: "/guide", key: "nav_guide" },
{ to: "/publishers", key: "nav_publishers" },
{ to: "/team", key: "nav_team" },
{ to: "/favorites", key: "nav_favorites" },
{ to: "/updates", key: "nav_updates" },
{ to: "/requests", key: "nav_requests" },
{ to: "/connect", key: "nav_connect" }];

const LOGO_URL =
"https://db.app/api/apps/6afdd17d5897428569d3106f/files/mp/public/6afdd17d5897428569d3106f/c7fb61cef_quest-unlocked-logo.png";

const linkClass = "rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:text-foreground";
const activeClass = { className: "text-foreground" };

export default function Layout({ children }) {
  const { user, isAuthenticated, isLoadingAuth, logout, navigateToLogin } = useAuth();
  const { language, t } = useSiteLanguage();
  const [manageOpen, setManageOpen] = useState(false);

  return (
    <div dir={isRtlLanguage(language) ? "rtl" : "ltr"} className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-30 border-b border-border/70 bg-background/85 backdrop-blur">
        <div className="mx-auto w-full max-w-6xl px-5">
          <div className="flex h-16 items-center justify-between gap-3">
            <Link to="/" className="flex items-center gap-3">
              <Image
                src={LOGO_URL}
                alt="Quest Unlocked"
                className="h-10 w-auto rounded-md"
                fittingType="fit" />
              
              <span className="font-heading text-sm font-semibold uppercase tracking-[0.22em] text-foreground">
                Quest Unlocked
              </span>
            </Link>

            <nav className="hidden flex-wrap items-center gap-1 lg:flex">
              {NAV.map((item) =>
              <Link key={item.to} to={item.to} className={linkClass} activeProps={activeClass}>
                  {t(item.key)}
                </Link>
              )}
              <MoreMenu className={linkClass} />
              {isAuthenticated &&
              <button type="button" className={linkClass} onClick={() => setManageOpen(true)}>
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="h-4 w-4" />
                    {t("manage")}
                  </span>
                </button>
              }
            </nav>

            <div className="flex items-center gap-2">
              {isLoadingAuth ?
              <div className="h-9 w-20 animate-pulse rounded-md bg-muted" /> :
              isAuthenticated ?
              <>
                  <Link
                  to="/profile"
                  className="flex items-center gap-2 rounded-md px-1.5 py-1 transition-colors hover:bg-accent">
                  
                    <UserAvatar user={user} />
                    <span className="hidden max-w-[140px] truncate text-xs text-muted-foreground lg:inline">
                      {user?.full_name || user?.email}
                    </span>
                  </Link>
                  <Button variant="ghost" size="sm" onClick={() => logout()}>
                    <LogOut className="mr-1.5 h-4 w-4" />
                    {t("sign_out")}
                  </Button>
                </> :

              <div className="flex items-center gap-1">
                  <Button asChild variant="ghost" size="sm">
                    <Link to="/register">{t("create_account")}</Link>
                  </Button>
                  <Button size="sm" onClick={() => navigateToLogin()}>
                    {t("sign_in")}
                  </Button>
                </div>
              }
            </div>
          </div>

          <nav className="flex items-center gap-1 overflow-x-auto pb-2 lg:hidden">
            {NAV.map((item) =>
            <Link key={item.to} to={item.to} className={linkClass} activeProps={activeClass}>
                {t(item.key)}
              </Link>
            )}
            <MoreMenu className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm text-muted-foreground" />
            {isAuthenticated &&
            <button type="button" className={linkClass} onClick={() => setManageOpen(true)}>
                {t("manage")}
              </button>
            }
          </nav>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <ManageChooser open={manageOpen} onOpenChange={setManageOpen} user={user} />

      <footer className="border-t border-border/70">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-5 py-8 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <span className="font-mono uppercase tracking-[0.18em]">Quest Unlocked · Human published VR builds credit to @rad for help in the website update </span>
          <a
            href={DISCORD_URL}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 transition-colors hover:text-primary">
            
            <MessageCircle className="h-3.5 w-3.5" />
            {t("join_discord")}
          </a>
        </div>
      </footer>
    </div>);

}