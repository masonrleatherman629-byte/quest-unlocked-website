import { Link } from "@tanstack/react-router";
import { Image } from "@/components/ui/image";

// One headset's table: rank, game, community average FPS, 1% low and how many
// results that average is built from. Games without results still list, so a
// member can open them and add the first one.
export default function BenchmarkTable({ games, stats, headset }) {
  const rows = games
    .map((game) => ({ game, result: stats(game.id, headset) }))
    .sort(
      (a, b) =>
        (b.result?.fps ?? -1) - (a.result?.fps ?? -1) ||
        a.game.title.localeCompare(b.game.title)
    );

  if (!rows.length) {
    return (
      <div className="rounded-xl border border-dashed border-border px-6 py-16 text-center">
        <p className="font-heading text-lg text-foreground">No games to compare yet</p>
        <p className="mt-1 text-sm text-muted-foreground">
          Add a build to the library and its benchmarks land here.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="hidden grid-cols-[2rem_1fr_5.5rem_5.5rem_5.5rem] gap-3 border-b border-border px-4 py-3 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground sm:grid">
        <span>#</span>
        <span>Game</span>
        <span className="text-right">Avg FPS</span>
        <span className="text-right">1% low</span>
        <span className="text-right">Results</span>
      </div>

      {rows.map(({ game, result }, index) => (
        <Link
          key={game.id}
          to="/games/$gameId"
          params={{ gameId: game.id }}
          className="grid grid-cols-[1.5rem_1fr_4.5rem] items-center gap-3 border-b border-border/70 px-4 py-3 transition-colors last:border-0 hover:bg-secondary/40 sm:grid-cols-[2rem_1fr_5.5rem_5.5rem_5.5rem]"
        >
          <span className="font-mono text-xs text-muted-foreground">{index + 1}</span>

          <span className="flex min-w-0 items-center gap-3">
            <span className="h-11 w-16 shrink-0 overflow-hidden rounded-md border border-border bg-muted">
              {game.image_url && (
                <Image
                  src={game.image_url}
                  alt={`${game.title} cover art`}
                  className="h-full w-full object-cover"
                  fittingType="fill"
                />
              )}
            </span>
            <span className="min-w-0">
              <span className="block truncate font-heading text-sm font-medium text-foreground">
                {game.title}
              </span>
              <span className="block truncate font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                {[game.developer, game.version && `v${game.version}`].filter(Boolean).join(" · ")}
              </span>
            </span>
          </span>

          <span className="text-right font-heading text-sm text-foreground">
            {result ? result.fps : "—"}
          </span>
          <span className="hidden text-right font-mono text-xs text-muted-foreground sm:block">
            {result?.low ?? "—"}
          </span>
          <span className="hidden text-right font-mono text-xs text-muted-foreground sm:block">
            {result?.count ?? "—"}
          </span>
        </Link>
      ))}
    </div>
  );
}