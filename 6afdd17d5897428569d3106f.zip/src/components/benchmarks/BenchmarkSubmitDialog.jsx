import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BENCHMARK_PRESETS, HEADSETS } from "@/lib/game-options";
import { createBenchmark } from "@/lib/server-fns";

const EMPTY = { game_id: "", headset: "", fps_avg: "", fps_low: "", preset: "High", notes: "" };

export default function BenchmarkSubmitDialog({ open, onOpenChange, games, headset }) {
  const router = useRouter();
  const submit = useServerFn(createBenchmark);
  const [form, setForm] = useState({ ...EMPTY, headset });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const set = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  const handleOpenChange = (next) => {
    if (next) {
      setForm({ ...EMPTY, headset });
      setError("");
    }
    onOpenChange(next);
  };

  const valid = form.game_id && form.headset && Number(form.fps_avg) > 0;

  const save = async (event) => {
    event.preventDefault();
    if (!valid) return;
    setBusy(true);
    setError("");
    try {
      const game = games.find((entry) => entry.id === form.game_id);
      await submit({
        data: {
          game_id: form.game_id,
          game_title: game?.title,
          headset: form.headset,
          fps_avg: Number(form.fps_avg),
          fps_low: form.fps_low === "" ? undefined : Number(form.fps_low),
          preset: form.preset,
          notes: form.notes.trim() || undefined,
        },
      });
      await router.invalidate();
      toast.success("Result added to the benchmark tables.");
      onOpenChange(false);
    } catch (err) {
      setError(err?.message || "The result could not be saved.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add a benchmark result</DialogTitle>
          <DialogDescription>
            Record what a build actually ran at on your headset. The table averages every result.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={save} className="space-y-4">
          {error && (
            <p role="alert" className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
              {error}
            </p>
          )}

          <div className="space-y-2">
            <Label>Game</Label>
            <Select value={form.game_id} onValueChange={(value) => set("game_id", value)}>
              <SelectTrigger>
                <SelectValue placeholder="Pick a game" />
              </SelectTrigger>
              <SelectContent>
                {games.map((game) => (
                  <SelectItem key={game.id} value={game.id}>
                    {game.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Headset</Label>
              <Select value={form.headset} onValueChange={(value) => set("headset", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Pick a headset" />
                </SelectTrigger>
                <SelectContent>
                  {HEADSETS.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Graphics preset</Label>
              <Select value={form.preset} onValueChange={(value) => set("preset", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {BENCHMARK_PRESETS.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bench-fps">Average FPS</Label>
              <Input
                id="bench-fps"
                type="number"
                min="1"
                max="240"
                inputMode="decimal"
                placeholder="72"
                value={form.fps_avg}
                onChange={(event) => set("fps_avg", event.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bench-low">1% low FPS</Label>
              <Input
                id="bench-low"
                type="number"
                min="0"
                max="240"
                inputMode="decimal"
                placeholder="61"
                value={form.fps_low}
                onChange={(event) => set("fps_low", event.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bench-notes">Notes</Label>
            <Textarea
              id="bench-notes"
              rows={3}
              maxLength={500}
              placeholder="Link or standalone, render resolution, anything that shaped the result."
              value={form.notes}
              onChange={(event) => set("notes", event.target.value)}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={busy || !valid}>
              {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Add result
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}