import { Link } from "@tanstack/react-router";
import { Wrench } from "lucide-react";
import { DISCORD_URL } from "@/lib/links";

// What the whole public site becomes while maintenance is switched on.
export default function MaintenanceScreen({ message }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-5 py-16">
      <div className="w-full max-w-md text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-border bg-card">
          <Wrench className="h-6 w-6 text-primary" />
        </span>
        <p className="mt-6 font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Quest Unlocked</p>
        <h1 className="mt-3 font-heading text-3xl font-semibold tracking-tight text-foreground">
          Down for maintenance
        </h1>
        <p className="mt-3 text-sm text-muted-foreground">{message}</p>
        <div className="mt-6 flex flex-col items-center gap-2 text-xs text-muted-foreground">
          <a
            href={DISCORD_URL}
            target="_blank"
            rel="noreferrer"
            className="underline-offset-4 transition-colors hover:text-primary hover:underline"
          >
            Updates are posted on Discord
          </a>
          <Link to="/login" className="underline-offset-4 transition-colors hover:text-foreground hover:underline">
            Staff sign in
          </Link>
        </div>
      </div>
    </div>
  );
}