import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Image } from "@/components/ui/image";

export default function PublisherCard({ publisher, gameCount }) {
  const initials = (publisher.name || "?").slice(0, 2).toUpperCase();

  return (
    <Link
      to="/publishers/$publisherId"
      params={{ publisherId: publisher.id }}
      className="group flex flex-col gap-4 rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/50"
    >
      <div className="flex items-center gap-4">
        <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg border border-border bg-muted">
          {publisher.logo_url ? (
            <Image
              src={publisher.logo_url}
              alt={`${publisher.name} logo`}
              className="h-full w-full object-cover"
              fittingType="fill"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center font-mono text-xs text-muted-foreground">
              {initials}
            </div>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-heading text-lg font-semibold text-foreground">{publisher.name}</h3>
          <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            {gameCount} {gameCount === 1 ? "title" : "titles"}
          </p>
        </div>
        <ArrowUpRight className="h-4 w-4 shrink-0 text-muted-foreground transition-colors group-hover:text-primary" />
      </div>

      {publisher.description && (
        <p className="line-clamp-2 text-sm leading-relaxed text-muted-foreground">{publisher.description}</p>
      )}
    </Link>
  );
}