import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Download, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import LauncherBuildDialog from "@/components/admin/LauncherBuildDialog";
import { saveLauncherBuild } from "@/lib/server-fns";
import { useAuth } from "@/lib/AuthContext";

export default function QuestBuildBar({ build }) {
  const { user } = useAuth();
  const router = useRouter();
  const save = useServerFn(saveLauncherBuild);
  const [open, setOpen] = useState(false);
  const isAdmin = user?.role === "admin";

  if (!build?.download_url && !isAdmin) return null;

  return (
    <div className="mt-6 flex flex-wrap items-center gap-2">
      {build?.download_url && (
        <Button asChild className="h-12 rounded-xl bg-launcher text-launcher-foreground hover:bg-launcher/90">
          <a href={build.download_url} download>
            <Download className="mr-2 h-4 w-4" />
            Download launcher APK
          </a>
        </Button>
      )}
      {isAdmin && (
        <Button variant="outline" className="h-12 rounded-xl" onClick={() => setOpen(true)}>
          <Upload className="mr-2 h-4 w-4" />
          {build?.download_url ? "Replace APK" : "Add build"}
        </Button>
      )}

      {isAdmin && (
        <LauncherBuildDialog
          open={open}
          onOpenChange={setOpen}
          platform="Meta Quest"
          build={build}
          onSave={async (values) => {
            await save({ data: values });
            await router.invalidate();
          }}
        />
      )}
    </div>
  );
}