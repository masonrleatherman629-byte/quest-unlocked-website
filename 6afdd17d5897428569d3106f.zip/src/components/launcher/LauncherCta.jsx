import { Link } from "@tanstack/react-router";
import { ChevronRight, MessageCircle, Monitor } from "lucide-react";
import { DISCORD_URL } from "@/lib/links";

const baseClass =
  "group flex items-center gap-4 rounded-xl px-5 py-4 transition-opacity hover:opacity-90";

export default function LauncherCta() {
  return (
    <div className="grid gap-3">
      <Link to="/launcher" className={`${baseClass} bg-launcher text-launcher-foreground`}>
        <Monitor className="h-6 w-6 shrink-0" />
        <span className="min-w-0 flex-1">
          <span className="block text-[11px] uppercase tracking-[0.16em] opacity-80">Download games with</span>
          <span className="block font-heading text-lg font-semibold leading-tight">Moon Launcher</span>
        </span>
        <ChevronRight className="h-5 w-5 shrink-0 opacity-80 transition-transform group-hover:translate-x-0.5" />
      </Link>

      <a
        href={DISCORD_URL}
        target="_blank"
        rel="noreferrer"
        className={`${baseClass} bg-discord text-discord-foreground`}
      >
        <MessageCircle className="h-6 w-6 shrink-0" />
        <span className="min-w-0 flex-1">
          <span className="block text-[11px] uppercase tracking-[0.16em] opacity-80">Join us on</span>
          <span className="block font-heading text-lg font-semibold leading-tight">Discord</span>
        </span>
        <ChevronRight className="h-5 w-5 shrink-0 opacity-80 transition-transform group-hover:translate-x-0.5" />
      </a>
    </div>
  );
}