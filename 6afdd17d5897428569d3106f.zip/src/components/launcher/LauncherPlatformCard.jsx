import { Link } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function LauncherPlatformCard({ label, icon: Icon, blurb, build, href, actionLabel }) {
  const ready = Boolean(build?.download_url);

  return (
    <div className="flex flex-col rounded-xl border border-border bg-card p-5">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border border-launcher/40 bg-launcher/10 text-launcher">
          <Icon className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <h2 className="font-heading text-base font-semibold text-foreground">{label}</h2>
          <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            {ready
              ? [build.version && `v${build.version}`, build.size_label].filter(Boolean).join(" · ")
              : href
                ? "Runs in the headset browser"
                : "Coming soon"}
          </p>
        </div>
      </div>

      <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
        {build?.notes || blurb}
      </p>

      <div className="mt-4 flex flex-col gap-2">
        {ready && (
          <Button asChild className="bg-launcher text-launcher-foreground hover:bg-launcher/90">
            <a href={build.download_url} download>
              <Download className="mr-2 h-4 w-4" />
              Download for {label}
            </a>
          </Button>
        )}
        {href && (
          <Button
            asChild
            variant={ready ? "outline" : undefined}
            className={ready ? undefined : "bg-launcher text-launcher-foreground hover:bg-launcher/90"}
          >
            <Link to={href}>
              <Icon className="mr-2 h-4 w-4" />
              {actionLabel || `Open on ${label}`}
            </Link>
          </Button>
        )}
        {!ready && !href && (
          <Button variant="outline" disabled>
            Coming soon
          </Button>
        )}
      </div>
    </div>
  );
}