import { Link } from "@tanstack/react-router";
import { Download, RefreshCw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Image } from "@/components/ui/image";
import { isNewer } from "@/lib/quest-library";
import { cn } from "@/lib/utils";

export default function QuestGameCard({ game, installed, onInstall, onRemove }) {
  const update = Boolean(installed && game.version && isNewer(game.version, installed.version));
  const status = !installed
    ? "Not installed"
    : update
      ? `Update available · ${game.version ? `v${game.version}` : "new build"}`
      : `Installed${installed.version ? ` · v${installed.version}` : ""}`;

  return (
    <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-4 sm:flex-row sm:items-center">
      <div className="h-24 w-24 shrink-0 overflow-hidden rounded-xl border border-border bg-muted">
        {game.image_url && (
          <Image
            src={game.image_url}
            alt={game.title}
            className="h-full w-full object-cover"
            fittingType="fill"
          />
        )}
      </div>

      <div className="min-w-0 flex-1">
        <Link
          to="/games/$gameId"
          params={{ gameId: game.id }}
          className="font-heading text-lg font-semibold text-foreground hover:text-primary"
        >
          {game.title}
        </Link>
        <p className="mt-0.5 truncate font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
          {[game.developer, game.version && `v${game.version}`, game.size_label]
            .filter(Boolean)
            .join(" · ") || "Build"}
        </p>
        <p className={cn("mt-2 text-sm", update ? "text-launcher" : "text-muted-foreground")}>{status}</p>
      </div>

      <div className="flex shrink-0 flex-wrap items-center gap-2">
        {game.download_url ? (
          <Button
            asChild
            size="lg"
            className="h-12 bg-launcher px-5 text-launcher-foreground hover:bg-launcher/90"
          >
            <a href={game.download_url} download onClick={() => onInstall(game)}>
              {update ? (
                <RefreshCw className="mr-2 h-4 w-4" />
              ) : (
                <Download className="mr-2 h-4 w-4" />
              )}
              {installed ? (update ? "Update" : "Reinstall") : "Install"}
            </a>
          </Button>
        ) : (
          <Button size="lg" variant="outline" className="h-12" disabled>
            Build pending
          </Button>
        )}

        {installed && (
          <Button size="lg" variant="ghost" className="h-12" onClick={() => onRemove(game.id)}>
            <Trash2 className="mr-2 h-4 w-4" />
            Remove
          </Button>
        )}
      </div>
    </div>
  );
}