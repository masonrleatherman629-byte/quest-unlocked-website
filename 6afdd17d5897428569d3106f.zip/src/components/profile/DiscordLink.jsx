const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useCallback, useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Image } from "@/components/ui/image";

import { useAuth } from "@/lib/AuthContext";
import { getMyDiscord } from "@/lib/server-fns";

const CONNECTOR_ID = "6afe3a0bb7f276df226b1a59";

export default function DiscordLink() {
  const fetchDiscord = useServerFn(getMyDiscord);
  const { refresh } = useAuth();
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);
  const [discord, setDiscord] = useState(null);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      const result = await fetchDiscord();
      setConnected(result.connected);
      setDiscord(result.discord ?? null);
      setError("");
    } catch {
      setError("Discord couldn't be reached just now.");
    } finally {
      setLoading(false);
    }
  }, [fetchDiscord]);

  useEffect(() => {
    load();
  }, [load]);

  const connect = async () => {
    setWorking(true);
    setError("");
    try {
      const url = await db.connectors.connectAppUser(CONNECTOR_ID);
      const popup = window.open(url, "_blank", "width=520,height=760");
      const timer = setInterval(() => {
        if (!popup || popup.closed) {
          clearInterval(timer);
          load();
          refresh();
          setWorking(false);
        }
      }, 500);
    } catch {
      setError("The Discord window could not be opened.");
      setWorking(false);
    }
  };

  const disconnect = async () => {
    setWorking(true);
    setError("");
    try {
      await db.connectors.disconnectAppUser(CONNECTOR_ID);
      setConnected(false);
      setDiscord(null);
    } catch {
      setError("Discord could not be disconnected.");
    } finally {
      setWorking(false);
    }
  };

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-heading text-base font-semibold text-foreground">Discord</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {connected
              ? "Your Discord account is linked to this profile."
              : "Link your Discord account so your Discord name shows on your profile."}
          </p>
        </div>

        {loading ? (
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Checking…
          </span>
        ) : connected ? (
          <Button variant="outline" size="sm" onClick={disconnect} disabled={working}>
            {working && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Disconnect
          </Button>
        ) : (
          <Button size="sm" onClick={connect} disabled={working}>
            {working && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Connect Discord
          </Button>
        )}
      </div>

      {connected && discord && (
        <div className="mt-4 flex items-center gap-3 rounded-lg border border-border bg-background/40 p-3">
          {discord.avatar_url ? (
            <Image
              src={discord.avatar_url}
              alt=""
              className="h-11 w-11 rounded-full"
              fittingType="fill"
            />
          ) : (
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-discord/20 font-heading text-sm font-semibold text-discord">
              {discord.name.slice(0, 1).toUpperCase()}
            </div>
          )}
          <div>
            <p className="font-heading text-sm font-medium text-foreground">{discord.name}</p>
            <p className="font-mono text-[11px] text-muted-foreground">@{discord.username}</p>
          </div>
        </div>
      )}

      {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
    </div>
  );
}