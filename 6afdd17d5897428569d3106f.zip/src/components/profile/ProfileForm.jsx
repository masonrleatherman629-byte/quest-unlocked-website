const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { compressImage } from "@/lib/image-compress";
import { updateProfile } from "@/lib/server-fns";
import { useAuth } from "@/lib/AuthContext";
import UserAvatar from "@/components/profile/UserAvatar";

export default function ProfileForm({ user }) {
  const save = useServerFn(updateProfile);
  const { refresh } = useAuth();
  const [name, setName] = useState(user?.full_name || "");
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar_url || "");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");

  const handlePicture = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setError("");
    setUploading(true);
    try {
      const compressed = await compressImage(file);
      const extension = compressed.type === "image/webp" ? "webp" : "jpg";
      const namedFile = new File([compressed], `${crypto.randomUUID()}-${Date.now()}.${extension}`, {
        type: compressed.type || "image/jpeg",
      });
      const { file_url } = await db.integrations.Core.UploadPublicFile({ file: namedFile });
      setAvatarUrl(file_url);
      setStatus("Picture ready — save to keep it");
    } catch (err) {
      setError(err?.message || "The picture could not be uploaded.");
    } finally {
      setUploading(false);
      event.target.value = "";
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!name.trim()) {
      setError("Add a name before saving.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await save({ data: { full_name: name.trim(), avatar_url: avatarUrl || undefined } });
      await refresh();
      setStatus("Profile saved");
    } catch (err) {
      setError(err?.message || "Your profile could not be saved.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 rounded-xl border border-border bg-card p-5">
      <div className="flex flex-wrap items-center gap-4">
        <UserAvatar user={{ full_name: name, avatar_url: avatarUrl }} className="h-20 w-20 text-lg" />
        <div className="space-y-2">
          <Button asChild type="button" variant="outline" size="sm" disabled={uploading}>
            <label className="cursor-pointer">
              {uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
              {avatarUrl ? "Change picture" : "Upload picture"}
              <input type="file" accept="image/*" className="hidden" onChange={handlePicture} />
            </label>
          </Button>
          <p className="text-xs text-muted-foreground">
            A square picture works best. Stored publicly — anyone with the link can open it.
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="full-name">Display name</Label>
        <Input
          id="full-name"
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Your name"
          maxLength={80}
        />
        <p className="text-xs text-muted-foreground">Shown on your comments across the library.</p>
      </div>

      {status && !error && <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-primary">{status}</p>}
      {error && <p className="text-sm text-destructive">{error}</p>}

      <Button type="submit" disabled={saving || uploading}>
        {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Save profile
      </Button>
    </form>
  );
}