import { Image } from "@/components/ui/image";
import { cn } from "@/lib/utils";

export default function UserAvatar({ user, className }) {
  const name = user?.full_name || user?.email || "";
  const initials = name.trim().slice(0, 2).toUpperCase() || "?";

  return (
    <span
      className={cn(
        "grid h-8 w-8 shrink-0 place-items-center overflow-hidden rounded-full border border-border bg-secondary font-mono text-[10px] uppercase text-muted-foreground",
        className
      )}
    >
      {user?.avatar_url ? (
        <Image
          src={user.avatar_url}
          alt={name ? `${name}'s profile picture` : "Profile picture"}
          className="h-full w-full object-cover"
          fittingType="fill"
        />
      ) : (
        initials
      )}
    </span>
  );
}