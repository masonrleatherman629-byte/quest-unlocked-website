import { Image } from "@/components/ui/image";

const ROLE_STYLES = {
  Admin: "border-primary/40 bg-primary/10 text-primary",
  Helper: "border-launcher/40 bg-launcher/10 text-launcher",
  Tester: "border-accent/40 bg-accent/10 text-accent",
};

// One person: their picture, their name, their role and a line about them.
export default function TeamMemberCard({ member }) {
  const initials = (member.name || "?")
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();

  return (
    <div className="flex flex-col items-center rounded-xl border border-border bg-card p-6 text-center">
      <div className="h-24 w-24 overflow-hidden rounded-full border border-border bg-muted">
        {member.avatar_url ? (
          <Image
            src={member.avatar_url}
            alt={member.name}
            className="h-full w-full object-cover"
            fittingType="fill"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center font-heading text-xl text-muted-foreground">
            {initials}
          </div>
        )}
      </div>

      <h2 className="mt-4 font-heading text-base font-semibold text-foreground">{member.name}</h2>

      <span
        className={`mt-2 rounded-full border px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-[0.16em] ${
          ROLE_STYLES[member.role] || ROLE_STYLES.Helper
        }`}
      >
        {member.role || "Helper"}
      </span>

      {member.text && (
        <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
          {member.text}
        </p>
      )}
    </div>
  );
}