import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Heart, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/AuthContext";
import { checkFavorite, toggleFavorite } from "@/lib/server-fns";
import { cn } from "@/lib/utils";

export default function FavoriteButton({ game }) {
  const { isAuthenticated, navigateToLogin } = useAuth();
  const check = useServerFn(checkFavorite);
  const toggle = useServerFn(toggleFavorite);
  const [favoriteId, setFavoriteId] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      setFavoriteId(null);
      return;
    }
    let alive = true;
    check({ data: { game_id: game.id } })
      .then((record) => {
        if (alive) setFavoriteId(record?.id ?? null);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [isAuthenticated, game.id, check]);

  const handleClick = async () => {
    if (!isAuthenticated) {
      navigateToLogin();
      return;
    }
    setBusy(true);
    try {
      const result = await toggle({
        data: { game_id: game.id, game_title: game.title, favorite_id: favoriteId },
      });
      setFavoriteId(result.favorited ? result.id : null);
    } finally {
      setBusy(false);
    }
  };

  const favorited = Boolean(favoriteId);

  return (
    <Button variant="outline" size="sm" onClick={handleClick} disabled={busy}>
      {busy ? (
        <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
      ) : (
        <Heart className={cn("mr-1.5 h-4 w-4", favorited && "fill-primary text-primary")} />
      )}
      {favorited ? "Saved" : "Favorite"}
    </Button>
  );
}