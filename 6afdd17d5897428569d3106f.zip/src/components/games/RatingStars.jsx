import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export default function RatingStars({ rating, count, className }) {
  if (!rating) return null;

  return (
    <span className={cn("inline-flex items-center gap-1.5", className)}>
      <span className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((step) => (
          <Star
            key={step}
            className={cn(
              "h-3.5 w-3.5",
              step <= Math.round(rating) ? "fill-accent text-accent" : "text-muted-foreground/40"
            )}
          />
        ))}
      </span>
      <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
        {rating.toFixed(1)}
        {count ? ` · ${count}` : ""}
      </span>
    </span>
  );
}