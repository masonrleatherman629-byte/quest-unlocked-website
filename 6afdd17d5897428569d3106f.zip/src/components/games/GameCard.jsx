import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import { Badge } from "@/components/ui/badge";
import RatingStars from "@/components/games/RatingStars";
import { ContentRating, OfflinePlayPill, StatusPill } from "@/components/games/GameTags";

export default function GameCard({ game }) {
  return (
    <Link
      to="/games/$gameId"
      params={{ gameId: game.id }}
      className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card transition-colors hover:border-primary/50"
    >
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-muted">
        {game.image_url ? (
          <Image
            src={game.image_url}
            alt={`${game.title} cover art`}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
            fittingType="fill"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-muted-foreground">
            <span className="font-mono text-[11px] uppercase tracking-[0.2em]">No artwork</span>
          </div>
        )}
        {game.status && (
          <Badge className="absolute left-3 top-3 border-0 bg-background/85 text-[11px] font-medium uppercase tracking-wider text-foreground backdrop-blur">
            {game.status}
          </Badge>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="truncate font-heading text-lg font-semibold text-foreground">{game.title}</h3>
            <p className="mt-0.5 truncate text-xs text-muted-foreground">
              {game.developer}
              {game.version ? ` · v${game.version}` : ""}
            </p>
            {game.rating > 0 && (
              <div className="mt-1.5">
                <RatingStars rating={game.rating} count={game.rating_count} />
              </div>
            )}
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {game.price && (
              <span className="font-heading text-sm font-semibold text-foreground">{game.price}</span>
            )}
            <ArrowUpRight className="h-4 w-4 text-muted-foreground transition-colors group-hover:text-primary" />
          </div>
        </div>

        {game.description && (
          <p className="line-clamp-2 text-sm leading-relaxed text-muted-foreground">{game.description}</p>
        )}

        {(game.players || (game.player_modes || []).length > 0) && (
          <p className="truncate font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            {[game.players, (game.player_modes || []).join(" / ")].filter(Boolean).join(" · ")}
          </p>
        )}

        {(game.versions?.length || game.offline_play || game.content_rating) && (
          <div className="flex flex-wrap items-center gap-1.5">
            <StatusPill game={game} />
            <OfflinePlayPill enabled={game.offline_play} />
            <ContentRating value={game.content_rating} />
          </div>
        )}

        <div className="mt-auto flex flex-wrap gap-1.5">
          {(game.genres || []).slice(0, 3).map((genre) => (
            <span
              key={genre}
              className="rounded-full border border-border bg-secondary/60 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground"
            >
              {genre}
            </span>
          ))}
        </div>
      </div>
    </Link>
  );
}