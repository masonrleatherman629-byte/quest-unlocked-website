import useSiteLanguage from "@/hooks/use-site-language";

export default function LibraryHero({ count }) {
  const { t } = useSiteLanguage();

  return (
    <section className="relative overflow-hidden border-b border-border/70">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
          "linear-gradient(to right, hsl(var(--border)) 1px, transparent 1px), linear-gradient(to bottom, hsl(var(--border)) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(ellipse at 30% 0%, black, transparent 72%)"
        }} />
      
      <div className="relative mx-auto w-full max-w-6xl px-5 py-16 sm:py-24">
        <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-primary">
          {t("hero_kicker")}
        </p>
        <h1 className="mt-5 max-w-2xl font-heading text-4xl font-semibold leading-[1.05] tracking-tight text-foreground sm:text-6xl">
          {t("hero_title_a")}
          <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{t("hero_title_b")}</span>
        </h1>
        <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">A developer-published catalogue of VR builds. Every title is uploaded by a human and downloaded straight to your headset — no filler, no generated artwork, no dead links. thx to @roxyou for testing help in the website as well as rad for help in development

        </p>

        

        
      </div>
    </section>);

}