import { useState } from "react";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, MessageSquare, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/lib/AuthContext";
import { displayAvatar, displayName } from "@/lib/identity";
import UserAvatar from "@/components/profile/UserAvatar";
import { createComment, deleteComment } from "@/lib/server-fns";

const formatDate = (value) =>
  value ? new Date(value).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "";

export default function CommentSection({ gameId, gameTitle, comments }) {
  const { user, isAuthenticated, isLoadingAuth, navigateToLogin } = useAuth();
  const router = useRouter();
  const post = useServerFn(createComment);
  const remove = useServerFn(deleteComment);

  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    if (!body.trim()) return;
    setSending(true);
    setError("");
    try {
      await post({ data: { game_id: gameId, game_title: gameTitle, body: body.trim() } });
      setBody("");
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "Your comment could not be posted.");
    } finally {
      setSending(false);
    }
  };

  const handleDelete = async (id) => {
    await remove({ data: { id } });
    await router.invalidate();
  };

  return (
    <section className="mt-10 border-t border-border/70 pt-6">
      <h2 className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
        <MessageSquare className="h-3.5 w-3.5" />
        Community · {comments.length}
      </h2>

      {isLoadingAuth ? null : isAuthenticated ? (
        <form onSubmit={submit} className="mt-4 space-y-2">
          <div className="flex items-center gap-2">
            <UserAvatar
              user={{ full_name: displayName(user), avatar_url: displayAvatar(user) }}
              className="h-7 w-7"
            />
            <span className="text-xs text-muted-foreground">Posting as {displayName(user)}</span>
          </div>
          <Textarea
            value={body}
            onChange={(event) => setBody(event.target.value)}
            rows={3}
            maxLength={2000}
            placeholder="What do you think of this build?"
          />
          <div className="flex items-center justify-between gap-3">
            {error && <p className="text-xs text-destructive">{error}</p>}
            <Button type="submit" size="sm" disabled={sending || !body.trim()}>
              {sending && <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />}
              Post comment
            </Button>
          </div>
        </form>
      ) : (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3">
          <p className="text-sm text-muted-foreground">Sign in to join the conversation.</p>
          <Button size="sm" onClick={() => navigateToLogin()}>
            Sign in
          </Button>
        </div>
      )}

      <ul className="mt-5 space-y-3">
        {comments.length === 0 && (
          <li className="rounded-lg border border-dashed border-border px-4 py-8 text-center text-sm text-muted-foreground">
            No comments yet. Be the first.
          </li>
        )}
        {comments.map((comment) => {
          const mine = comment.created_by_id === user?.id;
          return (
            <li key={comment.id} className="rounded-lg border border-border bg-card px-4 py-3">
              <div className="flex items-start gap-3">
                <UserAvatar
                  user={{ full_name: comment.author_name, avatar_url: comment.author_avatar_url }}
                  className="h-8 w-8"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-2">
                      <span className="truncate font-heading text-sm font-medium text-foreground">
                        {comment.author_name || "Player"}
                      </span>
                      <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                        {formatDate(comment.created_date)}
                      </span>
                    </div>
                    {(mine || user?.role === "admin") && (
                      <button
                        type="button"
                        onClick={() => handleDelete(comment.id)}
                        className="text-muted-foreground transition-colors hover:text-destructive"
                        aria-label="Delete comment"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                  <p className="mt-1.5 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                    {comment.body}
                  </p>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}