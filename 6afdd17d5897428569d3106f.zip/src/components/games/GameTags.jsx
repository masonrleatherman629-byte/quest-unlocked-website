import { cn } from "@/lib/utils";

const STATUS_STYLES = {
  Released: "border-primary/50 bg-primary/15 text-primary",
  "In Archive": "border-chart-4/50 bg-chart-4/10 text-chart-4",
  Outdated: "border-accent/50 bg-accent/10 text-accent",
};

// The pill describes the build the library hosts: its newest version's state.
const newestVersion = (versions = []) =>
  [...versions].sort((a, b) => (b.release_date || "").localeCompare(a.release_date || ""))[0] || null;

export function StatusPill({ game }) {
  const status = newestVersion(game?.versions)?.status;
  if (!status) return null;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium",
        STATUS_STYLES[status] || STATUS_STYLES.Outdated
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {status}
    </span>
  );
}

export function OfflinePlayPill({ enabled }) {
  if (!enabled) return null;
  return (
    <span className="inline-flex items-center rounded-full border border-emerald-400/60 bg-emerald-400/10 px-2.5 py-0.5 text-[11px] font-medium text-emerald-300">
      Offline Play
    </span>
  );
}

export function ContentRating({ value }) {
  if (!value) return null;
  return (
    <span className="inline-flex items-center rounded-full border border-border bg-secondary/60 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
      {value}
    </span>
  );
}