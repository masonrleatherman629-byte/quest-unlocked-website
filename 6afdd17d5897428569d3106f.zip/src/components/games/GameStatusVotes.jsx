import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ThumbsDown, ThumbsUp } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { castGameVote, listGameVotes, listMyVotes } from "@/lib/server-fns";
import { cn } from "@/lib/utils";

const ROWS = [
  { kind: "Game", label: "Is this game working?" },
  { kind: "Multiplayer", label: "Is multiplayer working?" },
];

const ANSWERS = ["Working", "Not Working"];

export default function GameStatusVotes({ game }) {
  const { isAuthenticated, navigateToLogin } = useAuth();
  const loadCounts = useServerFn(listGameVotes);
  const loadMine = useServerFn(listMyVotes);
  const vote = useServerFn(castGameVote);
  const [counts, setCounts] = useState({});
  const [mine, setMine] = useState({});
  const [busy, setBusy] = useState(false);

  // The multiplayer question only appears when the store listing says the game has it.
  const rows = ROWS.filter(
    (row) => row.kind !== "Multiplayer" || game.players === "Multiplayer" || game.players === "Both"
  );

  const refresh = async () => {
    const [nextCounts, myVotes] = await Promise.all([
      loadCounts({ data: { game_id: game.id } }),
      isAuthenticated ? loadMine({ data: { game_id: game.id } }) : Promise.resolve([]),
    ]);
    setCounts(nextCounts);
    setMine(Object.fromEntries(myVotes.map((entry) => [entry.kind, entry.status])));
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game.id, isAuthenticated]);

  const handleVote = async (kind, status) => {
    if (!isAuthenticated) {
      navigateToLogin();
      return;
    }
    setBusy(true);
    try {
      await vote({ data: { game_id: game.id, kind, status } });
      await refresh();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-8 space-y-2">
      {rows.map((row) => (
        <div
          key={row.kind}
          className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3"
        >
          <p className="text-sm text-foreground">{row.label}</p>
          <div className="flex flex-wrap items-center gap-2">
            {ANSWERS.map((status) => {
              const count = counts[`${row.kind}:${status}`] || 0;
              const picked = mine[row.kind] === status;
              const positive = status === "Working";
              return (
                <button
                  key={status}
                  type="button"
                  disabled={busy}
                  onClick={() => handleVote(row.kind, status)}
                  className={cn(
                    "flex items-center gap-2 rounded-full border border-border bg-secondary px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-secondary/70 disabled:opacity-60",
                    picked && (positive ? "border-primary bg-primary/15" : "border-destructive bg-destructive/15")
                  )}
                >
                  {positive ? <ThumbsUp className="h-3.5 w-3.5" /> : <ThumbsDown className="h-3.5 w-3.5" />}
                  {status}
                  {count > 0 && (
                    <span
                      className={cn(
                        "flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-[10px] font-semibold text-white",
                        positive ? "bg-emerald-600" : "bg-red-600"
                      )}
                    >
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}