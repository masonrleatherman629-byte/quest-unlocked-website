// One filter card: icon + heading, then its controls.
export default function FilterPanel({ icon: Icon, title, children }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center gap-2">
        {Icon && <Icon className="h-4 w-4 text-primary" aria-hidden="true" />}
        <h3 className="font-heading text-sm font-semibold text-foreground">{title}</h3>
      </div>
      <div className="mt-3">{children}</div>
    </div>
  );
}