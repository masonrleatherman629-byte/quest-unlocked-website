import { TrendingUp } from "lucide-react";
import FilterPanel from "@/components/games/filters/FilterPanel";
import { POPULARITY_OPTIONS, SORT_OPTIONS } from "@/lib/sort-games";
import { cn } from "@/lib/utils";

const buttonClass = (active) =>
  cn(
    "rounded-md border px-3 py-1.5 text-left text-xs transition-colors",
    active
      ? "border-primary bg-primary/20 text-primary"
      : "border-border bg-background/40 text-muted-foreground hover:text-foreground"
  );

// Popularity is ranked on real download counts; the plain orders sit underneath
// so the old ways of sorting stay one click away.
export default function PopularitySort({ sort, onChange }) {
  return (
    <FilterPanel icon={TrendingUp} title="Sort by Popularity">
      <div className="grid gap-1.5 sm:grid-cols-2">
        {POPULARITY_OPTIONS.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            className={buttonClass(sort === option.value)}
          >
            {option.label}
          </button>
        ))}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-1.5 border-t border-border pt-3">
        <span className="mr-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          Or by
        </span>
        {SORT_OPTIONS.filter((option) => option !== "Added").map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => onChange(option)}
            className={cn(
              "rounded-full border px-2.5 py-1 text-[11px] transition-colors",
              sort === option
                ? "border-primary/60 bg-primary/15 text-primary"
                : "border-border text-muted-foreground hover:text-foreground"
            )}
          >
            {option}
          </button>
        ))}
      </div>
    </FilterPanel>
  );
}