import { Puzzle } from "lucide-react";
import FilterPanel from "@/components/games/filters/FilterPanel";
import { cn } from "@/lib/utils";

const MODES = ["Any Mode", "Single Player", "Co-Op", "Multiplayer"];

// Who a build is played with, from the game's player count.
export default function GameModeFilter({ value, onChange }) {
  return (
    <FilterPanel icon={Puzzle} title="Game Mode">
      <div className="flex flex-wrap gap-1.5">
        {MODES.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => onChange(option)}
            className={cn(
              "rounded-md border px-2.5 py-1 text-xs transition-colors",
              value === option
                ? "border-primary bg-primary/20 text-primary"
                : "border-border bg-background/40 text-muted-foreground hover:text-foreground"
            )}
          >
            {option}
          </button>
        ))}
      </div>
    </FilterPanel>
  );
}