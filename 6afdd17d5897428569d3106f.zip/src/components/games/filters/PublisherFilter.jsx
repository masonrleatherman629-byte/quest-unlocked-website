import { useState } from "react";
import { Building2 } from "lucide-react";
import FilterPanel from "@/components/games/filters/FilterPanel";
import FilterSearch from "@/components/games/filters/FilterSearch";
import { cn } from "@/lib/utils";

// Studios and publishers, one picked at a time, with a way back to the whole library.
export default function PublisherFilter({ options, value, onChange }) {
  const [query, setQuery] = useState("");
  const term = query.trim().toLowerCase();
  const visible = options.filter((option) => option.toLowerCase().includes(term));

  return (
    <FilterPanel icon={Building2} title="Publisher/Developer">
      <FilterSearch value={query} onChange={setQuery} placeholder="Search publishers..." />

      <div className="mt-3 grid max-h-64 grid-cols-2 gap-1.5 overflow-y-auto pr-1">
        <button
          type="button"
          onClick={() => onChange("All")}
          className={cn(
            "truncate rounded-md border px-2 py-1.5 text-left text-[11px] transition-colors",
            value === "All"
              ? "border-primary bg-primary/15 text-primary"
              : "border-border bg-background/40 text-foreground hover:border-primary/50"
          )}
        >
          All studios
        </button>
        {visible.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => onChange(value === option ? "All" : option)}
            className={cn(
              "truncate rounded-md border px-2 py-1.5 text-left text-[11px] transition-colors",
              value === option
                ? "border-primary bg-primary/15 text-primary"
                : "border-border bg-background/40 text-foreground hover:border-primary/50"
            )}
            title={option}
          >
            {option}
          </button>
        ))}
        {!visible.length && (
          <p className="col-span-2 py-4 text-center text-xs text-muted-foreground">No studios match.</p>
        )}
      </div>
    </FilterPanel>
  );
}