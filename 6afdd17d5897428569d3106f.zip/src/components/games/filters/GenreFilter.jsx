import { useState } from "react";
import { Tag } from "lucide-react";
import FilterPanel from "@/components/games/filters/FilterPanel";
import FilterSearch from "@/components/games/filters/FilterSearch";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

// Genres are multi-select: relaxed filtering matches ANY picked genre, otherwise
// a game has to carry all of them.
export default function GenreFilter({ options, selected, onChange, relaxed, onRelaxedChange }) {
  const [query, setQuery] = useState("");
  const term = query.trim().toLowerCase();
  const visible = options.filter((option) => option.toLowerCase().includes(term));

  const toggle = (option) => {
    onChange(
      selected.includes(option) ? selected.filter((entry) => entry !== option) : [...selected, option]
    );
  };

  return (
    <FilterPanel icon={Tag} title="Genres">
      <FilterSearch value={query} onChange={setQuery} placeholder="Search genres..." />

      <div className="mt-3 grid max-h-64 grid-cols-3 gap-1.5 overflow-y-auto pr-1">
        {visible.length ? (
          visible.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => toggle(option)}
              className={cn(
                "truncate rounded-md border px-2 py-1.5 text-left text-[11px] transition-colors",
                selected.includes(option)
                  ? "border-primary bg-primary/15 text-primary"
                  : "border-border bg-background/40 text-foreground hover:border-primary/50"
              )}
              title={option}
            >
              {option}
            </button>
          ))
        ) : (
          <p className="col-span-3 py-4 text-center text-xs text-muted-foreground">No genres match.</p>
        )}
      </div>

      <div className="mt-3 flex items-center justify-between gap-3 border-t border-border pt-3">
        <span className="text-[11px] text-muted-foreground">
          Relaxed Filtering: Match ANY selected genre
        </span>
        <Switch checked={relaxed} onCheckedChange={onRelaxedChange} aria-label="Match any selected genre" />
      </div>
    </FilterPanel>
  );
}