import { useState } from "react";
import { Play } from "lucide-react";
import { Image } from "@/components/ui/image";
import { cn } from "@/lib/utils";

const isVideoFile = (url) => /\.(mp4|webm|mov)(\?|$)/i.test(url);

export default function GameGallery({ game }) {
  // The trailer leads, like the store page: the player sits at the top and every
  // still is a thumbnail underneath it.
  const media = [
    ...(game.video_urls || []).map((src, index) => ({
      type: isVideoFile(src) ? "video" : "link",
      src,
      label: `Video ${index + 1}`,
    })),
    ...(game.image_url ? [{ type: "image", src: game.image_url, label: "Cover" }] : []),
    ...(game.screenshots || []).map((src, index) => ({ type: "image", src, label: `Shot ${index + 1}` })),
  ];
  const [active, setActive] = useState(0);
  const current = media[active];

  if (!media.length) {
    return (
      <div className="flex aspect-[16/10] items-center justify-center rounded-xl border border-border bg-muted font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
        No media uploaded
      </div>
    );
  }

  return (
    <div>
      <div className="overflow-hidden rounded-xl border border-border bg-black">
        {current.type === "image" && (
          <Image
            src={current.src}
            alt={`${game.title} ${current.label}`}
            className="aspect-[16/10] w-full object-cover"
            fittingType="fill"
          />
        )}
        {current.type === "video" && (
          <video key={current.src} src={current.src} controls className="aspect-[16/10] w-full bg-black" />
        )}
        {current.type === "link" && (
          <a
            href={current.src}
            target="_blank"
            rel="noreferrer"
            className="flex aspect-[16/10] w-full flex-col items-center justify-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            <Play className="h-8 w-8" />
            Watch {current.label.toLowerCase()}
          </a>
        )}
      </div>

      {media.length > 1 && (
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {media.map((item, index) => (
            <button
              key={`${item.src}-${index}`}
              type="button"
              onClick={() => setActive(index)}
              className={cn(
                "relative h-16 w-24 shrink-0 overflow-hidden rounded-md border transition-colors",
                index === active ? "border-primary" : "border-border opacity-70 hover:opacity-100"
              )}
              aria-label={item.label}
            >
              {item.type === "image" ? (
                <Image src={item.src} alt={item.label} className="h-full w-full object-cover" fittingType="fill" />
              ) : (
                <span className="flex h-full w-full items-center justify-center bg-secondary text-muted-foreground">
                  <Play className="h-4 w-4" />
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}