import { Search } from "lucide-react";
import { GENRES, PLAYER_MODES } from "@/lib/game-options";
import GameModeFilter from "@/components/games/filters/GameModeFilter";
import GenreFilter from "@/components/games/filters/GenreFilter";
import PopularitySort from "@/components/games/filters/PopularitySort";
import PublisherFilter from "@/components/games/filters/PublisherFilter";
import { cn } from "@/lib/utils";

function ChipRow({ label, options, value, onChange, allLabel }) {
  const choices = allLabel ? [allLabel, ...options] : options;
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <span className="mr-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</span>
      {choices.map((option) => {
        const active = value === option;
        return (
          <button
            key={option}
            type="button"
            onClick={() => onChange(option)}
            className={cn(
              "rounded-full border px-3 py-1 text-xs transition-colors",
              active
                ? "border-primary/60 bg-primary/15 text-primary"
                : "border-border bg-card text-muted-foreground hover:text-foreground"
            )}
          >
            {option}
          </button>
        );
      })}
    </div>
  );
}

export default function LibraryFilters({
  games,
  bundles = [],
  category,
  setCategory,
  status,
  setStatus,
  genres,
  setGenres,
  relaxed,
  setRelaxed,
  mode,
  setMode,
  gameMode,
  setGameMode,
  publisher,
  setPublisher,
  language,
  setLanguage,
  myLanguages = [],
  search,
  setSearch,
  sort,
  setSort,
}) {
  // Bundles live in the library too, so they get their own category tag.
  const categories = [
    ...new Set([...games.map((g) => g.category).filter(Boolean), ...(bundles.length ? ["Bundles"] : [])]),
  ];
  // Every genre the picker offers, plus any custom one already on a game.
  const genreOptions = [...new Set([...GENRES, ...games.flatMap((g) => g.genres || [])])].sort((a, b) =>
    a.localeCompare(b)
  );
  // Every play mode the library supports, so a new one is filterable before any
  // game carries it yet.
  const modes = [...new Set([...PLAYER_MODES, ...games.flatMap((g) => g.player_modes || [])])];
  const languages = [
    ...new Set(games.flatMap((g) => (g.languages || []).map((name) => name.trim())).filter(Boolean)),
  ].sort((a, b) => a.localeCompare(b));
  // Only the statuses the library actually carries, in their natural order.
  const statusOrder = ["Ready", "Not in library", "Draft", "Archived"];
  const statuses = [...new Set(games.map((game) => game.status).filter(Boolean))].sort(
    (a, b) => statusOrder.indexOf(a) - statusOrder.indexOf(b)
  );
  const publishers = [
    ...new Set(games.map((g) => g.developer?.trim()).filter(Boolean)),
  ].sort((a, b) => a.localeCompare(b));

  return (
    <div className="flex flex-col gap-3 border-b border-border/70 pb-6">
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search builds, studios, genres"
          aria-label="Search the library"
          className="h-10 w-full rounded-md border border-input bg-transparent pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
        />
      </div>

      <ChipRow label="Category" options={categories} value={category} onChange={setCategory} allLabel="All" />

      {statuses.length > 1 && (
        <ChipRow label="Status" options={statuses} value={status} onChange={setStatus} allLabel="All" />
      )}

      <div className="grid items-start gap-3 md:grid-cols-2">
        <GenreFilter
          options={genreOptions}
          selected={genres}
          onChange={setGenres}
          relaxed={relaxed}
          onRelaxedChange={setRelaxed}
        />
        <GameModeFilter value={gameMode} onChange={setGameMode} />
        <PublisherFilter options={publishers} value={publisher} onChange={setPublisher} />
        <PopularitySort sort={sort} onChange={setSort} />
      </div>

      {modes.length > 0 && (
        <ChipRow label="Play mode" options={modes} value={mode} onChange={setMode} allLabel="All" />
      )}
      {languages.length > 0 && (
        <ChipRow
          label="Language"
          options={myLanguages.length ? ["My languages", ...languages] : languages}
          value={language}
          onChange={setLanguage}
          allLabel="All"
        />
      )}
    </div>
  );
}