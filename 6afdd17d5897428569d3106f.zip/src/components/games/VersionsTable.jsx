import { cn } from "@/lib/utils";

const STATUS_STYLES = {
  Released: "border-primary/50 bg-primary/15 text-primary",
  "In Archive": "border-accent/50 bg-accent/15 text-accent",
  Outdated: "border-border bg-secondary/60 text-muted-foreground",
};

const formatDate = (value) => {
  if (!value) return "—";
  const date = new Date(`${value}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric", timeZone: "UTC" });
};

// Newest build first, so the table reads like a changelog.
const ordered = (versions) =>
  [...versions].sort((a, b) => (b.release_date || "").localeCompare(a.release_date || ""));

export default function VersionsTable({ versions = [] }) {
  if (!versions.length) return null;
  const rows = ordered(versions);

  return (
    <div className="mt-8 border-t border-border/70 pt-6">
      <h2 className="font-heading text-lg font-semibold text-foreground">
        Versions <span className="font-normal text-muted-foreground">({rows.length})</span>
      </h2>
      <div className="mt-3 overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead>
            <tr className="border-b border-border font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              <th className="px-4 py-3 font-normal">Version name</th>
              <th className="px-4 py-3 font-normal">Version code</th>
              <th className="px-4 py-3 font-normal">Size</th>
              <th className="px-4 py-3 font-normal">Release date</th>
              <th className="px-4 py-3 font-normal">Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr
                key={`${row.version_name}-${index}`}
                className="border-b border-border/60 last:border-0"
              >
                <td className="px-4 py-3 font-medium text-foreground">{row.version_name}</td>
                <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{row.version_code || "—"}</td>
                <td className="px-4 py-3 text-muted-foreground">{row.size_label || "—"}</td>
                <td className="px-4 py-3 text-muted-foreground">{formatDate(row.release_date)}</td>
                <td className="px-4 py-3">
                  <span
                    className={cn(
                      "rounded-full border px-2.5 py-0.5 text-[11px]",
                      STATUS_STYLES[row.status] || STATUS_STYLES.Outdated
                    )}
                  >
                    {row.status || "Outdated"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}