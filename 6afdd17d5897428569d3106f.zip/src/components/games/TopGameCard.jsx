import { Link } from "@tanstack/react-router";
import { Image } from "@/components/ui/image";
import RatingStars from "@/components/games/RatingStars";

// One tile of the Top Games wall: rank, cover, build number and rating.
export default function TopGameCard({ game, rank }) {
  return (
    <Link
      to="/games/$gameId"
      params={{ gameId: game.id }}
      className="group flex flex-col overflow-hidden rounded-lg border border-border bg-card transition-colors hover:border-primary/50"
    >
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-muted">
        {game.image_url ? (
          <Image
            src={game.image_url}
            alt={`${game.title} cover art`}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
            fittingType="fill"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            No artwork
          </div>
        )}

        <span className="absolute left-2 top-2 flex h-6 min-w-6 items-center justify-center rounded bg-background/85 px-1.5 font-mono text-[11px] font-semibold text-primary backdrop-blur">
          {rank}
        </span>

        {game.version && (
          <span className="absolute right-2 top-2 rounded bg-destructive px-1.5 py-0.5 font-mono text-[10px] font-medium text-destructive-foreground">
            Build {game.version}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-1 p-3">
        <h3 className="truncate font-heading text-sm font-semibold text-foreground">{game.title}</h3>
        <p className="truncate text-[11px] text-muted-foreground">{game.developer || "Unknown studio"}</p>
        {game.rating > 0 && (
          <div className="mt-auto pt-1.5">
            <RatingStars rating={game.rating} count={game.rating_count} />
          </div>
        )}
      </div>
    </Link>
  );
}