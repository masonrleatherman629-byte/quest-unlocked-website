import GameCard from "@/components/games/GameCard";
import BundleCard from "@/components/bundles/BundleCard";

export default function GameGrid({ games, bundles = [] }) {
  if (!games.length && !bundles.length) {
    return (
      <div className="rounded-xl border border-dashed border-border bg-card/50 px-6 py-16 text-center">
        <p className="font-heading text-lg text-foreground">Nothing matches that filter</p>
        <p className="mt-1 text-sm text-muted-foreground">Try another category or genre.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {games.map((game) => (
        <GameCard key={game.id} game={game} />
      ))}
      {bundles.map((bundle) => (
        <BundleCard key={bundle.id} bundle={bundle} count={(bundle.game_ids || []).length} />
      ))}
    </div>
  );
}