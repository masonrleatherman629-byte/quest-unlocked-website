import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, ChevronLeft, ChevronRight } from "lucide-react";
import { Image } from "@/components/ui/image";
import { Button } from "@/components/ui/button";
import { trackDownload } from "@/lib/download-tracker";
import { cn } from "@/lib/utils";

const DURATION = 7000;

const versionLabel = (version) => {
  const value = (version || "").trim();
  if (!value) return "";
  return /^v/i.test(value) ? value : `v${value}`;
};

export default function FeaturedCarousel({ games }) {
  const count = games.length;
  const [index, setIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (count < 2) return;
    setProgress(0);
    const frame = requestAnimationFrame(() => setProgress(100));
    const timer = setTimeout(() => setIndex((current) => (current + 1) % count), DURATION);
    return () => {
      cancelAnimationFrame(frame);
      clearTimeout(timer);
    };
  }, [index, count]);

  if (!count) return null;

  const game = games[Math.min(index, count - 1)];
  const step = (delta) => setIndex((current) => (current + delta + count) % count);

  return (
    <section className="overflow-hidden rounded-2xl border border-border bg-card">
      <div className="relative min-h-[320px] sm:min-h-[380px] lg:min-h-[420px]">
        <Image
          key={game.id}
          src={game.image_url}
          alt={`${game.title} artwork`}
          className="absolute inset-0 h-full w-full object-cover"
          fittingType="fill"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-background/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

        <div className="relative flex min-h-[320px] items-center px-6 py-10 sm:min-h-[380px] sm:px-10 lg:min-h-[420px]">
          <div className="max-w-xl">
            <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-primary">Featured build</p>
            <h2 className="mt-3 font-heading text-3xl font-semibold uppercase leading-none tracking-tight text-foreground sm:text-5xl">
              {game.title}
            </h2>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              {game.version && (
                <span className="rounded-full bg-primary/15 px-2.5 py-1 font-mono text-[11px] font-medium text-primary">
                  {versionLabel(game.version)}
                </span>
              )}
              <span className="rounded-full border border-border bg-background/70 px-2.5 py-1 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                {(game.headsets || [])[0] || "Meta Quest"}
              </span>
              {game.players && (
                <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                  {game.players}
                </span>
              )}
              {game.release_date && (
                <span className="font-mono text-[11px] text-muted-foreground">{game.release_date.slice(0, 4)}</span>
              )}
            </div>

            {game.description && (
              <p className="mt-4 line-clamp-3 text-sm leading-relaxed text-muted-foreground">{game.description}</p>
            )}

            <div className="mt-6 flex flex-wrap items-center gap-2">
              <Button asChild size="lg">
                {game.download_url ? (
                  <a
                    href={game.download_url}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => trackDownload(game)}
                  >
                    Download Now
                    <ArrowRight className="ml-1 h-4 w-4 shrink-0" />
                  </a>
                ) : (
                  <Link to="/games/$gameId" params={{ gameId: game.id }}>
                    Download Now
                    <ArrowRight className="ml-1 h-4 w-4 shrink-0" />
                  </Link>
                )}
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/games/$gameId" params={{ gameId: game.id }}>
                  Details
                  <ChevronRight className="ml-1 h-4 w-4 shrink-0" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {count > 1 && (
        <div className="flex items-center gap-4 border-t border-border/60 bg-background/60 px-6 py-3 sm:px-10">
          <div className="h-1 flex-1 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary"
              style={{
                width: `${progress}%`,
                transition: progress ? `width ${DURATION}ms linear` : "none",
              }}
            />
          </div>

          <div className="hidden items-center gap-1.5 sm:flex">
            {games.map((item, dot) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setIndex(dot)}
                aria-label={`Show ${item.title}`}
                className={cn(
                  "h-1.5 rounded-full transition-all",
                  dot === index ? "w-4 bg-primary" : "w-1.5 bg-muted-foreground/40 hover:bg-muted-foreground"
                )}
              />
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => step(-1)}
              aria-label="Previous featured game"
              className="rounded-full border border-border p-1.5 text-muted-foreground transition-colors hover:text-foreground"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => step(1)}
              aria-label="Next featured game"
              className="rounded-full border border-border p-1.5 text-muted-foreground transition-colors hover:text-foreground"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
}