import { ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

const STYLES = {
  Published: "border-primary/50 bg-primary/10 text-primary",
  "Coming soon": "border-accent/50 bg-accent/10 text-accent",
  "Not on store": "border-border bg-secondary/60 text-muted-foreground",
};

const LABELS = {
  Published: "On the Quest Store",
  "Coming soon": "Coming to the store",
  "Not on store": "Not on the store yet",
};

export default function StoreStatusBadge({ status, url, className }) {
  if (!status) return null;
  const label = LABELS[status] || status;
  const classes = cn(
    "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.14em]",
    STYLES[status] || STYLES["Not on store"],
    className
  );

  if (url) {
    return (
      <a href={url} target="_blank" rel="noreferrer" className={classes}>
        {label}
        <ExternalLink className="h-3 w-3" />
      </a>
    );
  }

  return <span className={classes}>{label}</span>;
}