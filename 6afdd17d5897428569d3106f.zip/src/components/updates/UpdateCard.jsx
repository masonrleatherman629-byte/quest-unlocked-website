import { Badge } from "@/components/ui/badge";

const formatDate = (value) =>
  value ? new Date(value).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "";

export default function UpdateCard({ update }) {
  return (
    <article className="rounded-xl border border-border bg-card p-5">
      <div className="flex flex-wrap items-center gap-2">
        <Badge variant="secondary" className="font-mono text-[10px] uppercase tracking-[0.14em]">
          {update.kind}
        </Badge>
        <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
          {formatDate(update.created_date)}
        </span>
      </div>
      <h2 className="mt-3 font-heading text-xl font-semibold text-foreground">{update.title}</h2>
      <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{update.body}</p>
    </article>
  );
}