import { CheckCircle2, Loader2, Usb, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const STEPS = [
  "Turn on developer mode for your headset in the Meta Horizon app.",
  "Plug a USB-C to USB-C cable into the headset and into the device you are using right now.",
  "Press Connect Quest, then put the headset on and tap Allow on the \"Allow USB debugging?\" prompt that appears inside it.",
];

export default function QuestConnectPanel({ status, error, onConnect, onDisconnect }) {
  const connected = status === "connected";
  const connecting = status === "connecting";

  return (
    <div className="mt-6 rounded-xl border border-border bg-card p-5">
      <ol className="space-y-2 text-sm text-muted-foreground">
        {STEPS.map((step, index) => (
          <li key={step} className="flex gap-2">
            <span className="font-mono text-xs text-primary">{index + 1}.</span>
            <span>{step}</span>
          </li>
        ))}
      </ol>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <Button onClick={connected ? onDisconnect : onConnect} disabled={connecting}>
          {connecting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Usb className="mr-2 h-4 w-4" />}
          {connected ? "Disconnect" : connecting ? "Connecting…" : "Connect Quest"}
        </Button>

        <span className="flex items-center gap-2 text-sm">
          {connected ? (
            <CheckCircle2 className="h-4 w-4 text-primary" />
          ) : connecting ? (
            <Loader2 className="h-4 w-4 animate-spin text-primary" />
          ) : (
            <XCircle className="h-4 w-4 text-muted-foreground" />
          )}
          <span className={connected ? "text-foreground" : "text-muted-foreground"}>
            {connected ? "Connected successfully" : connecting ? "Connecting to your headset…" : "Not connected"}
          </span>
        </span>
      </div>

      {error && <p className="mt-3 text-sm text-destructive">{error}</p>}

      <p className="mt-4 text-xs text-muted-foreground">
        Use Chrome or Edge on the device the cable is plugged into. APK, APK + OBB and ZIP builds install directly. RAR
        and 7z files still need SideQuest.
      </p>
    </div>
  );
}