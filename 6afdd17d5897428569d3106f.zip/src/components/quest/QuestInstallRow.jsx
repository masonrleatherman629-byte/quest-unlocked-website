import { CheckCircle2, Download, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Image } from "@/components/ui/image";
import TransferProgress from "@/components/downloads/TransferProgress";
import { useQuest } from "@/lib/QuestContext";

export default function QuestInstallRow({ game }) {
  const { connection, install, startInstall } = useQuest();
  const mine = install?.gameId === game.id ? install : null;
  const installing = mine?.state === "installing";
  const done = mine?.state === "done";
  const busy = install?.state === "installing";

  const details = [game.version && `v${game.version}`, game.size_label, game.file_name].filter(Boolean).join(" · ");

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex flex-wrap items-center gap-4">
        <Image
          src={game.image_url}
          alt={game.title}
          className="h-14 w-14 shrink-0 rounded-lg object-cover"
          fittingType="fill"
        />
        <div className="min-w-0 flex-1">
          <p className="truncate font-heading text-sm font-semibold text-foreground">{game.title}</p>
          {details && <p className="truncate text-xs text-muted-foreground">{details}</p>}
        </div>
        <Button size="sm" onClick={() => startInstall(game)} disabled={!connection || busy}>
          {installing ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : done ? (
            <CheckCircle2 className="mr-2 h-4 w-4" />
          ) : (
            <Download className="mr-2 h-4 w-4" />
          )}
          {installing ? `${mine.progress}%` : done ? "Installed" : "Install"}
        </Button>
      </div>

      {installing && <TransferProgress progress={mine.progress} speed={mine.speed} />}

      {mine?.state === "failed" && <p className="mt-2 text-xs text-destructive">{mine.error}</p>}
    </div>
  );
}