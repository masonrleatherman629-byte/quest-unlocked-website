import { useQuest } from "@/lib/QuestContext";
import TransferProgress from "@/components/downloads/TransferProgress";

// A compact readout of the install running right now, so it can be watched from
// anywhere on the site.
export default function InstallProgressCard() {
  const { install } = useQuest();
  if (!install || install.state === "done") return null;

  return (
    <section className="mx-auto w-full max-w-6xl px-5 pt-8">
      <div className="rounded-xl border border-primary/40 bg-card p-4">
        <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">
          {install.state === "failed" ? "Install failed" : "Installing to your headset"}
        </p>
        <p className="mt-1 truncate font-heading text-sm font-semibold text-foreground">{install.title}</p>
        {install.state === "installing" ? (
          <TransferProgress progress={install.progress} speed={install.speed} />
        ) : (
          <p className="mt-1.5 text-xs text-destructive">{install.error}</p>
        )}
      </div>
    </section>
  );
}