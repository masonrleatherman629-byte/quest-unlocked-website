import { useRef, useState } from "react";
import { CheckCircle2, Download, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trackDownload } from "@/lib/download-tracker";
import TransferProgress from "@/components/downloads/TransferProgress";
import { downloadFile } from "@/lib/file-download";
import { createSpeedMeter } from "@/lib/speed-meter";
import { cn } from "@/lib/utils";

export default function DownloadButton({
  url,
  fileName,
  gameId,
  gameTitle,
  label = "Download game",
  size = "default",
  className,
}) {
  const [state, setState] = useState("idle");
  const [progress, setProgress] = useState(0);
  const [speed, setSpeed] = useState(0);
  const [error, setError] = useState("");
  const meter = useRef(null);

  const start = async () => {
    setState("downloading");
    setProgress(0);
    setSpeed(0);
    setError("");
    meter.current = createSpeedMeter();
    trackDownload({ id: gameId, title: gameTitle });
    try {
      await downloadFile(url, fileName, (received, total) => {
        setProgress(total ? Math.round((received / total) * 100) : 0);
        const next = meter.current(received);
        if (next !== undefined) setSpeed(next);
      });
      setState("done");
      setProgress(100);
    } catch (err) {
      setState("idle");
      setError(err?.cancelled ? "" : err?.message || "This build could not be downloaded.");
    }
  };

  const downloading = state === "downloading";

  return (
    <div className={cn("w-full sm:w-auto", className)}>
      <Button size={size} onClick={start} disabled={downloading} className="w-full">
        {downloading ? (
          <Loader2 className="mr-2 h-4 w-4 shrink-0 animate-spin" />
        ) : state === "done" ? (
          <CheckCircle2 className="mr-2 h-4 w-4 shrink-0" />
        ) : (
          <Download className="mr-2 h-4 w-4 shrink-0" />
        )}
        <span className="truncate">{downloading ? `${progress}%` : state === "done" ? "Downloaded" : label}</span>
      </Button>
      {downloading && <TransferProgress progress={progress} speed={speed} />}
      {error && <p className="mt-1.5 text-xs text-destructive">{error}</p>}
    </div>
  );
}