import { Link } from "@tanstack/react-router";
import { Image } from "@/components/ui/image";
import RatingStars from "@/components/games/RatingStars";
import DownloadButton from "@/components/downloads/DownloadButton";

export default function DownloadCard({ game }) {
  const meta = [game.version ? `v${game.version}` : "", game.size_label, game.file_name].filter(Boolean);

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-3 sm:flex-row sm:items-center sm:gap-4 sm:p-4">
      <div className="h-16 w-24 shrink-0 overflow-hidden rounded-md border border-border bg-muted">
        {game.image_url ? (
          <Image
            src={game.image_url}
            alt={`${game.title} artwork`}
            className="h-full w-full object-cover"
            fittingType="fill"
          />
        ) : (
          <div className="flex h-full items-center justify-center font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
            None
          </div>
        )}
      </div>

      <div className="min-w-0 flex-1">
        <Link
          to="/games/$gameId"
          params={{ gameId: game.id }}
          className="block truncate font-heading text-base font-semibold text-foreground transition-colors hover:text-primary"
        >
          {game.title}
        </Link>
        <p className="truncate text-xs text-muted-foreground">{game.developer || "Unknown developer"}</p>
        {meta.length > 0 && (
          <p className="mt-1 truncate font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            {meta.join(" · ")}
          </p>
        )}
        {game.rating > 0 && (
          <div className="mt-1.5">
            <RatingStars rating={game.rating} count={game.rating_count} />
          </div>
        )}
      </div>

      <DownloadButton
        url={game.download_url}
        fileName={game.file_name}
        gameId={game.id}
        gameTitle={game.title}
        className="shrink-0"
      />
    </div>
  );
}