export default function TransferProgress({ progress, speed }) {
  return (
    <div className="mt-2">
      <div className="h-1.5 overflow-hidden rounded-full bg-secondary">
        <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
      </div>
      <p className="mt-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
        {progress}%{speed > 0 ? ` · ${speed.toFixed(1)} MB/s` : ""}
      </p>
    </div>
  );
}