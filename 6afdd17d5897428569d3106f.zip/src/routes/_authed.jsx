import { Outlet, createFileRoute } from "@tanstack/react-router";
import { AuthGateError, requireSignedIn } from "@/components/auth/AuthGate";
import Layout from "@/components/Layout";

export const Route = createFileRoute("/_authed")({
  ssr: false,
  beforeLoad: requireSignedIn,
  errorComponent: AuthGateError,
  component: AuthedLayout,
});

// Signed-in pages keep the site header, so there is always a way back to the
// library from the manage area.
function AuthedLayout() {
  return (
    <Layout>
      <Outlet />
    </Layout>
  );
}