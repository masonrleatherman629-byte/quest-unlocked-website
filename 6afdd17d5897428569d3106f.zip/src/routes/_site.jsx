import { createFileRoute, Outlet } from "@tanstack/react-router";
import Layout from "@/components/Layout";
import MaintenanceScreen from "@/components/MaintenanceScreen";
import { useAuth } from "@/lib/AuthContext";
import { QuestProvider } from "@/lib/QuestContext";
import { getSiteConfig } from "@/lib/site-config-fns";

export const Route = createFileRoute("/_site")({
  loader: () => getSiteConfig(),
  component: SiteLayout,
});

function SiteLayout() {
  const config = Route.useLoaderData();
  const { user } = useAuth();

  // Admins keep the site open so they can finish the work and switch it back on.
  if (config.maintenance && user?.role !== "admin") {
    return <MaintenanceScreen message={config.message} />;
  }

  return (
    <QuestProvider>
      <Layout>
        <Outlet />
      </Layout>
    </QuestProvider>
  );
}