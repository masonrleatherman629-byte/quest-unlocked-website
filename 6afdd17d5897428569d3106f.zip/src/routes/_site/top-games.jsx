import { createFileRoute } from "@tanstack/react-router";
import TopGameCard from "@/components/games/TopGameCard";
import { publicGames } from "@/lib/benchmark-stats";
import { listGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/top-games")({
  loader: () => listGames(),
  head: () => ({
    meta: [
      { title: "Top Games — Quest Unlocked" },
      {
        name: "description",
        content: "The highest rated VR builds in the Quest Unlocked library.",
      },
    ],
  }),
  component: TopGamesPage,
});

function TopGamesPage() {
  const games = Route.useLoaderData();
  const top = publicGames(games)
    .sort(
      (a, b) =>
        (b.rating ?? 0) - (a.rating ?? 0) || (b.rating_count ?? 0) - (a.rating_count ?? 0)
    )
    .slice(0, 12);

  return (
    <div className="mx-auto w-full max-w-5xl px-5 py-12">
      <div className="flex justify-center">
        <span className="rounded-full bg-primary/15 px-5 py-1.5 font-mono text-[11px] uppercase tracking-[0.26em] text-primary">
          Top Games
        </span>
      </div>
      <h1 className="mt-4 text-center font-heading text-4xl font-semibold tracking-tight text-foreground">
        The best of the library
      </h1>
      <p className="mx-auto mt-2 max-w-xl text-center text-sm text-muted-foreground">
        Ranked by store rating, then by how many people rated it. Every tile opens its game page.
      </p>

      {top.length ? (
        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {top.map((game, index) => (
            <TopGameCard key={game.id} game={game} rank={index + 1} />
          ))}
        </div>
      ) : (
        <div className="mt-10 rounded-xl border border-dashed border-border px-6 py-16 text-center">
          <p className="font-heading text-lg text-foreground">No games ranked yet</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Add builds with a store rating and they land here.
          </p>
        </div>
      )}
    </div>
  );
}