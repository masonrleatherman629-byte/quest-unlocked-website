import { createFileRoute } from "@tanstack/react-router";
import { Gamepad2, Laptop, Monitor, Terminal } from "lucide-react";
import LauncherPlatformCard from "@/components/launcher/LauncherPlatformCard";
import LauncherCta from "@/components/launcher/LauncherCta";
import { listLauncherBuilds } from "@/lib/server-fns";

const PLATFORMS = [
  {
    platform: "Meta Quest",
    label: "Meta Quest",
    icon: Gamepad2,
    blurb: "Install builds straight to the headset, no cable needed.",
    href: "/launcher/quest",
    actionLabel: "Open in your headset",
  },
  {
    platform: "Windows",
    label: "Windows",
    icon: Monitor,
    blurb: "Side-load over USB or Wi-Fi from your PC.",
  },
  {
    platform: "Linux",
    label: "Linux",
    icon: Terminal,
    blurb: "A single portable binary, no install required.",
  },
  {
    platform: "macOS",
    label: "macOS",
    icon: Laptop,
    blurb: "Universal build for Apple silicon and Intel Macs.",
  },
];

export const Route = createFileRoute("/_site/launcher")({
  loader: () => listLauncherBuilds(),
  head: () => ({
    meta: [
      { title: "Moon Launcher — Quest Unlocked" },
      {
        name: "description",
        content:
          "Moon Launcher installs and updates Quest Unlocked builds on Meta Quest, Windows, Linux and macOS.",
      },
    ],
  }),
  component: LauncherPage,
});

function LauncherPage() {
  const builds = Route.useLoaderData();
  const byPlatform = (platform) => builds.find((build) => build.platform === platform) || null;

  return (
    <section className="mx-auto w-full max-w-6xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-launcher">Moon Launcher</p>
      <h1 className="mt-2 max-w-2xl font-heading text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
        One launcher for every build in the library
      </h1>
      <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">
        Moon Launcher installs and updates Quest Unlocked builds on your headset and on desktop. Pick your
        platform, download once, and every new build shows up in the launcher.
      </p>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {PLATFORMS.map(({ platform, label, icon, blurb, href, actionLabel }) => (
          <LauncherPlatformCard
            key={platform}
            label={label}
            icon={icon}
            blurb={blurb}
            build={byPlatform(platform)}
            href={href}
            actionLabel={actionLabel}
          />
        ))}
      </div>

      <div className="mt-10">
        <LauncherCta />
      </div>
    </section>
  );
}