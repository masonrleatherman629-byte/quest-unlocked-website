import { Link, Outlet, createFileRoute } from "@tanstack/react-router";
import { ArrowLeft, Download, Gamepad2, LayoutGrid } from "lucide-react";
import { useQuestLibrary } from "@/hooks/use-quest-library";
import QuestBuildBar from "@/components/launcher/QuestBuildBar";
import { listLauncherBuilds } from "@/lib/server-fns";
import { cn } from "@/lib/utils";

const TABS = [
  { to: "/launcher/quest", label: "My library", icon: LayoutGrid, exact: true },
  { to: "/launcher/quest/browse", label: "Browse builds", icon: Gamepad2 },
  { to: "/launcher/quest/downloads", label: "Downloads", icon: Download },
];

export const Route = createFileRoute("/_site/launcher_/quest")({
  head: () => ({
    meta: [
      { title: "Moon Launcher for Meta Quest — Quest Unlocked" },
      {
        name: "description",
        content:
          "Moon Launcher on Meta Quest: install, update and remove Quest Unlocked builds straight from the headset browser.",
      },
    ],
  }),
  loader: () => listLauncherBuilds(),
  component: QuestLauncherShell,
});

function QuestLauncherShell() {
  const builds = Route.useLoaderData();
  const questBuild = builds.find((build) => build.platform === "Meta Quest") || null;
  const { installed, ready } = useQuestLibrary();
  const count = Object.keys(installed).length;

  return (
    <section className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6">
      <Link
        to="/launcher"
        className="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        All platforms
      </Link>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl border border-launcher/40 bg-launcher/10 text-launcher">
          <Gamepad2 className="h-6 w-6" />
        </span>
        <div className="min-w-0 flex-1">
          <h1 className="font-heading text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            Moon Launcher
          </h1>
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-launcher">
            Meta Quest · runs in the headset browser
          </p>
        </div>
        <span className="rounded-full border border-border bg-card px-3 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
          {ready ? `${count} installed` : "Checking headset…"}
        </span>
      </div>

      <QuestBuildBar build={questBuild} />

      <nav className="mt-6 flex flex-wrap gap-2">
        {TABS.map(({ to, label, icon: Icon, exact }) => (
          <Link
            key={to}
            to={to}
            activeOptions={{ exact }}
            className="inline-flex h-12 items-center gap-2 rounded-xl border border-border bg-card px-4 font-heading text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            activeProps={{
              className: cn(
                "inline-flex h-12 items-center gap-2 rounded-xl border border-launcher/50 bg-launcher/15 px-4 font-heading text-sm font-semibold text-launcher"
              ),
            }}
          >
            <Icon className="h-4 w-4" />
            {label}
          </Link>
        ))}
      </nav>

      <div className="mt-6">
        <Outlet />
      </div>

      <p className="mt-10 text-xs leading-relaxed text-muted-foreground">
        Installs download to your headset. Launch them from Unknown Sources in your Quest library.
      </p>
    </section>
  );
}