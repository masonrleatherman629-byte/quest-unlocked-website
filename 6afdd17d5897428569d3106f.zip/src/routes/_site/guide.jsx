import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, MessageCircle } from "lucide-react";
import { Image } from "@/components/ui/image";
import { DISCORD_URL } from "@/lib/links";
import { listGuideSections } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/guide")({
  loader: () => listGuideSections(),
  head: () => ({
    meta: [
      { title: "Guide — Quest Unlocked" },
      { name: "description", content: "Step-by-step help for downloading, sideloading and playing Quest builds." },
    ],
  }),
  component: GuidePage,
});

function GuidePage() {
  const sections = Route.useLoaderData();

  return (
    <div className="mx-auto w-full max-w-5xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Guide</p>
      <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">
        Everything you need to get a build running
      </h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        From your first download to a full sideload, these steps cover the whole trip.
      </p>

      {sections.length ? (
        <div className="mt-8 grid gap-8 lg:grid-cols-[220px_minmax(0,1fr)]">
          <nav aria-label="Guide steps" className="hidden lg:block">
            <div className="sticky top-24 space-y-1">
              {sections.map((section, index) => (
                <a
                  key={section.id}
                  href={`#step-${index + 1}`}
                  className="block truncate rounded-md px-2 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-secondary/60 hover:text-foreground"
                >
                  {String(index + 1).padStart(2, "0")} · {section.title}
                </a>
              ))}
            </div>
          </nav>

          <div className="space-y-6">
            {sections.map((section, index) => (
              <article
                key={section.id}
                id={`step-${index + 1}`}
                className="scroll-mt-24 rounded-xl border border-border bg-card p-6"
              >
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-primary">
                  Step {String(index + 1).padStart(2, "0")}
                </p>
                <h2 className="mt-2 font-heading text-xl font-semibold text-foreground">{section.title}</h2>
                {section.image_url && (
                  <div className="mt-4 overflow-hidden rounded-lg border border-border">
                    <Image
                      src={section.image_url}
                      alt={section.title}
                      className="h-auto w-full object-cover"
                      fittingType="fit"
                    />
                  </div>
                )}
                <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{section.body}</p>
              </article>
            ))}

            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="flex items-center gap-2 font-heading text-lg font-semibold text-foreground">
                <BookOpen className="h-4 w-4 text-primary" />
                Still stuck?
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Ask in the community Discord or{" "}
                <Link to="/requests" className="font-medium text-primary hover:underline">
                  send a request
                </Link>{" "}
                and the team will help.
              </p>
              <a
                href={DISCORD_URL}
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
              >
                <MessageCircle className="h-4 w-4" />
                Join the Discord
              </a>
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-8 rounded-xl border border-dashed border-border bg-card/50 px-6 py-16 text-center">
          <p className="font-heading text-lg text-foreground">The guide is being written</p>
          <p className="mt-1 text-sm text-muted-foreground">Check back soon, or ask in the Discord.</p>
        </div>
      )}
    </div>
  );
}