import { createFileRoute, Link } from "@tanstack/react-router";
import { Package } from "lucide-react";
import DownloadCard from "@/components/downloads/DownloadCard";
import { listGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/downloads")({
  loader: () => listGames(),
  head: () => ({
    meta: [
      { title: "Downloads — Quest Unlocked" },
      {
        name: "description",
        content: "Every Meta Quest build in the library that is ready to download right now.",
      },
    ],
  }),
  component: DownloadsPage,
});

function DownloadsPage() {
  const games = Route.useLoaderData();
  const builds = games.filter((game) => game.status !== "Archived" && game.download_url);

  return (
    <div className="mx-auto w-full max-w-4xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Downloads</p>
      <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">Grab a build</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        {builds.length} {builds.length === 1 ? "build" : "builds"} ready to sideload. Unzip the file, then push the APK
        with SideQuest or the Meta Quest Developer Hub.
      </p>

      {builds.length > 0 ? (
        <div className="mt-8 space-y-3">
          {builds.map((game) => (
            <DownloadCard key={game.id} game={game} />
          ))}
        </div>
      ) : (
        <div className="mt-8 flex flex-col items-center gap-3 rounded-xl border border-border bg-card px-5 py-14 text-center">
          <Package className="h-6 w-6 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">No builds have a file attached yet.</p>
          <Link to="/" className="text-sm text-primary hover:underline">
            Back to the library
          </Link>
        </div>
      )}
    </div>
  );
}