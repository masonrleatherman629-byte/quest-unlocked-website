import { createFileRoute } from "@tanstack/react-router";
import PublisherCard from "@/components/publishers/PublisherCard";
import { listGames, listPublishers } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/publishers/")({
  loader: async () => {
    const [publishers, games] = await Promise.all([listPublishers(), listGames()]);
    return { publishers, games };
  },
  head: () => ({
    meta: [
      { title: "Publishers — Quest Unlocked" },
      { name: "description", content: "Every studio publishing VR builds on Quest Unlocked." },
    ],
  }),
  component: PublishersPage,
});

function PublishersPage() {
  const { publishers, games } = Route.useLoaderData();

  // Counts include builds that only carry the studio name as their developer.
  const counts = publishers.reduce((totals, publisher) => {
    const key = (publisher.name || "").trim().toLowerCase();
    totals[publisher.id] = games.filter(
      (game) =>
        game.publisher_id === publisher.id ||
        (key && (game.developer || "").trim().toLowerCase() === key)
    ).length;
    return totals;
  }, {});

  return (
    <section className="mx-auto w-full max-w-6xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-primary">Studios</p>
      <div className="mt-2 flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">Publishers</h1>
        <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
          {String(publishers.length).padStart(2, "0")} studios
        </span>
      </div>
      <p className="mt-2 max-w-xl text-sm text-muted-foreground">
        Open a publisher to see every build they have published to the library.
      </p>

      {publishers.length ? (
        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2">
          {publishers.map((publisher) => (
            <PublisherCard key={publisher.id} publisher={publisher} gameCount={counts[publisher.id] || 0} />
          ))}
        </div>
      ) : (
        <div className="mt-8 rounded-xl border border-dashed border-border bg-card/50 px-6 py-16 text-center">
          <p className="font-heading text-lg text-foreground">No publishers yet</p>
          <p className="mt-1 text-sm text-muted-foreground">Studios appear here once a game is assigned to one.</p>
        </div>
      )}
    </section>
  );
}