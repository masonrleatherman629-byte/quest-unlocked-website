import { createFileRoute } from "@tanstack/react-router";
import BundleCard from "@/components/bundles/BundleCard";
import { listBundles } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/bundles/")({
  loader: () => listBundles(),
  head: () => ({
    meta: [
      { title: "Bundles — Quest Unlocked" },
      { name: "description", content: "Curated packs of Meta Quest builds from the Quest Unlocked library." },
    ],
  }),
  component: BundlesPage,
});

function BundlesPage() {
  const bundles = Route.useLoaderData();

  return (
    <div className="mx-auto w-full max-w-6xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Bundles</p>
      <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">
        Packs worth installing together
      </h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Each bundle groups library builds around one kind of session, so you can grab a whole set at once.
      </p>

      {bundles.length ? (
        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {bundles.map((bundle) => (
            <BundleCard key={bundle.id} bundle={bundle} count={(bundle.game_ids || []).length} />
          ))}
        </div>
      ) : (
        <div className="mt-8 rounded-xl border border-dashed border-border bg-card/50 px-6 py-16 text-center">
          <p className="font-heading text-lg text-foreground">No bundles yet</p>
          <p className="mt-1 text-sm text-muted-foreground">Bundles appear here as soon as they are published.</p>
        </div>
      )}
    </div>
  );
}