import { createFileRoute } from "@tanstack/react-router";
import QuestGameCard from "@/components/launcher/QuestGameCard";
import { useQuestLibrary } from "@/hooks/use-quest-library";
import { listGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/launcher_/quest/browse")({
  loader: () => listGames(),
  head: () => ({ meta: [{ title: "Browse builds — Moon Launcher on Meta Quest" }] }),
  component: QuestBrowsePage,
});

function QuestBrowsePage() {
  const games = Route.useLoaderData();
  const { installed, install, remove } = useQuestLibrary();
  const available = games.filter((game) => game.status !== "Archived");

  return (
    <div>
      <div className="flex items-end justify-between gap-3">
        <h2 className="font-heading text-lg font-semibold text-foreground">Everything in the library</h2>
        <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
          {available.length} {available.length === 1 ? "build" : "builds"}
        </span>
      </div>

      {available.length ? (
        <div className="mt-4 space-y-3">
          {available.map((game) => (
            <QuestGameCard
              key={game.id}
              game={game}
              installed={installed[game.id]}
              onInstall={install}
              onRemove={remove}
            />
          ))}
        </div>
      ) : (
        <p className="mt-4 rounded-2xl border border-border bg-card px-4 py-12 text-center text-sm text-muted-foreground">
          No builds in the library yet.
        </p>
      )}
    </div>
  );
}