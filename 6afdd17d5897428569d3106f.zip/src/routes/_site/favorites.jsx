import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Heart, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import GameGrid from "@/components/games/GameGrid";
import { useAuth } from "@/lib/AuthContext";
import { listFavorites, listGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/favorites")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Favorites — Quest Unlocked" },
      { name: "description", content: "The builds you saved for later." },
    ],
  }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const { isAuthenticated, isLoadingAuth, navigateToLogin } = useAuth();
  const loadFavorites = useServerFn(listFavorites);
  const loadGames = useServerFn(listGames);
  const [games, setGames] = useState(null);

  useEffect(() => {
    if (!isAuthenticated) {
      setGames(null);
      return;
    }
    let alive = true;
    Promise.all([loadFavorites(), loadGames()])
      .then(([favorites, all]) => {
        if (!alive) return;
        const ids = new Set(favorites.map((favorite) => favorite.game_id));
        setGames(all.filter((game) => ids.has(game.id)));
      })
      .catch(() => {
        if (alive) setGames([]);
      });
    return () => {
      alive = false;
    };
  }, [isAuthenticated, loadFavorites, loadGames]);

  return (
    <div className="mx-auto w-full max-w-6xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Saved</p>
      <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">Favorites</h1>
      <p className="mt-2 text-sm text-muted-foreground">Builds you saved from the library, kept in one place.</p>

      <div className="mt-8">
        {isLoadingAuth ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Loading your favorites
          </div>
        ) : !isAuthenticated ? (
          <div className="flex flex-col items-center gap-3 rounded-xl border border-border bg-card px-5 py-14 text-center">
            <Heart className="h-6 w-6 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Sign in to save builds and keep them here.</p>
            <Button size="sm" onClick={() => navigateToLogin()}>
              Sign in
            </Button>
          </div>
        ) : games === null ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Loading your favorites
          </div>
        ) : games.length ? (
          <GameGrid games={games} />
        ) : (
          <div className="flex flex-col items-center gap-3 rounded-xl border border-border bg-card px-5 py-14 text-center">
            <Heart className="h-6 w-6 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Nothing saved yet. Tap Favorite on a game page.</p>
          </div>
        )}
      </div>
    </div>
  );
}