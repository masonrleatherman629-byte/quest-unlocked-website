import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { ArrowLeft, HardDrive, Package, Headset } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import DownloadButton from "@/components/downloads/DownloadButton";
import GameGallery from "@/components/games/GameGallery";
import CommentSection from "@/components/games/CommentSection";
import FavoriteButton from "@/components/games/FavoriteButton";
import GameStatusVotes from "@/components/games/GameStatusVotes";
import RatingStars from "@/components/games/RatingStars";
import StoreStatusBadge from "@/components/games/StoreStatusBadge";
import VersionsTable from "@/components/games/VersionsTable";
import { ContentRating, OfflinePlayPill, StatusPill } from "@/components/games/GameTags";
import UserAvatar from "@/components/profile/UserAvatar";
import { getGame, getPublisher, listComments } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/games/$gameId")({
  loader: async ({ params }) => {
    const game = await getGame({ data: { id: params.gameId } });
    if (!game) throw notFound();
    const [comments, publisher] = await Promise.all([
      listComments({ data: { game_id: game.id } }),
      game.publisher_id ? getPublisher({ data: { id: game.publisher_id } }) : Promise.resolve(null),
    ]);
    return { game, comments, publisher };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.game?.title ?? "Build"} — Quest Unlocked` },
      {
        name: "description",
        content: loaderData?.game?.description?.slice(0, 155) ?? "A Meta Quest build.",
      },
    ],
  }),
  component: GameDetailPage,
});

// Dates are stored as YYYY-MM-DD, so they are read and shown in UTC on both ends.
const formatReleaseDate = (value) => {
  if (!value) return "";
  const date = new Date(`${value}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric", timeZone: "UTC" });
};

function GameDetailPage() {
  const { game, comments, publisher } = Route.useLoaderData();
  // Listed for its details and store facts, but no build is hosted here yet.
  const notInLibrary = game.status === "Not in library";
  const meta = [
    ["Released", formatReleaseDate(game.release_date)],
    ["Version", game.version],
    ["Size", game.size_label],
    ["Build", game.file_name],
    ["Players", game.players],
    ["Play modes", (game.player_modes || []).join(", ")],
    ["Languages", (game.languages || []).join(", ")],
  ].filter(([, value]) => value);

  return (
    <div className="mx-auto w-full max-w-6xl px-5 py-10">
      <Link
        to="/"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to library
      </Link>

      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div>
          <GameGallery game={game} />

          <div className="mt-6 flex flex-wrap items-center gap-2">
            {notInLibrary && (
              <Badge variant="outline" className="border-accent/60 text-accent">
                Not in library
              </Badge>
            )}
            {game.category && <Badge variant="secondary">{game.category}</Badge>}
            {(game.genres || []).map((genre) => (
              <Badge key={genre} variant="outline" className="text-muted-foreground">
                {genre}
              </Badge>
            ))}
            <StoreStatusBadge status={game.store_status} url={game.store_url} />
            <StatusPill game={game} />
            <OfflinePlayPill enabled={game.offline_play} />
            <ContentRating value={game.content_rating} />
            {game.price && (
              <span className="font-heading text-sm font-semibold text-foreground">{game.price}</span>
            )}
          </div>

          <div className="mt-4 flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0">
              <h1 className="font-heading text-4xl font-semibold tracking-tight text-foreground">{game.title}</h1>
              <p className="mt-1 text-sm text-muted-foreground">By {game.developer || "Unknown developer"}</p>
              {publisher && (
                <p className="mt-1 text-sm text-muted-foreground">
                  Published by{" "}
                  <Link
                    to="/publishers/$publisherId"
                    params={{ publisherId: publisher.id }}
                    className="font-medium text-primary hover:underline"
                  >
                    {publisher.name}
                  </Link>
                </p>
              )}
              {game.author_name && (
                <div className="mt-3 flex items-center gap-2">
                  <UserAvatar
                    user={{ full_name: game.author_name, avatar_url: game.author_avatar_url }}
                    className="h-6 w-6"
                  />
                  <span className="text-xs text-muted-foreground">
                    Added by <span className="font-medium text-foreground">{game.author_name}</span>
                  </span>
                </div>
              )}
              {game.rating > 0 && (
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <RatingStars rating={game.rating} count={game.rating_count} />
                  <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    {game.rating_source || "Meta Quest Store"}
                  </span>
                </div>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {notInLibrary ? (
                <Button size="sm" disabled>
                  <Package className="mr-2 h-4 w-4" />
                  Not in library
                </Button>
              ) : game.download_url ? (
                <DownloadButton
                  url={game.download_url}
                  fileName={game.file_name}
                  gameId={game.id}
                  gameTitle={game.title}
                  label="Download"
                  size="sm"
                />
              ) : (
                <Button size="sm" disabled>
                  <Package className="mr-2 h-4 w-4" />
                  Unavailable
                </Button>
              )}
              <FavoriteButton game={game} />
            </div>
          </div>

          <GameStatusVotes game={game} />

          {game.description && (
            <div className="mt-8 border-t border-border/70 pt-6">
              <h2 className="font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
                About this build
              </h2>
              <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
                {game.description}
              </p>
            </div>
          )}

          <VersionsTable versions={game.versions || []} />

          <CommentSection gameId={game.id} gameTitle={game.title} comments={comments} />
        </div>

        <aside className="space-y-4">
          <div className="rounded-xl border border-border bg-card p-5">
            {meta.length > 0 && (
              <dl className="space-y-3">
                {meta.map(([label, value]) => (
                  <div key={label} className="flex items-baseline justify-between gap-3">
                    <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                      {label}
                    </dt>
                    <dd className="truncate text-sm text-foreground">{value}</dd>
                  </div>
                ))}
              </dl>
            )}
          </div>

          {(game.headsets || []).length > 0 && (
            <div className="rounded-xl border border-border bg-card p-5">
              <h2 className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                <Headset className="h-3.5 w-3.5" />
                Compatible headsets
              </h2>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {game.headsets.map((headset) => (
                  <span
                    key={headset}
                    className="rounded-full border border-border bg-secondary/60 px-2.5 py-1 text-xs text-muted-foreground"
                  >
                    {headset}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-xl border border-border bg-card p-5">
            <h2 className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              <HardDrive className="h-3.5 w-3.5" />
              How to install
            </h2>
            <ol className="mt-3 space-y-2 text-xs leading-relaxed text-muted-foreground">
              <li>1. Enable developer mode on your Quest headset.</li>
              <li>
                2. Or plug in a USB-C cable and install it from the{" "}
                <Link to="/connect" className="font-medium text-primary hover:underline">
                  Connect Quest
                </Link>{" "}
                page.
              </li>
              <li>3. Or download the build and sideload it with SideQuest.</li>
            </ol>
          </div>
        </aside>
      </div>
    </div>
  );
}