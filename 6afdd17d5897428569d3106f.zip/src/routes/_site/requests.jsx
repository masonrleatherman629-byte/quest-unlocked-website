import { createFileRoute } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";
import RequestForm from "@/components/requests/RequestForm";
import { DISCORD_URL } from "@/lib/links";

export const Route = createFileRoute("/_site/requests")({
  head: () => ({
    meta: [
      { title: "Requests — Quest Unlocked" },
      { name: "description", content: "Request a VR build for the library or suggest an improvement." },
    ],
  }),
  component: RequestsPage,
});

function RequestsPage() {
  return (
    <div className="mx-auto w-full max-w-3xl px-5 py-12">
      <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-primary">Open inbox</p>
      <h1 className="mt-3 font-heading text-4xl font-semibold tracking-tight text-foreground">Requests</h1>
      <p className="mt-2 max-w-xl text-sm text-muted-foreground">
        Want a build in the library, or something fixed on the hub? Send it here. Every request is read.
      </p>

      <div className="mt-8">
        <RequestForm />
      </div>

      <a
        href={DISCORD_URL}
        target="_blank"
        rel="noreferrer"
        className="mt-6 flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-5 py-4 transition-colors hover:border-primary/50"
      >
        <span className="flex items-center gap-2 text-sm text-muted-foreground">
          <MessageCircle className="h-4 w-4 text-primary" />
          Faster answers in the community Discord
        </span>
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-primary">Join</span>
      </a>
    </div>
  );
}