import { createFileRoute, Link } from "@tanstack/react-router";
import QuestGameCard from "@/components/launcher/QuestGameCard";
import { useQuestLibrary } from "@/hooks/use-quest-library";
import { listGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/launcher_/quest/")({
  loader: () => listGames(),
  head: () => ({ meta: [{ title: "My library — Moon Launcher on Meta Quest" }] }),
  component: QuestLibraryPage,
});

function QuestLibraryPage() {
  const games = Route.useLoaderData();
  const { installed, ready, install, remove } = useQuestLibrary();
  const owned = games.filter((game) => installed[game.id]);

  return (
    <div>
      <h2 className="font-heading text-lg font-semibold text-foreground">Installed on this headset</h2>

      {!ready ? (
        <p className="mt-4 rounded-2xl border border-border bg-card px-4 py-12 text-center text-sm text-muted-foreground">
          Reading your headset…
        </p>
      ) : owned.length ? (
        <div className="mt-4 space-y-3">
          {owned.map((game) => (
            <QuestGameCard
              key={game.id}
              game={game}
              installed={installed[game.id]}
              onInstall={install}
              onRemove={remove}
            />
          ))}
        </div>
      ) : (
        <div className="mt-4 rounded-2xl border border-border bg-card px-6 py-12 text-center">
          <p className="text-sm text-muted-foreground">Nothing installed on this headset yet.</p>
          <Link
            to="/launcher/quest/browse"
            className="mt-4 inline-flex h-12 items-center rounded-xl bg-launcher px-5 font-heading text-sm font-semibold text-launcher-foreground hover:bg-launcher/90"
          >
            Browse builds
          </Link>
        </div>
      )}
    </div>
  );
}