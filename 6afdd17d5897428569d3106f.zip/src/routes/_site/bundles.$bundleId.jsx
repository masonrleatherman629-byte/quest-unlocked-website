import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { ArrowLeft, ExternalLink, Layers } from "lucide-react";
import { Image } from "@/components/ui/image";
import GameGrid from "@/components/games/GameGrid";
import { getBundle, listBundleGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/bundles/$bundleId")({
  loader: async ({ params }) => {
    const bundle = await getBundle({ data: { id: params.bundleId } });
    if (!bundle) throw notFound();
    const games = await listBundleGames({ data: { id: bundle.id } });
    return { bundle, games };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.bundle?.title ?? "Bundle"} — Quest Unlocked` },
      { name: "description", content: loaderData?.bundle?.description?.slice(0, 155) ?? "A Quest Unlocked bundle." },
    ],
  }),
  component: BundleDetailPage,
});

function BundleDetailPage() {
  const { bundle, games } = Route.useLoaderData();

  return (
    <div className="mx-auto w-full max-w-6xl px-5 py-10">
      <Link
        to="/bundles"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        All bundles
      </Link>

      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div>
          <div className="aspect-[16/9] w-full overflow-hidden rounded-xl border border-border bg-muted">
            {bundle.image_url ? (
              <Image
                src={bundle.image_url}
                alt={`${bundle.title} artwork`}
                className="h-full w-full object-cover"
                fittingType="fill"
              />
            ) : (
              <div className="flex h-full items-center justify-center font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                No artwork
              </div>
            )}
          </div>

          <h1 className="mt-6 font-heading text-4xl font-semibold tracking-tight text-foreground">{bundle.title}</h1>
          <p className="mt-2 flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            <Layers className="h-3.5 w-3.5" />
            {games.length} {games.length === 1 ? "game" : "games"} included
          </p>

          {bundle.description && (
            <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
              {bundle.description}
            </p>
          )}

          {(bundle.screenshots || []).length > 0 && (
            <div className="mt-6 flex gap-2 overflow-x-auto pb-1">
              {bundle.screenshots.map((src) => (
                <div key={src} className="h-24 w-36 shrink-0 overflow-hidden rounded-lg border border-border">
                  <Image src={src} alt="Bundle screenshot" className="h-full w-full object-cover" fittingType="fill" />
                </div>
              ))}
            </div>
          )}

          <div className="mt-8">
            <h2 className="mb-4 font-heading text-xl font-semibold text-foreground">In this bundle</h2>
            <GameGrid games={games} />
          </div>
        </div>

        <aside className="space-y-4">
          <div className="rounded-xl border border-border bg-card p-5">
            <h2 className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">At a glance</h2>
            <dl className="mt-3 space-y-3 text-sm">
              <div className="flex items-baseline justify-between gap-3">
                <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Games</dt>
                <dd className="text-foreground">{games.length}</dd>
              </div>
              <div className="flex items-baseline justify-between gap-3">
                <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Total size</dt>
                <dd className="truncate text-foreground">
                  {games.some((game) => game.size_label) ? "See each game" : "—"}
                </dd>
              </div>
            </dl>
            {bundle.store_url && (
              <a
                href={bundle.store_url}
                target="_blank"
                rel="noreferrer"
                className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
              >
                <ExternalLink className="h-4 w-4" />
                View on the store
              </a>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}