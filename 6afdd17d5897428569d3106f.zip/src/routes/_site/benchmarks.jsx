import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import BenchmarkTable from "@/components/benchmarks/BenchmarkTable";
import BenchmarkSubmitDialog from "@/components/benchmarks/BenchmarkSubmitDialog";
import { summariseBenchmarks, publicGames } from "@/lib/benchmark-stats";
import { HEADSETS } from "@/lib/game-options";
import { listBenchmarks, listGames } from "@/lib/server-fns";
import { useAuth } from "@/lib/AuthContext";

export const Route = createFileRoute("/_site/benchmarks")({
  loader: async () => {
    const [games, benchmarks] = await Promise.all([listGames(), listBenchmarks()]);
    return { games, benchmarks };
  },
  head: () => ({
    meta: [
      { title: "Benchmarks — Quest Unlocked" },
      {
        name: "description",
        content: "What Quest 2, Quest 3, Quest 3S and Quest Pro actually run library builds at.",
      },
    ],
  }),
  component: BenchmarksPage,
});

function BenchmarksPage() {
  const { games, benchmarks } = Route.useLoaderData();
  const { isAuthenticated, navigateToLogin } = useAuth();
  const [headset, setHeadset] = useState("Quest 3");
  const [open, setOpen] = useState(false);

  const list = publicGames(games);
  const stats = summariseBenchmarks(benchmarks);
  const results = benchmarks.filter((row) => row.headset === headset).length;

  return (
    <div className="mx-auto w-full max-w-5xl px-5 py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-primary">
            Performance
          </p>
          <h1 className="mt-3 font-heading text-4xl font-semibold tracking-tight text-foreground">
            Benchmarks
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            Community results per headset: average FPS and 1% lows for every build in the library.
          </p>
        </div>

        <Button
          onClick={() => (isAuthenticated ? setOpen(true) : navigateToLogin())}
          disabled={!list.length}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add your result
        </Button>
      </div>

      <div className="mt-8 flex flex-wrap items-center gap-2">
        {HEADSETS.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => setHeadset(option)}
            className={
              option === headset
                ? "rounded-full border border-primary bg-primary/15 px-4 py-1.5 text-sm font-medium text-primary"
                : "rounded-full border border-border px-4 py-1.5 text-sm text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
            }
          >
            {option}
          </button>
        ))}
        <span className="ml-auto font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          {results} {results === 1 ? "result" : "results"} on {headset}
        </span>
      </div>

      <div className="mt-4">
        <BenchmarkTable games={list} stats={stats} headset={headset} />
      </div>

      <p className="mt-4 text-xs text-muted-foreground">
        Averages come from results members recorded themselves, so a small sample can swing. Games
        without a result show a dash until someone adds one.
      </p>

      <BenchmarkSubmitDialog
        open={open}
        onOpenChange={setOpen}
        games={list}
        headset={headset}
      />
    </div>
  );
}