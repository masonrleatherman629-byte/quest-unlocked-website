import { createFileRoute } from "@tanstack/react-router";
import UpdateCard from "@/components/updates/UpdateCard";
import { listUpdates } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/updates")({
  loader: () => listUpdates(),
  head: () => ({
    meta: [
      { title: "Updates — Quest Unlocked" },
      { name: "description", content: "New builds, patches and notes from the Quest Unlocked library." },
    ],
  }),
  component: UpdatesPage,
});

function UpdatesPage() {
  const updates = Route.useLoaderData();

  return (
    <div className="mx-auto w-full max-w-3xl px-5 py-12">
      <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-primary">Build log</p>
      <h1 className="mt-3 font-heading text-4xl font-semibold tracking-tight text-foreground">Updates</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        New titles, patches and hub changes, newest first.
      </p>

      <div className="mt-8 space-y-4">
        {updates.length ? (
          updates.map((update) => <UpdateCard key={update.id} update={update} />)
        ) : (
          <div className="rounded-xl border border-dashed border-border px-6 py-16 text-center">
            <p className="font-heading text-lg text-foreground">No updates yet</p>
            <p className="mt-1 text-sm text-muted-foreground">The first build log lands here.</p>
          </div>
        )}
      </div>
    </div>
  );
}