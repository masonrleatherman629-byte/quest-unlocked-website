import { useMemo, useState } from "react";
import { useAuth } from "@/lib/AuthContext";
import { createFileRoute } from "@tanstack/react-router";
import LibraryHero from "@/components/games/LibraryHero";
import FeaturedCarousel from "@/components/games/FeaturedCarousel";
import LauncherCta from "@/components/launcher/LauncherCta";
import LibraryFilters from "@/components/games/LibraryFilters";
import GameGrid from "@/components/games/GameGrid";
import InstallProgressCard from "@/components/quest/InstallProgressCard";
import InviteBanner from "@/components/InviteBanner";
import { sortGames } from "@/lib/sort-games";
import { listBundles, listDownloadCounts, listGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/")({
  loader: async () => {
    const [games, bundles, downloads] = await Promise.all([
      listGames(),
      listBundles(),
      listDownloadCounts(),
    ]);
    return { games, bundles, downloads };
  },
  head: () => ({
    meta: [
      { title: "Quest Unlocked — VR build library" },
      {
        name: "description",
        content: "A developer-published catalogue of Meta Quest VR builds, delivered as direct files.",
      },
    ],
  }),
  component: LibraryPage,
});

function LibraryPage() {
  const { games, bundles, downloads } = Route.useLoaderData();
  const { user } = useAuth();
  const [category, setCategory] = useState("All");
  const [status, setStatus] = useState("All");
  const [genres, setGenres] = useState([]);
  const [relaxed, setRelaxed] = useState(false);
  const [mode, setMode] = useState("All");
  const [gameMode, setGameMode] = useState("Any Mode");
  const [publisher, setPublisher] = useState("All");
  const [language, setLanguage] = useState("All");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("Added");

  const myLanguages = useMemo(() => user?.play_languages || [], [user]);
  // "My languages" only narrows anything once the member has saved some.
  const languageFilter = language === "My languages" && !myLanguages.length ? "All" : language;

  const published = useMemo(() => games.filter((game) => game.status !== "Archived"), [games]);

  const featured = useMemo(
    () => published.filter((game) => game.status === "Ready" && game.image_url).slice(0, 8),
    [published]
  );

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    const wanted = genres.map((genre) => genre.toLowerCase());
    const matchesGenres = (game) => {
      if (!wanted.length) return true;
      const carried = (game.genres || []).map((genre) => genre.toLowerCase());
      return relaxed
        ? wanted.some((genre) => carried.includes(genre))
        : wanted.every((genre) => carried.includes(genre));
    };
    // Co-Op and Multiplayer both mean the build has to be playable with others.
    const matchesGameMode = (game) => {
      if (gameMode === "Any Mode") return true;
      const players = game.players || "";
      if (gameMode === "Single Player") return players === "Single player" || players === "Both";
      return players === "Multiplayer" || players === "Both";
    };

    const filtered = published.filter((game) => {
      const haystack = [game.title, game.developer, game.description, ...(game.genres || [])]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return (
        category !== "Bundles" &&
        (category === "All" || game.category === category) &&
        (status === "All" || game.status === status) &&
        matchesGenres(game) &&
        matchesGameMode(game) &&
        (publisher === "All" || (game.developer || "").trim() === publisher) &&
        (mode === "All" || (game.player_modes || []).includes(mode)) &&
        (languageFilter === "All" ||
          (languageFilter === "My languages"
            ? (game.languages || []).some((name) =>
                myLanguages.some((mine) => mine.toLowerCase() === name.trim().toLowerCase())
              )
            : (game.languages || []).some((name) => name.trim() === languageFilter))) &&
        (!term || haystack.includes(term))
      );
    });
    return sortGames(filtered, sort, downloads);
  }, [
    published,
    category,
    status,
    genres,
    relaxed,
    gameMode,
    publisher,
    mode,
    languageFilter,
    myLanguages,
    search,
    sort,
    downloads,
  ]);

  // Bundles live in the same library: the search box and the Bundles category tag narrow them.
  const visibleBundles = useMemo(() => {
    if (category !== "All" && category !== "Bundles") return [];
    const term = search.trim().toLowerCase();
    if (!term) return bundles;
    return bundles.filter((bundle) =>
      [bundle.title, bundle.description].filter(Boolean).join(" ").toLowerCase().includes(term)
    );
  }, [bundles, category, search]);

  return (
    <>
      <LibraryHero count={published.length} />
      <InviteBanner />
      <InstallProgressCard />
      {featured.length > 0 && (
        <section className="mx-auto w-full max-w-6xl px-5 pt-8">
          <FeaturedCarousel games={featured} />
        </section>
      )}
      <section className="mx-auto w-full max-w-6xl px-5 pt-8">
        <LauncherCta />
      </section>
      <section className="mx-auto w-full max-w-6xl px-5 py-10">
        <div className="mb-6 flex items-end justify-between">
          <h2 className="font-heading text-xl font-semibold text-foreground">The library</h2>
          <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            {String(visible.length + visibleBundles.length).padStart(2, "0")} titles
          </span>
        </div>
        <div className="mb-6">
          <LibraryFilters
            games={published}
            bundles={bundles}
            category={category}
            setCategory={setCategory}
            status={status}
            setStatus={setStatus}
            genres={genres}
            setGenres={setGenres}
            relaxed={relaxed}
            setRelaxed={setRelaxed}
            mode={mode}
            setMode={setMode}
            gameMode={gameMode}
            setGameMode={setGameMode}
            publisher={publisher}
            setPublisher={setPublisher}
            language={language}
            setLanguage={setLanguage}
            myLanguages={myLanguages}
            search={search}
            setSearch={setSearch}
            sort={sort}
            setSort={setSort}
          />
        </div>
        <GameGrid games={visible} bundles={visibleBundles} />
      </section>
    </>
  );
}