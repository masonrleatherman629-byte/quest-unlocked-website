import { createFileRoute } from "@tanstack/react-router";
import TeamMemberCard from "@/components/team/TeamMemberCard";
import { listTeamMembers } from "@/lib/team-fns";

export const Route = createFileRoute("/_site/team")({
  loader: () => listTeamMembers(),
  head: () => ({
    meta: [
      { title: "Admins & Helpers — Quest Unlocked" },
      {
        name: "description",
        content: "The admins, helpers and testers who keep the Quest Unlocked library running.",
      },
    ],
  }),
  component: TeamPage,
});

function TeamPage() {
  const members = Route.useLoaderData();

  return (
    <div className="mx-auto w-full max-w-5xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">The team</p>
      <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">
        Admins, helpers and testers
      </h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        The people who upload builds, test them on their own headsets and answer in the Discord.
      </p>

      {members.length ? (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {members.map((member) => (
            <TeamMemberCard key={member.id} member={member} />
          ))}
        </div>
      ) : (
        <div className="mt-8 rounded-xl border border-dashed border-border bg-card/50 px-6 py-16 text-center">
          <p className="font-heading text-lg text-foreground">No one listed yet</p>
          <p className="mt-1 text-sm text-muted-foreground">
            The team page fills in as people are added from Manage.
          </p>
        </div>
      )}
    </div>
  );
}