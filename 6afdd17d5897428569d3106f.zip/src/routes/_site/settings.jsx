import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Palette, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import ThemeOption from "@/components/settings/ThemeOption";
import MyLanguagesSection from "@/components/settings/MyLanguagesSection";
import LibraryLanguagesSection from "@/components/settings/LibraryLanguagesSection";
import { SITE_LANGUAGES } from "@/lib/site-language";
import useSiteLanguage from "@/hooks/use-site-language";
import { cn } from "@/lib/utils";
import { ACCENTS, DEFAULT_THEME, RADII, SURFACES, readTheme, saveTheme } from "@/lib/theme";
import { LANGUAGES } from "@/lib/game-options";
import { listGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/settings")({
  loader: () => listGames(),
  head: () => ({
    meta: [
      { title: "Settings — Quest Unlocked" },
      { name: "description", content: "Change how the library looks and the languages you play in." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const games = Route.useLoaderData();
  const { language: siteLanguage, setLanguage: setSiteLanguage, t } = useSiteLanguage();
  const [theme, setTheme] = useState(DEFAULT_THEME);

  // Every language a build in the library carries, with how many builds use it.
  const languages = useMemo(() => {
    const counts = new Map();
    for (const game of games) {
      for (const raw of game.languages || []) {
        const name = raw.trim();
        if (name) counts.set(name, (counts.get(name) || 0) + 1);
      }
    }
    return [...counts.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [games]);
  // The standard list is always offered, so a member can pick a language even
  // before any build in the library is tagged with it.
  const languageNames = useMemo(
    () =>
      [...new Set([...LANGUAGES, ...languages.map((language) => language.name)])].sort((a, b) =>
        a.localeCompare(b)
      ),
    [languages]
  );

  // The saved look is per browser, so it is read after the page has rendered.
  useEffect(() => setTheme(readTheme()), []);

  const choose = (key) => (value) => {
    const next = { ...theme, [key]: value };
    setTheme(next);
    saveTheme(next);
  };

  const reset = () => {
    setTheme(DEFAULT_THEME);
    saveTheme(DEFAULT_THEME);
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Settings</p>
      <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">{t("settings_title")}</h1>
      <p className="mt-2 text-sm text-muted-foreground">{t("settings_intro")}</p>

      <div className="mt-8 space-y-6">
        <section className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            {t("site_language")}
          </h2>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {SITE_LANGUAGES.map((option) => {
              const active = siteLanguage === option.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => setSiteLanguage(option.id)}
                  className={cn(
                    "rounded-full border px-3 py-1 text-xs transition-colors",
                    active
                      ? "border-primary/60 bg-primary/15 text-primary"
                      : "border-border bg-background text-muted-foreground hover:text-foreground"
                  )}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            The site's own text is translated so far for the navigation, the library front page and this page.
          </p>
        </section>

        <MyLanguagesSection languages={languageNames} />
        <LibraryLanguagesSection languages={languages} />
      </div>

      <div className="mt-8 space-y-8">
        <section className="rounded-xl border border-border bg-card p-5">
          <h2 className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            <Palette className="h-3.5 w-3.5" />
            {t("accent_colour")}
          </h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {ACCENTS.map((accent) => (
              <ThemeOption
                key={accent.id}
                label={accent.label}
                selected={theme.accent === accent.id}
                onClick={() => choose("accent")(accent.id)}
              >
                <span
                  className="h-3.5 w-3.5 rounded-full border border-black/20"
                  style={{ backgroundColor: `hsl(${accent.primary})` }}
                />
              </ThemeOption>
            ))}
          </div>
        </section>

        <section className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{t("surface_tone")}</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {SURFACES.map((surface) => (
              <ThemeOption
                key={surface.id}
                label={surface.label}
                selected={theme.surface === surface.id}
                onClick={() => choose("surface")(surface.id)}
              >
                <span
                  className="h-3.5 w-3.5 rounded-full border border-border"
                  style={{ backgroundColor: `hsl(${surface.vars["--card"]})` }}
                />
              </ThemeOption>
            ))}
          </div>
        </section>

        <section className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{t("corner_shape")}</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {RADII.map((radius) => (
              <ThemeOption
                key={radius.id}
                label={radius.label}
                selected={theme.radius === radius.id}
                onClick={() => choose("radius")(radius.id)}
              >
                <span
                  className="h-3.5 w-3.5 border border-muted-foreground/60"
                  style={{ borderRadius: radius.value }}
                />
              </ThemeOption>
            ))}
          </div>
        </section>

        <div className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{t("preview")}</h2>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <Button size="sm">Primary button</Button>
            <Button size="sm" variant="outline">
              Secondary
            </Button>
            <span className="rounded-full border border-primary/60 bg-primary/15 px-3 py-1 text-xs text-primary">
              Accent chip
            </span>
          </div>
        </div>

        <Button variant="outline" onClick={reset}>
          <RotateCcw className="mr-2 h-4 w-4" />
          {t("reset_default")}
        </Button>
      </div>
    </div>
  );
}