import { createFileRoute, Link } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuestLibrary } from "@/hooks/use-quest-library";
import { isNewer } from "@/lib/quest-library";
import { listGames } from "@/lib/server-fns";

const when = (value) =>
  new Date(value).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

export const Route = createFileRoute("/_site/launcher_/quest/downloads")({
  loader: () => listGames(),
  head: () => ({ meta: [{ title: "Downloads — Moon Launcher on Meta Quest" }] }),
  component: QuestDownloadsPage,
});

function QuestDownloadsPage() {
  const games = Route.useLoaderData();
  const { installed, ready, remove } = useQuestLibrary();
  const byId = new Map(games.map((game) => [game.id, game]));
  const history = Object.entries(installed)
    .map(([gameId, entry]) => ({ gameId, entry, game: byId.get(gameId) }))
    .sort((a, b) => (a.entry.installed_at < b.entry.installed_at ? 1 : -1));

  return (
    <div>
      <h2 className="font-heading text-lg font-semibold text-foreground">Install history</h2>

      {!ready ? (
        <p className="mt-4 rounded-2xl border border-border bg-card px-4 py-12 text-center text-sm text-muted-foreground">
          Reading your headset…
        </p>
      ) : history.length ? (
        <div className="mt-4 overflow-hidden rounded-2xl border border-border bg-card">
          {history.map(({ gameId, entry, game }) => {
            const update = Boolean(game?.version && isNewer(game.version, entry.version));
            return (
              <div
                key={gameId}
                className="flex flex-wrap items-center gap-3 border-b border-border px-4 py-3 last:border-b-0"
              >
                <div className="min-w-0 flex-1">
                  {game ? (
                    <Link
                      to="/games/$gameId"
                      params={{ gameId }}
                      className="font-heading text-sm font-semibold text-foreground hover:text-primary"
                    >
                      {game.title}
                    </Link>
                  ) : (
                    <span className="font-heading text-sm font-semibold text-foreground">
                      {entry.file_name || "Removed game"}
                    </span>
                  )}
                  <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    {[entry.version && `v${entry.version}`, when(entry.installed_at)]
                      .filter(Boolean)
                      .join(" · ")}
                  </p>
                </div>

                {update && (
                  <span className="rounded-full border border-launcher/40 bg-launcher/10 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.12em] text-launcher">
                    Update to v{game.version}
                  </span>
                )}

                <Button variant="ghost" size="sm" onClick={() => remove(gameId)}>
                  <Trash2 className="mr-2 h-3.5 w-3.5" />
                  Remove
                </Button>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="mt-4 rounded-2xl border border-border bg-card px-6 py-12 text-center">
          <p className="text-sm text-muted-foreground">No installs from this headset yet.</p>
          <Link
            to="/launcher/quest/browse"
            className="mt-4 inline-flex h-12 items-center rounded-xl bg-launcher px-5 font-heading text-sm font-semibold text-launcher-foreground hover:bg-launcher/90"
          >
            Browse builds
          </Link>
        </div>
      )}
    </div>
  );
}