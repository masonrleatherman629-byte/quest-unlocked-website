import { createFileRoute } from "@tanstack/react-router";
import QuestConnectPanel from "@/components/quest/QuestConnectPanel";
import QuestInstallRow from "@/components/quest/QuestInstallRow";
import { useQuest } from "@/lib/QuestContext";
import { listGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/connect")({
  loader: () => listGames(),
  head: () => ({
    meta: [
      { title: "Connect Quest — Quest Unlocked" },
      {
        name: "description",
        content: "Plug your Quest in with a USB-C cable and install builds straight from the library.",
      },
    ],
  }),
  component: ConnectQuestPage,
});

function ConnectQuestPage() {
  const games = Route.useLoaderData();
  const quest = useQuest();
  const installable = games.filter((game) => game.download_url && game.status === "Ready");

  return (
    <div className="mx-auto w-full max-w-4xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-primary">Sideload without a computer</p>
      <h1 className="mt-2 font-heading text-4xl font-semibold tracking-tight text-foreground">Connect Quest</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Plug your headset in with a USB-C cable and install any build in the library right from this page. Nothing has to
        be set up on the device you are using.
      </p>

      <QuestConnectPanel
        status={quest.status}
        error={quest.error}
        onConnect={quest.connect}
        onDisconnect={quest.disconnect}
      />

      <h2 className="mt-10 font-mono text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
        Builds ready to install
      </h2>

      {installable.length ? (
        <div className="mt-4 space-y-2">
          {installable.map((game) => (
            <QuestInstallRow key={game.id} game={game} />
          ))}
        </div>
      ) : (
        <p className="mt-4 text-sm text-muted-foreground">No build with a file is in the library yet.</p>
      )}
    </div>
  );
}