import { createFileRoute, notFound, Link } from "@tanstack/react-router";
import { ArrowLeft, Globe, MessageCircle } from "lucide-react";
import { Image } from "@/components/ui/image";
import { Button } from "@/components/ui/button";
import GameGrid from "@/components/games/GameGrid";
import { getPublisher, listPublisherGames } from "@/lib/server-fns";

export const Route = createFileRoute("/_site/publishers/$publisherId")({
  loader: async ({ params }) => {
    const publisher = await getPublisher({ data: { id: params.publisherId } });
    if (!publisher) throw notFound();
    const games = await listPublisherGames({ data: { publisher_id: publisher.id } });
    return { publisher, games: games.filter((game) => game.status !== "Archived") };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.publisher?.name ?? "Publisher"} — Quest Unlocked` },
      {
        name: "description",
        content:
          loaderData?.publisher?.description?.slice(0, 155) ??
          "Every build this publisher has released on Quest Unlocked.",
      },
    ],
  }),
  component: PublisherPage,
});

function PublisherPage() {
  const { publisher, games } = Route.useLoaderData();

  return (
    <section className="mx-auto w-full max-w-6xl px-5 py-10">
      <Link
        to="/publishers"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        All publishers
      </Link>

      <div className="mt-6 flex flex-col gap-5 rounded-xl border border-border bg-card p-6 sm:flex-row sm:items-center">
        <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl border border-border bg-muted">
          {publisher.logo_url ? (
            <Image
              src={publisher.logo_url}
              alt={`${publisher.name} logo`}
              className="h-full w-full object-cover"
              fittingType="fill"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center font-mono text-sm text-muted-foreground">
              {(publisher.name || "?").slice(0, 2).toUpperCase()}
            </div>
          )}
        </div>

        <div className="min-w-0 flex-1">
          <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">{publisher.name}</h1>
          <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            {games.length} {games.length === 1 ? "title" : "titles"} published
          </p>
          {publisher.description && (
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">{publisher.description}</p>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {publisher.website_url && (
            <Button asChild variant="outline" size="sm">
              <a href={publisher.website_url} target="_blank" rel="noreferrer">
                <Globe className="mr-2 h-4 w-4" />
                Website
              </a>
            </Button>
          )}
          {publisher.discord_url && (
            <Button asChild variant="outline" size="sm">
              <a href={publisher.discord_url} target="_blank" rel="noreferrer">
                <MessageCircle className="mr-2 h-4 w-4" />
                Discord
              </a>
            </Button>
          )}
        </div>
      </div>

      <div className="mt-8">
        <GameGrid games={games} />
      </div>
    </section>
  );
}