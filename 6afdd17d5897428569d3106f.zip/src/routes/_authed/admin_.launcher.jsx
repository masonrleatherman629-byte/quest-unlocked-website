import { useState } from "react";
import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Gamepad2, Laptop, Monitor, Pencil, Terminal, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import LauncherBuildDialog from "@/components/admin/LauncherBuildDialog";
import { deleteLauncherBuild, listLauncherBuilds, saveLauncherBuild } from "@/lib/server-fns";

const PLATFORMS = [
  { platform: "Meta Quest", icon: Gamepad2 },
  { platform: "Windows", icon: Monitor },
  { platform: "Linux", icon: Terminal },
  { platform: "macOS", icon: Laptop },
];

export const Route = createFileRoute("/_authed/admin_/launcher")({
  loader: () => listLauncherBuilds(),
  head: () => ({ meta: [{ title: "Moon Launcher — Quest Unlocked" }] }),
  component: AdminLauncherPage,
});

function AdminLauncherPage() {
  const builds = Route.useLoaderData();
  const router = useRouter();
  const save = useServerFn(saveLauncherBuild);
  const remove = useServerFn(deleteLauncherBuild);

  const [editing, setEditing] = useState(null);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");

  const byPlatform = (platform) => builds.find((build) => build.platform === platform) || null;

  const handleSave = async (values) => {
    await save({ data: values });
    await router.invalidate();
  };

  const handleDelete = async (build) => {
    const confirmed = window.confirm(
      `Remove the ${build.platform} installer? The launcher page will show it as coming soon.`
    );
    if (!confirmed) return;
    setError("");
    try {
      await remove({ data: { id: build.id } });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "The build could not be removed.");
    }
  };

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <div className="mt-2">
          <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">Moon Launcher</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            One installer per platform. Upload a new file to replace a build.
          </p>
        </div>

        <AdminTabs />

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

        <div className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          {PLATFORMS.map(({ platform, icon: Icon }) => {
            const build = byPlatform(platform);
            return (
              <div
                key={platform}
                className="flex flex-wrap items-center justify-between gap-3 border-b border-border/70 px-4 py-3 last:border-b-0"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-border bg-muted text-muted-foreground">
                    <Icon className="h-4 w-4" />
                  </span>
                  <div className="min-w-0">
                    <p className="font-heading text-sm font-medium text-foreground">{platform}</p>
                    <p className="mt-0.5 truncate font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      {build?.download_url
                        ? [build.version && `v${build.version}`, build.size_label, build.file_name]
                            .filter(Boolean)
                            .join(" · ")
                        : "No installer yet"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setEditing(platform);
                      setOpen(true);
                    }}
                  >
                    <Pencil className="mr-1.5 h-3.5 w-3.5" />
                    {build ? "Edit" : "Add build"}
                  </Button>
                  {build && (
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(build)}>
                      <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                      Remove
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <LauncherBuildDialog
          open={open}
          onOpenChange={setOpen}
          platform={editing}
          build={editing ? byPlatform(editing) : null}
          onSave={handleSave}
        />
      </div>
    </AdminOnly>
  );
}