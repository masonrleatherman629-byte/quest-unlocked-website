import { useState } from "react";
import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Image } from "@/components/ui/image";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import TeamMemberDialog from "@/components/admin/TeamMemberDialog";
import { deleteTeamMember, listTeamMembers, saveTeamMember } from "@/lib/team-fns";

export const Route = createFileRoute("/_authed/admin_/team")({
  loader: () => listTeamMembers(),
  head: () => ({ meta: [{ title: "Team — Quest Unlocked" }] }),
  component: AdminTeamPage,
});

function AdminTeamPage() {
  const members = Route.useLoaderData();
  const router = useRouter();
  const save = useServerFn(saveTeamMember);
  const remove = useServerFn(deleteTeamMember);

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState("");

  const handleSave = async (values) => {
    await save({ data: values });
    await router.invalidate();
  };

  const handleDelete = async (member) => {
    if (!window.confirm(`Remove ${member.name} from the team page?`)) return;
    setError("");
    try {
      await remove({ data: { id: member.id } });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "That person could not be removed.");
    }
  };

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">Team</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {members.length} {members.length === 1 ? "person" : "people"} on the public team page.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="outline">
              <Link to="/team">View page</Link>
            </Button>
            <Button
              onClick={() => {
                setEditing(null);
                setOpen(true);
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add a member
            </Button>
          </div>
        </div>

        <AdminTabs />

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

        <div className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          {members.length ? (
            members.map((member) => (
              <div
                key={member.id}
                className="flex flex-wrap items-center justify-between gap-3 border-b border-border/70 px-4 py-3 last:border-b-0"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full border border-border bg-muted">
                    {member.avatar_url ? (
                      <Image
                        src={member.avatar_url}
                        alt={member.name}
                        className="h-full w-full object-cover"
                        fittingType="fill"
                      />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center font-mono text-[10px] text-muted-foreground">
                        {(member.name || "?").slice(0, 2).toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <p className="truncate font-heading text-sm font-medium text-foreground">
                      {member.name}
                    </p>
                    <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      {member.role || "Helper"}
                      {member.order !== undefined && member.order !== null
                        ? ` · position ${member.order}`
                        : ""}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setEditing(member);
                      setOpen(true);
                    }}
                  >
                    <Pencil className="mr-1.5 h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(member)}>
                    <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                    Delete
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <p className="px-4 py-12 text-center text-sm text-muted-foreground">
              Nobody listed yet. Add the first admin or helper.
            </p>
          )}
        </div>

        <TeamMemberDialog
          open={open}
          onOpenChange={setOpen}
          member={editing}
          onSave={handleSave}
        />
      </div>
    </AdminOnly>
  );
}