import { useState } from "react";
import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Layers, ListChecks, Plus, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import GameRow from "@/components/admin/GameRow";
import MaintenanceToggle from "@/components/admin/MaintenanceToggle";
import DiscordBotPanel from "@/components/admin/DiscordBotPanel";
import GameEditorDialog from "@/components/admin/GameEditorDialog";
import MultiGameAddDialog from "@/components/admin/MultiGameAddDialog";
import MultiBuildUploadDialog from "@/components/admin/MultiBuildUploadDialog";
import BulkEditDialog from "@/components/admin/BulkEditDialog";
import { uploadGameBuild } from "@/lib/game-artwork";
import { toGamePayload } from "@/lib/game-payload";
import { createGame, deleteGame, listGames, listPublishers, updateGame } from "@/lib/server-fns";
import { getSiteConfig } from "@/lib/site-config-fns";
import { getBotConfig } from "@/lib/bot-config-fns";

export const Route = createFileRoute("/_authed/admin")({
  loader: async () => {
    const [games, publishers, config, botConfig] = await Promise.all([
      listGames(),
      listPublishers(),
      getSiteConfig(),
      getBotConfig(),
    ]);
    return { games, publishers, config, botConfig };
  },
  head: () => ({ meta: [{ title: "Manage library — Quest Unlocked" }] }),
  component: AdminPage,
});

function AdminPage() {
  const { games, publishers, config, botConfig } = Route.useLoaderData();
  const router = useRouter();
  const create = useServerFn(createGame);
  const update = useServerFn(updateGame);
  const remove = useServerFn(deleteGame);

  const [open, setOpen] = useState(false);
  const [multiOpen, setMultiOpen] = useState(false);
  const [multiUploadOpen, setMultiUploadOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [uploadingId, setUploadingId] = useState(null);
  const [uploadError, setUploadError] = useState("");
  const [bulkOpen, setBulkOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState([]);

  const toggleSelect = (id) =>
    setSelectedIds((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id]
    );
  const selectedGames = games.filter((game) => selectedIds.includes(game.id));

  // Uploading straight from the list attaches the build file to that one game.
  const handleBuildUpload = async (game, file) => {
    setUploadingId(game.id);
    setUploadError("");
    try {
      const build = await uploadGameBuild(file);
      await update({ data: { id: game.id, ...build, upload_status: "Ready" } });
      await router.invalidate();
    } catch (err) {
      setUploadError(err?.message || `The build for ${game.title} could not be uploaded.`);
    } finally {
      setUploadingId(null);
    }
  };

  // Deleting the record takes the game page with it.
  const handleDelete = async (game) => {
    await remove({ data: { id: game.id } });
    toast.success(`${game.title} was removed from the library.`);
    await router.invalidate();
  };

  const handleSave = async (values) => {
    const payload = toGamePayload(values);

    if (values.id) {
      await update({ data: { id: values.id, ...payload } });
    } else {
      const { merged, game } = await create({ data: payload });
      if (merged) {
        toast.success(`${game.title} was already in the library, so its page was updated instead.`);
      }
    }
    await router.invalidate();
  };

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">Library builds</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {games.length} {games.length === 1 ? "title" : "titles"} · editing one build never changes another.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" disabled={!selectedGames.length} onClick={() => setBulkOpen(true)}>
              <ListChecks className="mr-2 h-4 w-4" />
              Bulk edit{selectedGames.length ? ` (${selectedGames.length})` : ""}
            </Button>
            <Button variant="outline" onClick={() => setMultiUploadOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Upload builds
            </Button>
            <Button variant="outline" onClick={() => setMultiOpen(true)}>
              <Layers className="mr-2 h-4 w-4" />
              Add several
            </Button>
            <Button
              onClick={() => {
                setEditing(null);
                setOpen(true);
              }}
            >
              <Plus className="mr-2 h-4 w-4" />
              Add a game
            </Button>
          </div>
        </div>

        <MaintenanceToggle config={config} />

        <DiscordBotPanel config={botConfig} />

        <AdminTabs />

        {uploadError && <p className="mt-4 text-sm text-destructive">{uploadError}</p>}

        <div className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          {games.length ? (
            games.map((game) => (
              <GameRow
                key={game.id}
                game={game}
                uploading={uploadingId === game.id}
                selected={selectedIds.includes(game.id)}
                onToggleSelect={toggleSelect}
                onUpload={handleBuildUpload}
                onDelete={handleDelete}
                onEdit={(target) => {
                  setEditing(target);
                  setOpen(true);
                }}
              />
            ))
          ) : (
            <p className="px-4 py-12 text-center text-sm text-muted-foreground">
              No builds yet. Add the first one.
            </p>
          )}
        </div>

        <GameEditorDialog
          open={open}
          onOpenChange={setOpen}
          game={editing}
          publishers={publishers}
          onSave={handleSave}
        />

        <MultiGameAddDialog
          open={multiOpen}
          onOpenChange={setMultiOpen}
          onAdded={() => router.invalidate()}
        />

        <MultiBuildUploadDialog
          open={multiUploadOpen}
          onOpenChange={setMultiUploadOpen}
          games={games}
          onUploaded={() => router.invalidate()}
        />

        <BulkEditDialog
          open={bulkOpen}
          onOpenChange={setBulkOpen}
          games={selectedGames}
          onSaved={() => setSelectedIds([])}
        />
      </div>
    </AdminOnly>
  );
}