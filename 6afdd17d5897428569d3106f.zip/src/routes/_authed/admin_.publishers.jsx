import { useState } from "react";
import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Gamepad2, Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import PublisherDialog from "@/components/admin/PublisherDialog";
import PublisherGamesDialog from "@/components/admin/PublisherGamesDialog";
import {
  createPublisher,
  deletePublisher,
  listGames,
  listPublishers,
  updateGame,
  updatePublisher,
} from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/admin_/publishers")({
  loader: async () => {
    const [publishers, games] = await Promise.all([listPublishers(), listGames()]);
    return { publishers, games };
  },
  head: () => ({ meta: [{ title: "Publishers — Quest Unlocked" }] }),
  component: AdminPublishersPage,
});

function AdminPublishersPage() {
  const { publishers, games } = Route.useLoaderData();
  const router = useRouter();
  const create = useServerFn(createPublisher);
  const update = useServerFn(updatePublisher);
  const remove = useServerFn(deletePublisher);
  const assignGame = useServerFn(updateGame);

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [gamesFor, setGamesFor] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState("");

  const counts = publishers.reduce((totals, publisher) => {
    const key = (publisher.name || "").trim().toLowerCase();
    totals[publisher.id] = games.filter(
      (game) =>
        game.publisher_id === publisher.id ||
        (key && (game.developer || "").trim().toLowerCase() === key)
    ).length;
    return totals;
  }, {});

  const handleAssign = async (gameId, publisherId) => {
    setBusyId(gameId);
    setError("");
    try {
      await assignGame({ data: { id: gameId, publisher_id: publisherId } });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "That game could not be moved.");
    } finally {
      setBusyId(null);
    }
  };

  const handleSave = async (values) => {
    const payload = {
      name: values.name,
      description: values.description,
      logo_url: values.logo_url,
      website_url: values.website_url,
      discord_url: values.discord_url,
    };
    if (values.id) {
      await update({ data: { id: values.id, ...payload } });
    } else {
      await create({ data: payload });
    }
    await router.invalidate();
  };

  const handleDelete = async (publisher) => {
    const count = counts[publisher.id] || 0;
    const confirmed = window.confirm(
      `Delete ${publisher.name}? ${count ? `${count} game${count === 1 ? "" : "s"} will stay in the library without a publisher.` : ""}`
    );
    if (!confirmed) return;
    setError("");
    try {
      await remove({ data: { id: publisher.id } });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "The publisher could not be deleted.");
    }
  };

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">Publishers</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {publishers.length} {publishers.length === 1 ? "studio" : "studios"} · attach games to them from the game editor.
            </p>
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add a publisher
          </Button>
        </div>

        <AdminTabs />

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

        <div className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          {publishers.length ? (
            publishers.map((publisher) => (
              <div
                key={publisher.id}
                className="flex flex-wrap items-center justify-between gap-3 border-b border-border/70 px-4 py-3 last:border-b-0"
              >
                <div className="min-w-0">
                  <Link
                    to="/publishers/$publisherId"
                    params={{ publisherId: publisher.id }}
                    className="font-heading text-sm font-medium text-foreground hover:text-primary"
                  >
                    {publisher.name}
                  </Link>
                  <p className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    {counts[publisher.id] || 0} {counts[publisher.id] === 1 ? "game" : "games"}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button variant="ghost" size="sm" onClick={() => setGamesFor(publisher)}>
                    <Gamepad2 className="mr-1.5 h-3.5 w-3.5" />
                    Games
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setEditing(publisher);
                      setOpen(true);
                    }}
                  >
                    <Pencil className="mr-1.5 h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(publisher)}>
                    <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                    Delete
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <p className="px-4 py-12 text-center text-sm text-muted-foreground">
              No publishers yet. Add the first studio.
            </p>
          )}
        </div>

        <PublisherDialog open={open} onOpenChange={setOpen} publisher={editing} onSave={handleSave} />

        <PublisherGamesDialog
          open={Boolean(gamesFor)}
          onOpenChange={(next) => !next && setGamesFor(null)}
          publisher={gamesFor}
          games={games}
          publishers={publishers}
          onAssign={handleAssign}
          busyId={busyId}
        />
      </div>
    </AdminOnly>
  );
}