import { createFileRoute } from "@tanstack/react-router";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import RequestsPanel from "@/components/admin/RequestsPanel";
import { listGameRequests } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/admin_/requests")({
  loader: () => listGameRequests(),
  head: () => ({ meta: [{ title: "Requests — Quest Unlocked" }] }),
  component: AdminRequestsPage,
});

function AdminRequestsPage() {
  const requests = Route.useLoaderData();

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">Requests</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {requests.length} {requests.length === 1 ? "submission" : "submissions"} from the community.
        </p>

        <AdminTabs />

        <div className="mt-6">
          <RequestsPanel requests={requests} />
        </div>
      </div>
    </AdminOnly>
  );
}