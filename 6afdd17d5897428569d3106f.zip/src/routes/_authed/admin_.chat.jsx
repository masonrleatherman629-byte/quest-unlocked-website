import { createFileRoute } from "@tanstack/react-router";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import StaffChat from "@/components/admin/StaffChat";
import { listStaffMessages } from "@/lib/staff-chat-fns";

export const Route = createFileRoute("/_authed/admin_/chat")({
  loader: () => listStaffMessages(),
  head: () => ({ meta: [{ title: "Staff chat — Quest Unlocked" }] }),
  component: AdminChatPage,
});

function AdminChatPage() {
  const messages = Route.useLoaderData();

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">Staff chat</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          A shared thread for admin accounts. Members never see it.
        </p>

        <AdminTabs />

        <div className="mt-6">
          <StaffChat messages={messages} />
        </div>
      </div>
    </AdminOnly>
  );
}