import { createFileRoute } from "@tanstack/react-router";
import ProfileForm from "@/components/profile/ProfileForm";
import DiscordLink from "@/components/profile/DiscordLink";

export const Route = createFileRoute("/_authed/profile")({
  head: () => ({ meta: [{ title: "Your profile — Quest Unlocked" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user } = Route.useRouteContext();

  return (
    <div className="mx-auto w-full max-w-2xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Profile</p>
      <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">
        {user?.full_name || "Your profile"}
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">Pick the picture and name the community sees.</p>

      <div className="mt-6">
        <ProfileForm user={user} />
      </div>

      <div className="mt-6">
        <DiscordLink />
      </div>
    </div>
  );
}