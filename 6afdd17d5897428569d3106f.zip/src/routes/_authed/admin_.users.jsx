import { useMemo, useState } from "react";
import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import AdminInviteCard from "@/components/admin/AdminInviteCard";
import UserRow from "@/components/admin/UserRow";
import { useAuth } from "@/lib/AuthContext";
import { listAppUsers, setUserRole } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/admin_/users")({
  loader: () => listAppUsers(),
  head: () => ({ meta: [{ title: "Users — Quest Unlocked" }] }),
  component: AdminUsersPage,
});

function AdminUsersPage() {
  const users = Route.useLoaderData();
  const router = useRouter();
  const { user: me } = useAuth();
  const changeRole = useServerFn(setUserRole);

  const [search, setSearch] = useState("");
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState("");

  const term = search.trim().toLowerCase();
  const visible = useMemo(
    () =>
      users.filter((user) =>
        !term || [user.full_name, user.email, user.discord_name].filter(Boolean).join(" ").toLowerCase().includes(term)
      ),
    [users, term]
  );
  const admins = users.filter((user) => user.role === "admin").length;

  const handleToggle = async (target, role) => {
    setBusyId(target.id);
    setError("");
    try {
      await changeRole({ data: { id: target.id, role } });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "That role could not be changed.");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">Users</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {users.length} {users.length === 1 ? "member" : "members"} · {admins} {admins === 1 ? "admin" : "admins"}
            </p>
          </div>
        </div>

        <AdminTabs />

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

        <div className="relative mt-6">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search by name, email or Discord name"
            className="pl-9"
          />
        </div>

        <div className="mt-4 overflow-hidden rounded-xl border border-border bg-card">
          {visible.length ? (
            visible.map((user) => (
              <UserRow
                key={user.id}
                user={user}
                isSelf={user.id === me?.id}
                busy={busyId === user.id}
                onToggle={handleToggle}
              />
            ))
          ) : (
            <p className="px-4 py-12 text-center text-sm text-muted-foreground">No member matches that search.</p>
          )}
        </div>

        <p className="mt-4 text-xs text-muted-foreground">
          Admins can see and change everything in the library, bundles, guide and this manage area. You cannot change
          your own role.
        </p>

        <AdminInviteCard />
      </div>
    </AdminOnly>
  );
}