import { useState } from "react";
import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import GuideEditorDialog from "@/components/admin/GuideEditorDialog";
import { deleteGuideSection, listGuideSections, saveGuideSection } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/admin_/guide")({
  loader: () => listGuideSections(),
  head: () => ({ meta: [{ title: "Guide — Quest Unlocked" }] }),
  component: AdminGuidePage,
});

function AdminGuidePage() {
  const sections = Route.useLoaderData();
  const router = useRouter();
  const save = useServerFn(saveGuideSection);
  const remove = useServerFn(deleteGuideSection);

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState("");

  const handleSave = async (values) => {
    await save({
      data: {
        id: values.id,
        title: values.title,
        body: values.body,
        image_url: values.image_url,
        order: values.order,
      },
    });
    await router.invalidate();
  };

  const handleDelete = async (section) => {
    if (!window.confirm(`Delete the step “${section.title}”?`)) return;
    setError("");
    try {
      await remove({ data: { id: section.id } });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "That step could not be deleted.");
    }
  };

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">Guide</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {sections.length} {sections.length === 1 ? "step" : "steps"} · this is what the guide page shows.
            </p>
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add a step
          </Button>
        </div>

        <AdminTabs />

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

        <div className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          {sections.length ? (
            sections.map((section, index) => (
              <div
                key={section.id}
                className="flex flex-wrap items-center justify-between gap-3 border-b border-border/70 px-4 py-3 last:border-b-0"
              >
                <div className="min-w-0">
                  <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    Step {String(index + 1).padStart(2, "0")} · order {section.order ?? 0}
                  </p>
                  <p className="mt-0.5 truncate font-heading text-sm font-medium text-foreground">{section.title}</p>
                  <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{section.body}</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setEditing(section);
                      setOpen(true);
                    }}
                  >
                    <Pencil className="mr-1.5 h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(section)}>
                    <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                    Delete
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <p className="px-4 py-12 text-center text-sm text-muted-foreground">
              No steps yet. Add the first one to start the guide.
            </p>
          )}
        </div>

        <GuideEditorDialog
          open={open}
          onOpenChange={setOpen}
          section={editing}
          nextOrder={(sections[sections.length - 1]?.order ?? 0) + 1}
          onSave={handleSave}
        />
      </div>
    </AdminOnly>
  );
}