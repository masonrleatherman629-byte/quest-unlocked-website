import { createFileRoute } from "@tanstack/react-router";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import UpdatesPanel from "@/components/admin/UpdatesPanel";
import { listUpdates } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/admin_/updates")({
  loader: () => listUpdates(),
  head: () => ({ meta: [{ title: "Updates — Quest Unlocked" }] }),
  component: AdminUpdatesPage,
});

function AdminUpdatesPage() {
  const updates = Route.useLoaderData();

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">Updates</h1>
        <p className="mt-1 text-sm text-muted-foreground">Post a build log entry — it shows on the Updates tab.</p>

        <AdminTabs />

        <div className="mt-6">
          <UpdatesPanel updates={updates} />
        </div>
      </div>
    </AdminOnly>
  );
}