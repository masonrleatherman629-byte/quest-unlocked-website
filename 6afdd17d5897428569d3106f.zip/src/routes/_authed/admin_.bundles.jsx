import { useState } from "react";
import { createFileRoute, useRouter, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Layers, Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Image } from "@/components/ui/image";
import AdminOnly from "@/components/admin/AdminOnly";
import AdminTabs from "@/components/admin/AdminTabs";
import BundleEditorDialog from "@/components/admin/BundleEditorDialog";
import { createBundle, deleteBundle, listBundles, listGames, updateBundle } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/admin_/bundles")({
  loader: async () => {
    const [bundles, games] = await Promise.all([listBundles(), listGames()]);
    return { bundles, games };
  },
  head: () => ({ meta: [{ title: "Bundles — Quest Unlocked" }] }),
  component: AdminBundlesPage,
});

function AdminBundlesPage() {
  const { bundles, games } = Route.useLoaderData();
  const router = useRouter();
  const create = useServerFn(createBundle);
  const update = useServerFn(updateBundle);
  const remove = useServerFn(deleteBundle);

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState("");

  const handleSave = async (values) => {
    const payload = {
      title: values.title,
      description: values.description,
      image_url: values.image_url,
      screenshots: values.screenshots,
      store_url: values.store_url,
      game_ids: values.game_ids,
    };
    if (values.id) {
      await update({ data: { id: values.id, ...payload } });
    } else {
      await create({ data: payload });
    }
    await router.invalidate();
  };

  const handleDelete = async (bundle) => {
    if (!window.confirm(`Delete ${bundle.title}? The games in it stay in the library.`)) return;
    setError("");
    try {
      await remove({ data: { id: bundle.id } });
      await router.invalidate();
    } catch (err) {
      setError(err?.message || "The bundle could not be deleted.");
    }
  };

  return (
    <AdminOnly>
      <div className="mx-auto w-full max-w-4xl px-5 py-10">
        <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Manage</p>
        <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-heading text-3xl font-semibold tracking-tight text-foreground">Bundles</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {bundles.length} {bundles.length === 1 ? "bundle" : "bundles"} · group builds into packs.
            </p>
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add a bundle
          </Button>
        </div>

        <AdminTabs />

        {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

        <div className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          {bundles.length ? (
            bundles.map((bundle) => (
              <div
                key={bundle.id}
                className="flex flex-wrap items-center justify-between gap-3 border-b border-border/70 px-4 py-3 last:border-b-0"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <div className="h-12 w-20 shrink-0 overflow-hidden rounded-md border border-border bg-muted">
                    {bundle.image_url ? (
                      <Image
                        src={bundle.image_url}
                        alt={`${bundle.title} artwork`}
                        className="h-full w-full object-cover"
                        fittingType="fill"
                      />
                    ) : (
                      <div className="flex h-full items-center justify-center font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                        None
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <Link
                      to="/bundles/$bundleId"
                      params={{ bundleId: bundle.id }}
                      className="truncate font-heading text-sm font-medium text-foreground hover:text-primary"
                    >
                      {bundle.title}
                    </Link>
                    <p className="mt-0.5 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      <Layers className="h-3 w-3" />
                      {(bundle.game_ids || []).length} {(bundle.game_ids || []).length === 1 ? "game" : "games"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setEditing(bundle);
                      setOpen(true);
                    }}
                  >
                    <Pencil className="mr-1.5 h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(bundle)}>
                    <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                    Delete
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <p className="px-4 py-12 text-center text-sm text-muted-foreground">
              No bundles yet. Add the first pack.
            </p>
          )}
        </div>

        <BundleEditorDialog
          open={open}
          onOpenChange={setOpen}
          bundle={editing}
          games={games}
          onSave={handleSave}
        />
      </div>
    </AdminOnly>
  );
}