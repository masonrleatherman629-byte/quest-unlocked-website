import { useState } from "react";
import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import GameEditorDialog from "@/components/admin/GameEditorDialog";
import MyRequests from "@/components/requests/MyRequests";
import { toGamePayload } from "@/lib/game-payload";
import { createGame, listMyGameRequests, listPublishers } from "@/lib/server-fns";

export const Route = createFileRoute("/_authed/manage")({
  loader: async () => {
    const [publishers, requests] = await Promise.all([listPublishers(), listMyGameRequests()]);
    return { publishers, requests };
  },
  head: () => ({ meta: [{ title: "Regular supply — Quest Unlocked" }] }),
  component: ManagePage,
});

function ManagePage() {
  const { publishers, requests } = Route.useLoaderData();
  const router = useRouter();
  const create = useServerFn(createGame);

  const [open, setOpen] = useState(false);
  const [added, setAdded] = useState(null);

  // Signed-in members can add a build to the library, nothing more.
  const handleSave = async (values) => {
    const { game, merged } = await create({ data: toGamePayload(values) });
    setAdded({ title: game?.title || values.title, merged });
    await router.invalidate();
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-5 py-10">
      <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-primary">Regular supply</p>
      <h1 className="mt-2 font-heading text-3xl font-semibold tracking-tight text-foreground">
        Add a game to the library
      </h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Anyone signed in can publish a build here. Adding one posts it to the library and to the Discord feed.
      </p>

      <div className="mt-6 rounded-xl border border-border bg-card p-6">
        <Button
          onClick={() => {
            setAdded(null);
            setOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add a game
        </Button>

        {added && (
          <p className="mt-4 flex items-center gap-2 text-sm text-primary">
            <CheckCircle2 className="h-4 w-4" />
            {added.merged
              ? `${added.title} is already in the library, so its page was updated with your build.`
              : `${added.title} is now in the library.`}
          </p>
        )}
      </div>

      <MyRequests requests={requests} />

      <GameEditorDialog
        open={open}
        onOpenChange={setOpen}
        game={null}
        publishers={publishers}
        showStoreLookup={false}
        onSave={handleSave}
      />
    </div>
  );
}