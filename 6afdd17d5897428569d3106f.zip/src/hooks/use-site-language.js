import { useEffect, useState } from "react";
import { SITE_LANGUAGE_EVENT, readSiteLanguage, saveSiteLanguage, translate } from "@/lib/site-language";

// The saved site language is read after the page has rendered, so the server
// markup and the first client render always agree.
export default function useSiteLanguage() {
  const [language, setLanguage] = useState("en");

  useEffect(() => {
    setLanguage(readSiteLanguage());
    const sync = () => setLanguage(readSiteLanguage());
    window.addEventListener(SITE_LANGUAGE_EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(SITE_LANGUAGE_EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  return { language, setLanguage: saveSiteLanguage, t: (key) => translate(language, key) };
}