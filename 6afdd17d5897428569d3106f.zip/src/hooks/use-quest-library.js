import { useEffect, useState } from "react";
import { readInstalled, writeInstalled } from "@/lib/quest-library";
import { trackDownload } from "@/lib/download-tracker";

// Every launcher screen reads the same saved state, so a change on one screen
// is announced to the others.
const CHANGED = "moon-launcher:quest:changed";

// Install state lives on the headset, so it is read after mount and saved on
// every change. A launcher screen never renders it during the server pass.
export function useQuestLibrary() {
  const [installed, setInstalled] = useState({});
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setInstalled(readInstalled());
    setReady(true);
    const sync = () => setInstalled(readInstalled());
    window.addEventListener(CHANGED, sync);
    return () => window.removeEventListener(CHANGED, sync);
  }, []);

  const save = (next) => {
    setInstalled(next);
    writeInstalled(next);
    window.dispatchEvent(new Event(CHANGED));
  };

  const install = (game) => {
    trackDownload(game);
    save({
      ...installed,
      [game.id]: {
        version: game.version || "",
        file_name: game.file_name || "",
        installed_at: new Date().toISOString(),
      },
    });
  };

  const remove = (gameId) => {
    const next = { ...installed };
    delete next[gameId];
    save(next);
  };

  return { installed, ready, install, remove };
}