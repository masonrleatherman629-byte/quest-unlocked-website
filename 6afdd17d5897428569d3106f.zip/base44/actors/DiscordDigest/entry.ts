import { Actor } from "base44:runtime/actors";

// The digest is event-driven, not timed: after a change lands the app asks this
// room to check how much piled up, and it posts when the batch is big enough.
// A cooldown stops one busy day from posting the same summary over and over.
const COOLDOWN_MS = 12 * 60 * 60 * 1000;
const MIN_CHANGES = 5;

export default class DiscordDigest extends Actor {
  static callable = ["check", "postNow"];

  async handleStart() {
    // Fixed-time runs are gone: drop any daily wake armed by an earlier version.
    await this.cancelSchedule("digest");
  }

  async postDigest(min = MIN_CHANGES) {
    const response = await this.client.asServiceRole.functions.invoke("discordDigest", {
      hours: 24,
      min,
    });
    return response?.data ?? null;
  }

  // Called after every library change and feed post. The digest function itself
  // counts the last 24 hours and decides whether that is enough to post.
  async check(options = {}) {
    const requested = Number(options?.min);
    const min = requested > 0 ? Math.round(requested) : MIN_CHANGES;

    const now = Date.now();
    const last = (await this.storage.get("last_posted_at")) || 0;
    if (now - last < COOLDOWN_MS) {
      return { posted: false, reason: "a digest was posted in the last 12 hours" };
    }

    const result = await this.postDigest(min);
    if (result?.posted) await this.storage.put("last_posted_at", now);
    return result ?? { posted: false };
  }

  async postNow() {
    const result = await this.postDigest();
    if (result?.posted) await this.storage.put("last_posted_at", Date.now());
    return result;
  }
}