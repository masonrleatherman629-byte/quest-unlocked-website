const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from "npm:@base44/sdk@0.8.63";

const APP_URL = "https://literate-quest-core-hub.db.app";
const BOT_NAME = "Quest Unlocked";
const BOT_AVATAR =
  "https://media.db.com/images/public/6afdd17d5897428569d3106f/839e25a01_generated_image.png";
const ACCENT = 0x00b0f4;
const DEFAULT_HOURS = 24;
const DEFAULT_MIN_CHANGES = 5;
const MAX_LINES = 12;
const FIELD_LIMIT = 1024;

const versionBadge = (game) => {
  const version = (game.version || "").trim();
  if (!version) return game.size_label || "new build";
  return /^v/i.test(version) ? version : `v${version}`;
};

const changedSince = (record, since) => {
  const stamp = record.created_date || record.updated_date;
  return stamp ? new Date(stamp).getTime() >= since : false;
};

// Publishers count whether they were added or edited during the window.
const touchedSince = (record, since) =>
  [record.created_date, record.updated_date].some(
    (stamp) => stamp && new Date(stamp).getTime() >= since
  );

const trim = (value, max = 90) => {
  const text = (value || "").replace(/\s+/g, " ").trim();
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
};

const lines = (entries) => entries.slice(0, MAX_LINES).join("\n").slice(0, FIELD_LIMIT);

// A workflow step passes its arguments as the request body; `hours` widens the
// window and `min` decides how much has to have happened before anything posts.
const readOptions = async (req: Request) => {
  let body: Record<string, unknown> = {};
  if (req.method !== "GET") {
    try {
      const text = await req.clone().text();
      if (text) body = JSON.parse(text);
    } catch {
      body = {};
    }
  }
  const url = new URL(req.url);
  const hours = Number(body.hours ?? url.searchParams.get("hours"));
  const min = Number(body.min ?? url.searchParams.get("min"));
  return {
    hours: Number.isFinite(hours) && hours >= 1 && hours <= 168 ? Math.round(hours) : DEFAULT_HOURS,
    min: Number.isFinite(min) && min >= 1 ? Math.round(min) : DEFAULT_MIN_CHANGES,
  };
};

// Daily digest of everything that changed on the site over the last 24 hours:
// new builds added to the library, plus every entry in the updates feed.
Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  const me = await db.auth.me().catch(() => null);
  if (me && me.role !== "admin") {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }

  const { hours, min } = await readOptions(req);
  const since = Date.now() - hours * 60 * 60 * 1000;

  const [gamePage, updatePage, publisherPage] = await Promise.all([
    db.asServiceRole.entities.Game.list({ sort: "-created_date", limit: 200 }),
    db.asServiceRole.entities.Update.list({ sort: "-created_date", limit: 100 }),
    db.asServiceRole.entities.Publisher.list({ sort: "-created_date", limit: 100 }),
  ]);

  const newGames = (gamePage.items ?? gamePage)
    .filter((game) => game.status !== "Draft" && game.status !== "Archived")
    .filter((game) => changedSince(game, since));

  // The updates feed already logs every library addition and edit, so anything
  // posted on the site during the window belongs in the digest.
  const updates = (updatePage.items ?? updatePage).filter((entry) => changedSince(entry, since));

  // Studios and publishers added or edited on the site during the window.
  const newPublishers = (publisherPage.items ?? publisherPage).filter((publisher) =>
    touchedSince(publisher, since)
  );

  const total = newGames.length + newPublishers.length + updates.length;

  // Quiet days stay quiet: the digest only posts once enough has changed.
  if (total < min) {
    return Response.json({
      posted: false,
      games: newGames.length,
      publishers: newPublishers.length,
      updates: updates.length,
      reason: `fewer than ${min} changes in the last ${hours} hours`,
    });
  }

  // The bot's settings decide whether the digest posts at all, and to which channel.
  const config = await db.asServiceRole.entities.BotConfig.list({ limit: 1 })
    .then((page: any) => (page.items ?? page)[0] ?? null)
    .catch(() => null);

  if (config && config.enabled === false) {
    return Response.json({ posted: false, reason: "the bot is paused" });
  }

  const events: string[] = config?.updates_events ?? ["New game", "Game update", "Digest", "Site online"];
  const leaks: string[] = config?.leaks_events ?? [];
  const webhooks = [
    events.includes("Digest") ? Deno.env.get("DISCORD_WEBHOOK_URL") : null,
    leaks.includes("Digest") ? Deno.env.get("DISCORD_LEAKS_WEBHOOK_URL") : null,
  ].filter(Boolean) as string[];

  if (!webhooks.length) {
    return Response.json({ posted: false, reason: "the digest is switched off for both channels" });
  }

  const role = config?.ping_role === false ? null : Deno.env.get("DISCORD_PING_ROLE_ID");
  const botName = config?.bot_name || BOT_NAME;
  const botAvatar = config?.bot_avatar_url || BOT_AVATAR;
  const includeImage = config?.include_image !== false;

  const fields = [];
  if (newGames.length) {
    fields.push({
      name: `New in the library (${newGames.length})`,
      value: lines(newGames.map((game) => `**${trim(game.title, 60)}** — \`${versionBadge(game)}\``)),
    });
  }
  if (newPublishers.length) {
    fields.push({
      name: `Publishers (${newPublishers.length})`,
      value: lines(newPublishers.map((publisher) => `**${trim(publisher.name, 60)}**`)),
    });
  }
  if (updates.length) {
    fields.push({
      name: `Site updates (${updates.length})`,
      value: lines(
        updates.map((entry) => `**${trim(entry.title)}**${entry.kind ? ` — ${entry.kind}` : ""}`)
      ),
    });
  }

  const body = {
    username: botName,
    avatar_url: botAvatar,
    content: role ? `<@&${role}>` : undefined,
    allowed_mentions: { parse: ["roles"] },
    embeds: [
      {
        author: { name: botName, icon_url: botAvatar },
        title: `${total} ${total === 1 ? "change" : "changes"} in the last ${hours} hours`,
        url: APP_URL,
        description: `Everything added to ${botName} in the past ${hours} hours: new builds, publishers and site updates.`,
        color: ACCENT,
        thumbnail:
          includeImage && newGames[0]?.image_url ? { url: newGames[0].image_url } : undefined,
        fields,
        timestamp: new Date().toISOString(),
      },
    ],
  };

  const results = await Promise.all(
    webhooks.map(async (webhook) => {
      const response = await fetch(webhook, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      return response.ok;
    })
  );

  return Response.json({
    posted: results.some(Boolean),
    channels: results.filter(Boolean).length,
    games: newGames.length,
    publishers: newPublishers.length,
    updates: updates.length,
  });
});